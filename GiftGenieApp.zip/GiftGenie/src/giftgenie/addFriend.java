package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public  class addFriend extends BorderPane {

    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView notificationIcon;
    protected final ImageView imageView4;
    protected final Button MyWishlistButton;
    protected final Button HomeButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView imageView_1;
    protected final ImageView imageView_2;
    protected final ImageView imageView_3;
    protected final ImageView imageView_4;
    protected final ImageView imageView_5;
    protected final ImageView imageView_6;
    protected final ImageView imageView_7;
    protected final ImageView imageView_8;
    protected final ImageView imageView_9;
    protected final ImageView imageView_10;
    protected final Label lbl_date;
    protected final Label lbl_friend;
    protected final Label lbl_1;
    protected final Label lbl_2;
    protected final Label lbl_3;
    protected final Label lbl_4;
    protected final Label lbl_5;
    protected final Label lbl_6;
    protected final Label lbl_7;
    protected final Label lbl_8;
    protected final Label lbl_9;
    protected final Label lbl_10;
    protected final Label lbl_11;
    protected final Label lbl_12;
    protected final Label lbl_13;
    protected final Label lbl_14;
    protected final Label lbl_15;
    protected final Label lbl_16;
    protected final Label lbl_17;
    protected final Label lbl_18;
    protected final Label lbl_19;
    protected final Label lbl_20;
    protected final ImageView imageView5;
    protected final Button CashButton;
    protected final ImageView imageView6;
    protected final Button SettingButton;
    protected final ImageView imageView7;
    protected final Button HelpButton;
    protected final ImageView imageView8;
    protected final TextField search_bar_Icon;
    protected final ImageView addicon_1;
    protected final ImageView addicon_2;
    protected final ImageView addicon_3;
    protected final ImageView addicon_4;
    protected final ImageView addicon_5;
    protected final ImageView addicon_6;
    protected final ImageView addicon_7;
    protected final ImageView addicon_8;
    protected final ImageView addicon_9;
    protected final ImageView addicon_10;
    protected final ImageView friendRequestImage;
    protected final ImageView friendListImage;
    protected final ImageView titlepic2;
    protected final ImageView titlepic1;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    
    boolean notificationTurn = true;
    
    Stage s;
    String moneyValue;
    String backGroundPic = null;
    public addFriend(Stage s , String username , String moneyValue , String pic) {
        this.s = s;
        this.moneyValue = moneyValue;
        this.backGroundPic = pic; 
        anchorPane = new AnchorPane();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        notificationIcon = new ImageView();
        imageView4 = new ImageView();
        MyWishlistButton = new Button();
        HomeButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        imageView_1 = new ImageView();
        imageView_2 = new ImageView();
        imageView_3 = new ImageView();
        imageView_4 = new ImageView();
        imageView_5 = new ImageView();
        imageView_6 = new ImageView();
        imageView_7 = new ImageView();
        imageView_8 = new ImageView();
        imageView_9 = new ImageView();
        imageView_10 = new ImageView();
        lbl_date = new Label();
        lbl_friend = new Label();
        lbl_1 = new Label();
        lbl_2 = new Label();
        lbl_3 = new Label();
        lbl_4 = new Label();
        lbl_5 = new Label();
        lbl_6 = new Label();
        lbl_7 = new Label();
        lbl_8 = new Label();
        lbl_9 = new Label();
        lbl_10 = new Label();
        lbl_11 = new Label();
        lbl_12 = new Label();
        lbl_13 = new Label();
        lbl_14 = new Label();
        lbl_15 = new Label();
        lbl_16 = new Label();
        lbl_17 = new Label();
        lbl_18 = new Label();
        lbl_19 = new Label();
        lbl_20 = new Label();
        imageView5 = new ImageView();
        CashButton = new Button();
        imageView6 = new ImageView();
        SettingButton = new Button();
        imageView7 = new ImageView();
        HelpButton = new Button();
        imageView8 = new ImageView();
        search_bar_Icon = new TextField();
        addicon_1 = new ImageView();
        addicon_2 = new ImageView();
        addicon_3 = new ImageView();
        addicon_4 = new ImageView();
        addicon_5 = new ImageView();
        addicon_6 = new ImageView();
        addicon_7 = new ImageView();
        addicon_8 = new ImageView();
        addicon_9 = new ImageView();
        addicon_10 = new ImageView();
        friendRequestImage = new ImageView();
        friendListImage = new ImageView();
        titlepic1 = new ImageView();
        titlepic2 = new ImageView();
        notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();

       setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));

        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        imageView3.setFitHeight(61.0);
        imageView3.setFitWidth(65.0);
        imageView3.setLayoutX(18.0);
        imageView3.setLayoutY(134.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        imageView4.setFitHeight(42.0);
        imageView4.setFitWidth(41.0);
        imageView4.setLayoutX(975.0);
        imageView4.setLayoutY(8.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setCursor(Cursor.HAND);
        imageView4.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setCursor(Cursor.HAND);
        AddItemButton.setFont(new Font("System Bold", 24.0));

        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setCursor(Cursor.HAND);
        FriendButton.setFont(new Font("System Bold", 24.0));

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));

        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));
        
        notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);
        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        imageView_1.setFitHeight(45.0);
        imageView_1.setFitWidth(730.0);
        imageView_1.setLayoutX(300.0);
        imageView_1.setLayoutY(139.0);
        imageView_1.setPickOnBounds(true);
        imageView_1.setPreserveRatio(true);
        imageView_1.setVisible(false);
        imageView_1.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_2.setFitHeight(45.0);
        imageView_2.setFitWidth(730.0);
        imageView_2.setLayoutX(300.0);
        imageView_2.setLayoutY(189.0);
        imageView_2.setPickOnBounds(true);
        imageView_2.setPreserveRatio(true);
        imageView_2.setVisible(false);
        imageView_2.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_3.setFitHeight(45.0);
        imageView_3.setFitWidth(730.0);
        imageView_3.setLayoutX(300.0);
        imageView_3.setLayoutY(239.0);
        imageView_3.setPickOnBounds(true);
        imageView_3.setPreserveRatio(true);
        imageView_3.setVisible(false);
        imageView_3.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_4.setFitHeight(45.0);
        imageView_4.setFitWidth(730.0);
        imageView_4.setLayoutX(300.0);
        imageView_4.setLayoutY(289.0);
        imageView_4.setPickOnBounds(true);
        imageView_4.setPreserveRatio(true);
        imageView_4.setVisible(false);
        imageView_4.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_5.setFitHeight(45.0);
        imageView_5.setFitWidth(730.0);
        imageView_5.setLayoutX(300.0);
        imageView_5.setLayoutY(339.0);
        imageView_5.setPickOnBounds(true);
        imageView_5.setPreserveRatio(true);
        imageView_5.setVisible(false);
        imageView_5.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_6.setFitHeight(45.0);
        imageView_6.setFitWidth(730.0);
        imageView_6.setLayoutX(300.0);
        imageView_6.setLayoutY(389.0);
        imageView_6.setPickOnBounds(true);
        imageView_6.setPreserveRatio(true);
        imageView_6.setVisible(false);
        imageView_6.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_7.setFitHeight(45.0);
        imageView_7.setFitWidth(730.0);
        imageView_7.setLayoutX(300.0);
        imageView_7.setLayoutY(439.0);
        imageView_7.setPickOnBounds(true);
        imageView_7.setPreserveRatio(true);
        imageView_7.setVisible(false);
        imageView_7.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_8.setFitHeight(45.0);
        imageView_8.setFitWidth(730.0);
        imageView_8.setLayoutX(300.0);
        imageView_8.setLayoutY(489.0);
        imageView_8.setPickOnBounds(true);
        imageView_8.setPreserveRatio(true);
        imageView_8.setVisible(false);
        imageView_8.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_9.setFitHeight(45.0);
        imageView_9.setFitWidth(730.0);
        imageView_9.setLayoutX(300.0);
        imageView_9.setLayoutY(539.0);
        imageView_9.setPickOnBounds(true);
        imageView_9.setPreserveRatio(true);
        imageView_9.setVisible(false);
        imageView_9.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_10.setFitHeight(45.0);
        imageView_10.setFitWidth(730.0);
        imageView_10.setLayoutX(300.0);
        imageView_10.setLayoutY(589.0);
        imageView_10.setPickOnBounds(true);
        imageView_10.setPreserveRatio(true);
        imageView_10.setVisible(false);
        imageView_10.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        lbl_date.setLayoutX(341.0);
        lbl_date.setLayoutY(108.0);
        lbl_date.setText("Username");
        lbl_date.setFont(new Font("System Bold", 12.0));

        lbl_friend.setLayoutX(553.0);
        lbl_friend.setLayoutY(107.0);
        lbl_friend.setText("Name");
        lbl_friend.setFont(new Font("System Bold", 12.0));

        lbl_1.setLayoutX(345.0);
        lbl_1.setLayoutY(150.0);
        lbl_1.setPrefHeight(20.0);
        lbl_1.setPrefWidth(60.0);
        lbl_1.setText("phone");
        lbl_1.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_1.setVisible(false);
        lbl_1.setFont(new Font("System Bold", 14.0));

        lbl_2.setLayoutX(345.0);
        lbl_2.setLayoutY(200.0);
        lbl_2.setText("phone");
        lbl_2.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_2.setVisible(false);
        lbl_2.setFont(new Font("System Bold", 14.0));

        lbl_3.setLayoutX(345.0);
        lbl_3.setLayoutY(250.0);
        lbl_3.setText("phone");
        lbl_3.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_3.setVisible(false);
        lbl_3.setFont(new Font("System Bold", 14.0));

        lbl_4.setLayoutX(345.0);
        lbl_4.setLayoutY(300.0);
        lbl_4.setText("phone");
        lbl_4.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_4.setVisible(false);
        lbl_4.setFont(new Font("System Bold", 14.0));

        lbl_5.setLayoutX(345.0);
        lbl_5.setLayoutY(350.0);
        lbl_5.setText("phone");
        lbl_5.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_5.setVisible(false);
        lbl_5.setFont(new Font("System Bold", 14.0));

        lbl_6.setLayoutX(345.0);
        lbl_6.setLayoutY(400.0);
        lbl_6.setText("phone");
        lbl_6.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_6.setVisible(false);
        lbl_6.setFont(new Font("System Bold", 14.0));

        lbl_7.setLayoutX(345.0);
        lbl_7.setLayoutY(450.0);
        lbl_7.setText("phone");
        lbl_7.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_7.setVisible(false);
        lbl_7.setFont(new Font("System Bold", 14.0));

        lbl_8.setLayoutX(345.0);
        lbl_8.setLayoutY(500.0);
        lbl_8.setText("phone");
        lbl_8.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_8.setVisible(false);
        lbl_8.setFont(new Font("System Bold", 14.0));

        lbl_9.setLayoutX(345.0);
        lbl_9.setLayoutY(550.0);
        lbl_9.setText("phone");
        lbl_9.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_9.setVisible(false);
        lbl_9.setFont(new Font("System Bold", 14.0));

        lbl_10.setLayoutX(345.0);
        lbl_10.setLayoutY(600.0);
        lbl_10.setText("phone");
        lbl_10.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_10.setVisible(false);
        lbl_10.setFont(new Font("System Bold", 14.0));

        lbl_11.setLayoutX(540.0);
        lbl_11.setLayoutY(150.0);
        lbl_11.setText("Abdelaziz");
        lbl_11.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_11.setVisible(false);
        lbl_11.setFont(new Font("System Bold", 14.0));

        lbl_12.setLayoutX(540.0);
        lbl_12.setLayoutY(200.0);
        lbl_12.setText("Abdelaziz");
        lbl_12.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_12.setVisible(false);
        lbl_12.setFont(new Font("System Bold", 14.0));

        lbl_13.setLayoutX(540.0);
        lbl_13.setLayoutY(250.0);
        lbl_13.setText("Abdelaziz");
        lbl_13.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_13.setVisible(false);
        lbl_13.setFont(new Font("System Bold", 14.0));

        lbl_14.setLayoutX(540.0);
        lbl_14.setLayoutY(300.0);
        lbl_14.setText("Abdelaziz");
        lbl_14.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_14.setVisible(false);
        lbl_14.setFont(new Font("System Bold", 14.0));

        lbl_15.setLayoutX(540.0);
        lbl_15.setLayoutY(350.0);
        lbl_15.setText("Abdelaziz");
        lbl_15.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_15.setVisible(false);
        lbl_15.setFont(new Font("System Bold", 14.0));

        lbl_16.setLayoutX(540.0);
        lbl_16.setLayoutY(400.0);
        lbl_16.setText("Abdelaziz");
        lbl_16.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_16.setVisible(false);
        lbl_16.setFont(new Font("System Bold", 14.0));

        lbl_17.setLayoutX(540.0);
        lbl_17.setLayoutY(450.0);
        lbl_17.setText("Abdelaziz");
        lbl_17.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_17.setVisible(false);
        lbl_17.setFont(new Font("System Bold", 14.0));

        lbl_18.setLayoutX(540.0);
        lbl_18.setLayoutY(500.0);
        lbl_18.setText("Abdelaziz");
        lbl_18.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_18.setVisible(false);
        lbl_18.setFont(new Font("System Bold", 14.0));

        lbl_19.setLayoutX(540.0);
        lbl_19.setLayoutY(550.0);
        lbl_19.setText("Abdelaziz");
        lbl_19.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_19.setVisible(false);
        lbl_19.setFont(new Font("System Bold", 14.0));

        lbl_20.setLayoutX(540.0);
        lbl_20.setLayoutY(600.0);
        lbl_20.setText("Abdelaziz");
        lbl_20.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_20.setVisible(false);
        lbl_20.setFont(new Font("System Bold", 14.0));

        imageView5.setFitHeight(51.0);
        imageView5.setFitWidth(59.0);
        imageView5.setLayoutX(15.0);
        imageView5.setLayoutY(260.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));

        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));
        
        titlepic1.setFitHeight(107.0);
        titlepic1.setFitWidth(68.0);
        titlepic1.setLayoutX(334.0);
        titlepic1.setLayoutY(82.0);
        titlepic1.setPickOnBounds(true);
        titlepic1.setPreserveRatio(true);
        titlepic1.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));
        
        titlepic2.setFitHeight(107.0);
        titlepic2.setFitWidth(68.0);
        titlepic2.setLayoutX(536.0);
        titlepic2.setLayoutY(81.0);
        titlepic2.setPickOnBounds(true);
        titlepic2.setPreserveRatio(true);
        titlepic2.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));
        
        imageView6.setFitHeight(51.0);
        imageView6.setFitWidth(59.0);
        imageView6.setLayoutX(17.0);
        imageView6.setLayoutY(316.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setCursor(Cursor.HAND);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView7.setFitHeight(51.0);
        imageView7.setFitWidth(59.0);
        imageView7.setLayoutX(19.0);
        imageView7.setLayoutY(378.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setCursor(Cursor.HAND);
        HelpButton.setFont(new Font("System Bold", 24.0));

        imageView8.setFitHeight(48.0);
        imageView8.setFitWidth(667.0);
        imageView8.setLayoutX(297.0);
        imageView8.setLayoutY(60.0);
        imageView8.setPickOnBounds(true);
        imageView8.setPreserveRatio(true);
        imageView8.setImage(new Image(getClass().getResource("searchbar.png").toExternalForm()));

        search_bar_Icon.setBlendMode(javafx.scene.effect.BlendMode.MULTIPLY);
        search_bar_Icon.setLayoutX(330.0);
        search_bar_Icon.setLayoutY(67.0);
        search_bar_Icon.setPrefHeight(25.0);
        search_bar_Icon.setPrefWidth(554.0);
        search_bar_Icon.setPromptText("Search By First Name And press Enter");
        search_bar_Icon.setStyle("-fx-background-radius: 30; -fx-background-color: white;");

        addicon_1.setFitHeight(22.0);
        addicon_1.setFitWidth(25.0);
        addicon_1.setLayoutX(860.0);
        addicon_1.setLayoutY(150.0);
        addicon_1.setPickOnBounds(true);
        addicon_1.setPreserveRatio(true);
        addicon_1.setVisible(false);
        addicon_1.setCursor(Cursor.HAND);
        addicon_1.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_2.setFitHeight(22.0);
        addicon_2.setFitWidth(25.0);
        addicon_2.setLayoutX(860.0);
        addicon_2.setLayoutY(200.0);
        addicon_2.setPickOnBounds(true);
        addicon_2.setPreserveRatio(true);
        addicon_2.setVisible(false);
        addicon_2.setCursor(Cursor.HAND);
        addicon_2.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_3.setFitHeight(22.0);
        addicon_3.setFitWidth(25.0);
        addicon_3.setLayoutX(860.0);
        addicon_3.setLayoutY(250.0);
        addicon_3.setPickOnBounds(true);
        addicon_3.setPreserveRatio(true);
        addicon_3.setVisible(false);
        addicon_3.setCursor(Cursor.HAND);
        addicon_3.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_4.setFitHeight(22.0);
        addicon_4.setFitWidth(25.0);
        addicon_4.setLayoutX(823.0);
        addicon_4.setLayoutY(300.0);
        addicon_4.setPickOnBounds(true);
        addicon_4.setPreserveRatio(true);
        addicon_4.setVisible(false);
        addicon_4.setCursor(Cursor.HAND);
        addicon_4.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_5.setFitHeight(22.0);
        addicon_5.setFitWidth(25.0);
        addicon_5.setLayoutX(860.0);
        addicon_5.setLayoutY(350.0);
        addicon_5.setPickOnBounds(true);
        addicon_5.setPreserveRatio(true);
        addicon_5.setVisible(false);
        addicon_5.setCursor(Cursor.HAND);
        addicon_5.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_6.setFitHeight(22.0);
        addicon_6.setFitWidth(25.0);
        addicon_6.setLayoutX(860.0);
        addicon_6.setLayoutY(400.0);
        addicon_6.setPickOnBounds(true);
        addicon_6.setPreserveRatio(true);
        addicon_6.setVisible(false);
        addicon_6.setCursor(Cursor.HAND);
        addicon_6.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_7.setFitHeight(22.0);
        addicon_7.setFitWidth(25.0);
        addicon_7.setLayoutX(860.0);
        addicon_7.setLayoutY(450.0);
        addicon_7.setPickOnBounds(true);
        addicon_7.setPreserveRatio(true);
        addicon_7.setVisible(false);
        addicon_7.setCursor(Cursor.HAND);
        addicon_7.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_8.setFitHeight(22.0);
        addicon_8.setFitWidth(25.0);
        addicon_8.setLayoutX(860.0);
        addicon_8.setLayoutY(500.0);
        addicon_8.setPickOnBounds(true);
        addicon_8.setPreserveRatio(true);
        addicon_8.setVisible(false);
        addicon_8.setCursor(Cursor.HAND);
        addicon_8.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_9.setFitHeight(22.0);
        addicon_9.setFitWidth(25.0);
        addicon_9.setLayoutX(860.0);
        addicon_9.setLayoutY(550.0);
        addicon_9.setPickOnBounds(true);
        addicon_9.setPreserveRatio(true);
        addicon_9.setVisible(false);
        addicon_9.setCursor(Cursor.HAND);
        addicon_9.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        addicon_10.setFitHeight(22.0);
        addicon_10.setFitWidth(25.0);
        addicon_10.setLayoutX(860.0);
        addicon_10.setLayoutY(600.0);
        addicon_10.setPickOnBounds(true);
        addicon_10.setPreserveRatio(true);
        addicon_10.setVisible(false);
        addicon_10.setCursor(Cursor.HAND);
        addicon_10.setImage(new Image(getClass().getResource("addiconitem.png").toExternalForm()));

        friendRequestImage.setFitHeight(164.0);
        friendRequestImage.setFitWidth(40.0);
        friendRequestImage.setLayoutX(1061.0);
        friendRequestImage.setLayoutY(100.0);
        friendRequestImage.setPickOnBounds(true);
        friendRequestImage.setPreserveRatio(true);
        friendRequestImage.setCursor(Cursor.HAND);
        friendRequestImage.setImage(new Image(getClass().getResource("friendRequestImage.png").toExternalForm()));

        friendListImage.setFitHeight(164.0);
        friendListImage.setFitWidth(40.0);
        friendListImage.setLayoutX(1061.0);
        friendListImage.setLayoutY(250.0);
        friendListImage.setPickOnBounds(true);
        friendListImage.setPreserveRatio(true);
        friendListImage.setCursor(Cursor.HAND);
        friendListImage.setImage(new Image(getClass().getResource("friendListImage.png").toExternalForm()));
        setCenter(anchorPane);

        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(titlepic1);
        anchorPane.getChildren().add(titlepic2);
        anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(imageView_1);
        anchorPane.getChildren().add(imageView_2);
        anchorPane.getChildren().add(imageView_3);
        anchorPane.getChildren().add(imageView_4);
        anchorPane.getChildren().add(imageView_5);
        anchorPane.getChildren().add(imageView_6);
        anchorPane.getChildren().add(imageView_7);
        anchorPane.getChildren().add(imageView_8);
        anchorPane.getChildren().add(imageView_9);
        anchorPane.getChildren().add(imageView_10);
        anchorPane.getChildren().add(lbl_date);
        anchorPane.getChildren().add(lbl_friend);
        anchorPane.getChildren().add(lbl_1);
        anchorPane.getChildren().add(lbl_2);
        anchorPane.getChildren().add(lbl_3);
        anchorPane.getChildren().add(lbl_4);
        anchorPane.getChildren().add(lbl_5);
        anchorPane.getChildren().add(lbl_6);
        anchorPane.getChildren().add(lbl_7);
        anchorPane.getChildren().add(lbl_8);
        anchorPane.getChildren().add(lbl_9);
        anchorPane.getChildren().add(lbl_10);
        anchorPane.getChildren().add(lbl_11);
        anchorPane.getChildren().add(lbl_12);
        anchorPane.getChildren().add(lbl_13);
        anchorPane.getChildren().add(lbl_14);
        anchorPane.getChildren().add(lbl_15);
        anchorPane.getChildren().add(lbl_16);
        anchorPane.getChildren().add(lbl_17);
        anchorPane.getChildren().add(lbl_18);
        anchorPane.getChildren().add(lbl_19);
        anchorPane.getChildren().add(lbl_20);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(imageView6);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(imageView7);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(imageView8);
        anchorPane.getChildren().add(search_bar_Icon);
        anchorPane.getChildren().add(addicon_1);
        anchorPane.getChildren().add(addicon_2);
        anchorPane.getChildren().add(addicon_3);
        anchorPane.getChildren().add(addicon_4);
        anchorPane.getChildren().add(addicon_5);
        anchorPane.getChildren().add(addicon_6);
        anchorPane.getChildren().add(addicon_7);
        anchorPane.getChildren().add(addicon_8);
        anchorPane.getChildren().add(addicon_9);
        anchorPane.getChildren().add(addicon_10);
        anchorPane.getChildren().add(friendRequestImage);
        anchorPane.getChildren().add(friendListImage);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);

        moneyText.setText(moneyValue);
        nameText.setText(username);
        if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        HomeButton.setOnAction(e -> {
             try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        FriendButton.setOnMouseEntered(e -> {
                    FriendButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnMouseExited(e -> {
                    FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchFriendsScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
                    
        HelpButton.setOnMouseEntered(e -> {
                    HelpButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HelpButton.setOnMouseExited(e -> {
                    HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        HelpButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchHelpScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        imageView4.setOnMouseClicked(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddItemButton.setOnMouseEntered(e -> {
                    AddItemButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        AddItemButton.setOnMouseExited(e -> {
                    AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        AddItemButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchAddItemScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });
        Label[] userNameLabels = {lbl_1, lbl_2, lbl_3, lbl_4, lbl_5,
            lbl_6, lbl_7, lbl_8, lbl_9, lbl_10};

        Label[] NameLabels = {lbl_11, lbl_12, lbl_13, lbl_14, lbl_15,
            lbl_16, lbl_17, lbl_18, lbl_19, lbl_20};

        ImageView[] addFriendIcon = {addicon_1, addicon_2, addicon_3, addicon_4, addicon_5,
            addicon_6, addicon_7, addicon_8, addicon_9, addicon_10};

        ImageView[] imageViews = {imageView_1, imageView_2, imageView_3, imageView_4, imageView_5,
            imageView_6, imageView_7, imageView_8, imageView_9, imageView_10};

        search_bar_Icon.setOnKeyPressed(e -> {
            Socket socket;
            try { 
                socket = new Socket("localhost", 7001);
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                if (e.getCode() == KeyCode.ENTER) {
                    String friendName = search_bar_Icon.getText();

                    String request = "addFriend" + ":" + friendName + ":" + username;
                    out.println(request);
                    String inputString = in.readLine();

                    if (inputString.length() == 0) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("No Content Available");
                        alert.setHeaderText(null);
                        alert.setContentText("There is no user with this name , Please try again.");
                        alert.showAndWait();
                        clearText(imageViews, userNameLabels, NameLabels, addFriendIcon);

                    } else {
                        clearText(imageViews, userNameLabels, NameLabels, addFriendIcon);
                        listingOfNewFriend(inputString, imageViews, userNameLabels, NameLabels, addFriendIcon);
                        
                        addicon_1.setOnMouseClicked(add -> {
                            int num =0 ;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username , num );
                        });

                        addicon_2.setOnMouseClicked(add -> {
                            int num =1;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username ,num);
                        });

                        addicon_3.setOnMouseClicked(add -> {
                             int num =2;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username , num );
                        });
                        addicon_4.setOnMouseClicked(add -> {
                             int num = 3;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username, num);
                        });
                        addicon_5.setOnMouseClicked(add -> {
                             int num = 4;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username , num);
                        });
                        addicon_6.setOnMouseClicked(add -> {
                             int num =5;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username , num);
                        });
                        addicon_7.setOnMouseClicked(add -> {
                             int num =6;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username ,num);
                        });
                        addicon_8.setOnMouseClicked(add -> {
                             int num =7;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username , num);
                        });
                        addicon_9.setOnMouseClicked(add -> {
                             int num =8;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username ,num);
                        });
                        addicon_10.setOnMouseClicked(add -> {
                             int num =9;
                            handleAddIcon(imageViews, userNameLabels, NameLabels, addFriendIcon , username ,num);
                        });                        
                        
                    }
                    return;
                }

            } catch (IOException ex) {
                Logger.getLogger(addFriend.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        friendListImage.setOnMouseClicked(e -> {
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendsScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
        friendRequestImage.setOnMouseClicked(e -> {
            try {   
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchFriendRequestScene();
            } catch (IOException ex) {
                Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

public void listingOfNewFriend(String response ,ImageView[] imageViews ,  Label[] userNameLabels  ,Label[] NameLabels  , ImageView[] addFriendIcon )
    {
        String[] data = response.split("#");
 
            
            for (int i = 0; i < imageViews.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String userName     = components[0];
                String firstName    = components[1];
                String lastName     = components[2];
                String concateName  = firstName+" "+lastName; 
 
                imageViews[i].setVisible(true);
                addFriendIcon[i].setVisible(true);
 
                
                userNameLabels[i].setText(userName);
                userNameLabels[i].setVisible(true);
                 
                NameLabels[i].setText(concateName);
                NameLabels[i].setVisible(true);
         
            }
            
    }
    
public void clearText(ImageView[] imageViews, Label[] userNameLabels, Label[] nameLabels, ImageView[] addFriendIcon) {
    for (int i = 0; i < imageViews.length; i++) {
            
            imageViews[i].setVisible(false);
            
            userNameLabels[i].setText("");
            
            userNameLabels[i].setVisible(false);
            
            nameLabels[i].setText("");
            
            nameLabels[i].setVisible(false);
            
            addFriendIcon[i].setVisible(false);
    }
 }

public void handleAddIcon(ImageView[] imageViews , Label[] userNameLabels , Label[] NameLabels, ImageView[] addFriendIcon  ,String username , int num){
  try {
                            Socket SS = new Socket("localhost", 7001);
                            PrintWriter output = new PrintWriter(SS.getOutputStream(), true);
                            BufferedReader input = new BufferedReader(new InputStreamReader(SS.getInputStream()));

                                String send = "FriendRequest" + ":" + username + ":" + userNameLabels[num].getText()+":" + "Pending";
                                output.println(send);
                                String response = input.readLine();
                                if (response.equals("true")) 
                                {
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setTitle("Send Friend Request");
                                    alert.setHeaderText(null);
                                    alert.setContentText("You Send Friend Request To "+ userNameLabels[num].getText());
                                    alert.showAndWait();
                                    clearText(imageViews, userNameLabels, NameLabels, addFriendIcon);
                                }
                                else{
                                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                    alert.setTitle("Send Friend Request");
                                    alert.setHeaderText(null);
                                    alert.setContentText("Sending friend request to  "+userNameLabels[num].getText()+" is failed ");
                                    alert.showAndWait();
                                    clearText(imageViews, userNameLabels, NameLabels, addFriendIcon);
                                }
 
                            } catch (IOException ex) {
                                Logger.getLogger(addFriend.class.getName()).log(Level.SEVERE, null, ex);
                            }                        
    };

	public void notificationView(  String response , Text[] notification )
    {       
	    String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    }
}
