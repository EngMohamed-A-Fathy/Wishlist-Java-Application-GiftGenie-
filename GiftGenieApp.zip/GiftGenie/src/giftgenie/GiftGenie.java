
package giftgenie;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class GiftGenie extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent rootlogin = new LoginScene(stage);
        stage.setResizable(false);

        Scene scene = new Scene(rootlogin);
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            public void handle(WindowEvent event) {
                System.exit(0);
            }
        });
        stage.setScene(scene);
        stage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
    
}
