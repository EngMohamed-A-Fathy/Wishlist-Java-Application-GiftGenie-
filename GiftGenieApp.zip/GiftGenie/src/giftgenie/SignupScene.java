package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
//import Server.src.server.server;

public  class SignupScene extends BorderPane {

    
    protected final ImageView imageStar;
    protected final ImageView imageStar2;
    protected final ImageView imageBoo;
    
    
    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ProgressBar pgbar;
    protected final TextField textFirstname;
    protected final Text text;
    protected final TextField textLastname;
    protected final TextField textUsername;
    protected final TextField textPhone;
    protected final TextField textEmail;
    protected final TextField textBirthdate;
    protected final TextField textPassword;
    protected final TextField textConpassword;
    protected final TextField TextFieldanswer;
    protected final Text text0;
    protected final Button btnSignUp;
    protected final Button btnLoginhere;

    public SignupScene(Stage s) throws IOException {

        anchorPane = new AnchorPane();
        imageView = new ImageView();
        pgbar = new ProgressBar();
        textFirstname = new TextField();
        text = new Text();
        textLastname = new TextField();
        textUsername = new TextField();
        textPhone = new TextField();
        textEmail = new TextField();
        textBirthdate = new TextField();
        textPassword = new TextField();
        textConpassword = new TextField();
        TextFieldanswer = new TextField();
        text0 = new Text();
        btnSignUp = new Button();
        btnLoginhere = new Button();

        setMaxHeight(400.0);
        setMaxWidth(612.0);
        setMinHeight(400.0);
        setMinWidth(570.0);
        setPrefHeight(400.0);
        setPrefWidth(592.0);

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setPrefHeight(410.0);
        anchorPane.setPrefWidth(613.0);

        imageView.setFitHeight(427.0);
        imageView.setFitWidth(610.0);
        imageView.setLayoutX(0.0);
        imageView.setLayoutY(0.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("loginback.png").toExternalForm()));

        pgbar.setLayoutX(463.0);
        pgbar.setLayoutY(301.0);
        pgbar.setMaxHeight(12.0);
        pgbar.setMinHeight(12.0);
        pgbar.setPrefHeight(12.0);
        pgbar.setPrefWidth(147.0);
        pgbar.setProgress(0.0);

        textFirstname.setAlignment(javafx.geometry.Pos.CENTER);
        textFirstname.setLayoutX(460.0);
        textFirstname.setLayoutY(36.0);
        textFirstname.setOpacity(0.95);
        textFirstname.setPrefHeight(23.0);
        textFirstname.setPrefWidth(147.0);
        textFirstname.setPromptText("insert FirstName here");
        textFirstname.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        text.setFill(javafx.scene.paint.Color.valueOf("#f0faff"));
        text.setLayoutX(467.0);
        text.setLayoutY(27.0);
        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setText("Signup screen!");
        text.setWrappingWidth(147.6552734375);
        text.setFont(new Font("System Bold", 18.0));

        textLastname.setAlignment(javafx.geometry.Pos.CENTER);
        textLastname.setLayoutX(460.0);
        textLastname.setLayoutY(69.0);
        textLastname.setOpacity(0.95);
        textLastname.setPrefHeight(23.0);
        textLastname.setPrefWidth(147.0);
        textLastname.setPromptText("insert LastName here");
        textLastname.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textUsername.setAlignment(javafx.geometry.Pos.CENTER);
        textUsername.setLayoutX(462.0);
        textUsername.setLayoutY(102.0);
        textUsername.setOpacity(0.95);
        textUsername.setPrefHeight(23.0);
        textUsername.setPrefWidth(147.0);
        textUsername.setPromptText("insert Username here");
        textUsername.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textPhone.setAlignment(javafx.geometry.Pos.CENTER);
        textPhone.setLayoutX(462.0);
        textPhone.setLayoutY(135.0);
        textPhone.setOpacity(0.95);
        textPhone.setPrefHeight(23.0);
        textPhone.setPrefWidth(147.0);
        textPhone.setPromptText("insert your number here");
        textPhone.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textBirthdate.setAlignment(javafx.geometry.Pos.CENTER);
        textBirthdate.setLayoutX(462.0);
        textBirthdate.setLayoutY(168.0);
        textBirthdate.setOpacity(0.95);
        textBirthdate.setPrefHeight(23.0);
        textBirthdate.setPrefWidth(147.0);
        textBirthdate.setPromptText("Birthdate like 20/6/1997");
        textBirthdate.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textEmail.setAlignment(javafx.geometry.Pos.CENTER);
        textEmail.setLayoutX(463.0);
        textEmail.setLayoutY(202.0);
        textEmail.setOpacity(0.95);
        textEmail.setPrefHeight(23.0);
        textEmail.setPrefWidth(147.0);
        textEmail.setPromptText("Email");
        textEmail.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textPassword.setAlignment(javafx.geometry.Pos.CENTER);
        textPassword.setLayoutX(463.0);
        textPassword.setLayoutY(235.0);
        textPassword.setOpacity(0.95);
        textPassword.setPrefHeight(23.0);
        textPassword.setPrefWidth(147.0);
        textPassword.setPromptText("Password");
        textPassword.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        textConpassword.setAlignment(javafx.geometry.Pos.CENTER);
        textConpassword.setLayoutX(463.0);
        textConpassword.setLayoutY(269.0);
        textConpassword.setOpacity(0.95);
        textConpassword.setPrefHeight(23.0);
        textConpassword.setPrefWidth(147.0);
        textConpassword.setPromptText("Confirm Password");
        textConpassword.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        TextFieldanswer.setAlignment(javafx.geometry.Pos.CENTER);
        TextFieldanswer.setLayoutX(461.0);
        TextFieldanswer.setLayoutY(339.0);
        TextFieldanswer.setOpacity(0.95);
        TextFieldanswer.setPrefHeight(23.0);
        TextFieldanswer.setPrefWidth(147.0);
        TextFieldanswer.setPromptText("Insert secret word ");
        TextFieldanswer.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        text0.setFill(javafx.scene.paint.Color.WHITE);
        text0.setLayoutX(462.0);
        text0.setLayoutY(330.0);
        text0.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text0.setStrokeWidth(0.0);
        text0.setText("what is your secret word?");
        text0.setWrappingWidth(155.6552734375);
        text0.setFont(new Font("System Bold", 12.0));

        btnSignUp.setLayoutX(540.0);
        btnSignUp.setLayoutY(371.0);
        btnSignUp.setMnemonicParsing(false);
        btnSignUp.setOpacity(0.88);
        btnSignUp.setPrefHeight(30.0);
        btnSignUp.setPrefWidth(69.0);
        btnSignUp.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        btnSignUp.setText("SignUp");
        btnSignUp.setCursor(Cursor.HAND);
        btnSignUp.setFont(new Font("System Bold", 12.0));

        btnLoginhere.setLayoutX(460.0);
        btnLoginhere.setLayoutY(371.0);
        btnLoginhere.setMnemonicParsing(false);
        btnLoginhere.setOpacity(0.88);
        btnLoginhere.setPrefHeight(30.0);
        btnLoginhere.setPrefWidth(69.0);
        btnLoginhere.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        btnLoginhere.setText("Login");
        btnLoginhere.setCursor(Cursor.HAND);
        btnLoginhere.setFont(new Font("System Bold", 12.0));
        setRight(anchorPane);

        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(pgbar);
        anchorPane.getChildren().add(textFirstname);
        anchorPane.getChildren().add(text);
        anchorPane.getChildren().add(textLastname);
        anchorPane.getChildren().add(textUsername);
        anchorPane.getChildren().add(textPhone);
        anchorPane.getChildren().add(textEmail);
        anchorPane.getChildren().add(textBirthdate);
        anchorPane.getChildren().add(textPassword);
        anchorPane.getChildren().add(textConpassword);
        anchorPane.getChildren().add(TextFieldanswer);
        anchorPane.getChildren().add(text0);
        anchorPane.getChildren().add(btnSignUp);
        anchorPane.getChildren().add(btnLoginhere);

        pgbar.setStyle("-fx-accent: red;"); // set initial color to red
        
       
    textPassword.textProperty().addListener((observable, oldValue, newValue) -> {
        int length = newValue.length();
        double progress = calculateStrength(newValue);
        pgbar.setProgress(progress);
        
        // update color based on strength level
        if (progress < 0.33) {
            pgbar.setStyle("-fx-accent: red;");
        } else if (progress < 0.66) {
            pgbar.setStyle("-fx-accent: yellow;");
        } else {
            pgbar.setStyle("-fx-accent: green;");
        }
    });
        
        
    btnLoginhere.setOnAction(e -> {
        Parent rootlogin = new LoginScene(s);
        Scene scene = new Scene(rootlogin);
        s.setScene(scene);       
        });

    btnSignUp.setOnAction(e -> {
          
            Socket socket;
            try {
                socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String password = textPassword.getText();
                String confirmPassword = textConpassword.getText();
                String emailRegex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
                String email = textEmail.getText();
                 if(textPassword.getText().isEmpty() || textFirstname.getText().isEmpty() || textLastname.getText().isEmpty() ||textUsername.getText().isEmpty()||textPhone.getText().isEmpty()||textBirthdate.getText().isEmpty() || TextFieldanswer.getText().isEmpty())   {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Please fill all blank fields");
                        alert.showAndWait();
                        return;
                    } 
                     else if (!password.equals(confirmPassword)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry! Password and Confirm Password do not match. Please try again.");
                    alert.showAndWait();
                    return;
                }else if (!email.matches(emailRegex)) { 
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry! Email address is not in a valid format. Please try again.");
                    alert.showAndWait();
                    return;
                }
                
                
                String signUpQuery = "signup"+":"+textFirstname.getText() + ":" + textLastname.getText() + ":" + textUsername.getText() + ":" + textPhone.getText() + ":" + textEmail.getText() + ":" + textBirthdate.getText() + ":" + textPassword.getText()+ ":"+TextFieldanswer.getText();
                output.println(signUpQuery);
                boolean registerCheck = Boolean.parseBoolean(input.readLine());
                if (registerCheck) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Registration Successful");
                    alert.setHeaderText(null);
                    alert.setContentText("Thank you for registering into our GiftGenie App!");
                    alert.showAndWait();
                    Parent rootlogin = new LoginScene(s);
                    Scene scene = new Scene(rootlogin);
                    s.setScene(scene);  
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry! The Username entered is already there! try another username");
                    alert.showAndWait();
                }
                socket.close();
            } catch (IOException ex) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                    alert.showAndWait();
            }
        });
        
        imageStar = new ImageView();       
            imageStar.setFitHeight(200.0);
            imageStar.setFitWidth(200.0);
            imageStar.setLayoutX(-10.0);
            imageStar.setLayoutY(1.0);
            imageStar.setPickOnBounds(true);
            imageStar.setPreserveRatio(true);
            imageStar.setImage(new Image(getClass().getResource("star.png").toExternalForm()));
            imageStar.toFront(); 
            anchorPane.getChildren().add(imageStar);

            Thread starThread = new Thread(() -> {
                int y = 270;
                int x = -10;
                boolean sleep = true; 
                boolean rotate = true; 
                while (sleep == true ) {
                    if (rotate)
                    {
                    x += 10;
                    y -= 10 ;
                    }
                    else {
                    x += 10; 
                    y += 10;
                    }
                    imageStar.setLayoutX(x);
                    imageStar.setLayoutY(y);

                    if (y <= 0){
                            x=0;
                            y=0;
                            imageStar.setRotate(90.0);
                            rotate = false;
                            sleep=false;
                            imageStar.setVisible(false);
                    }else if(y>=270){
                           x=0;
                           y=270;
                           imageStar.setRotate(360.0); 
                           rotate = true;
                           sleep=false;
                           imageStar.setVisible(false);
                           }

                    try {
                        if(sleep == false ){
                        Thread.sleep(4555);
                        sleep = true;
                        imageStar.setVisible(true);

                        }
                        else{
                        Thread.sleep(100);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            starThread.setDaemon(true);
            starThread.start();

            imageStar2 = new ImageView();       
            imageStar2.setFitHeight(100.0);
            imageStar2.setFitWidth(100.0);
            imageStar2.setLayoutX(100.0);
            imageStar2.setLayoutY(1.0);
            imageStar2.setImage(new Image(getClass().getResource("star2.png").toExternalForm()));
            imageStar2.toFront(); 
            anchorPane.getChildren().add(imageStar2);


            Thread imageStar2Thread = new Thread(() -> {
            Random random = new Random();
            int op1 = -10;
            while (true) {
                int x = random.nextInt(400);
                int y = random.nextInt(300);
                imageStar2.setLayoutX(x);
                imageStar2.setLayoutY(y);
                for (int i = 0; i <= 100; i++) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (int i = 100; i >= 0; i--) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            });
            imageStar2Thread.setDaemon(true);
            imageStar2Thread.start();


            imageBoo = new ImageView();       
            imageBoo.setFitHeight(200.0);
            imageBoo.setFitWidth(200.0);
            imageBoo.setLayoutX(200.0);
            imageBoo.setLayoutY(100.0);
            imageBoo.setPickOnBounds(true);
            imageBoo.setPreserveRatio(true);
            imageBoo.setVisible(false);
            imageBoo.setImage(new Image(getClass().getResource("Boo.png").toExternalForm()));
            imageStar.toFront(); 
            anchorPane.getChildren().add(imageBoo);

            text.setOnMouseEntered(e -> {
                        text.setFill(Color.LIGHTBLUE);
                        text.setUnderline(true);
                        text.setFont(Font.font("System",FontWeight.BOLD ,18));
                         });
            text.setOnMouseExited(e -> {
                        text.setFill(Color.WHITE);
                        text.setUnderline(false);
                        text.setFont(Font.font("System",FontWeight.BOLD,  18));
                    });
            text.setOnMouseClicked(e -> {
                Thread imageBooThread = new Thread(() -> {
                imageBoo.setFitWidth(50.0);
                imageBoo.setVisible(true);
                int size = 50;
                int step = 5;

                while (size < 300) {
                    size += step;
                    imageBoo.setFitWidth(size);
                    imageBoo.setFitHeight(size);
                    imageBoo.setVisible(true);

                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException es) {
                        es.printStackTrace();
                    }
                }
                    imageBoo.setVisible(false);
                    Thread.currentThread().interrupt();
                });
                        imageBooThread.start();
            });
  
    }
    
    private double calculateStrength(String password) {
    int score = 0;

        if (password.length() >= 8) {
        score += 1;
        }

        if (password.matches(".*[A-Z].*")) {
            score += 1;
        }

        if (password.matches(".*[a-z].*")) {
            score += 1;
        }

        if (password.matches(".*\\d.*")) {
            score += 1;
        }

        if (password.matches(".*[!@#$%^&*()].*")) {
            score += 1;
        }

        switch (score) {
            case 1:
                return .15;
            case 2:
                return .33;
            case 3:
                return .66;
            case 4:
                return .9;
            default:
                return 0;
        }    
};               
}


