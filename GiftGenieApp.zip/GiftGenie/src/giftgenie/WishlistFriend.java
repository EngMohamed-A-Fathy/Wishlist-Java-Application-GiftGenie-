package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class WishlistFriend extends BorderPane {

    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView imageView4;
    protected final ImageView notificationIcon;
    protected final ImageView addMoney;
    protected final Button HomeButton;
    protected final Button MyWishlistButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button CashButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView imageView5;
    protected final Button SettingButton;
    protected final ImageView imageView6;
    protected final Button HelpButton;
    protected final ImageView imageView7;
    protected final ImageView back1;
    protected final ImageView img1;
    protected final Text price1;
    protected final Text rem1;
    protected final Text title1;
    protected final Text desc1;
    protected final ImageView back2;
    protected final ImageView img2;
    protected final Text price2;
    protected final Text rem2;
    protected final Text title2;
    protected final Text desc2;
    protected final ImageView back3;
    protected final ImageView img3;
    protected final Text price3;
    protected final Text rem3;
    protected final Text title3;
    protected final Text desc3;
    protected final ImageView back4;
    protected final ImageView img4;
    protected final Text price4;
    protected final Text rem4;
    protected final Text title4;
    protected final Text desc4;
    protected final ImageView next;
    protected final ImageView backButt;
    protected final ImageView cont1;
    protected final ImageView cont2;
    protected final ImageView cont3;
    protected final ImageView cont4;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    
    boolean notificationTurn = true;
    Text[] remain;
    int round = 1;
    String[][] arr ;
    String backGroundPic = "background/222s.png";
    String currentMoney;
    String username; 
    public WishlistFriend(Stage s , String username, String moneyValue, String pic , String friendUsername) {
        this.username = username;
        backGroundPic = pic; 
        currentMoney = moneyValue;
        anchorPane = new AnchorPane();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        imageView4 = new ImageView();
        notificationIcon = new ImageView();
        addMoney = new ImageView();
        HomeButton = new Button();
        MyWishlistButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        CashButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        imageView5 = new ImageView();
        SettingButton = new Button();
        imageView6 = new ImageView();
        HelpButton = new Button();
        imageView7 = new ImageView();
        back1 = new ImageView();
        img1 = new ImageView();
        price1 = new Text();
        rem1 = new Text();
        title1 = new Text();
        desc1 = new Text();
        back2 = new ImageView();
        img2 = new ImageView();
        price2 = new Text();
        rem2 = new Text();
        title2 = new Text();
        desc2 = new Text();
        back3 = new ImageView();
        img3 = new ImageView();
        price3 = new Text();
        rem3 = new Text();
        title3 = new Text();
        desc3 = new Text();
        back4 = new ImageView();
        img4 = new ImageView();
        price4 = new Text();
        rem4 = new Text();
        title4 = new Text();
        desc4 = new Text();
        next = new ImageView();
        backButt = new ImageView();
        cont1 = new ImageView();
        cont2 = new ImageView();
        cont3 = new ImageView();
        cont4 = new ImageView();
        notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();

        setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));

        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        imageView3.setFitHeight(51.0);
        imageView3.setFitWidth(59.0);
        imageView3.setLayoutX(15.0);
        imageView3.setLayoutY(260.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));

        imageView4.setFitHeight(61.0);
        imageView4.setFitWidth(65.0);
        imageView4.setLayoutX(18.0);
        imageView4.setLayoutY(134.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        addMoney.setFitHeight(42.0);
        addMoney.setFitWidth(41.0);
        addMoney.setLayoutX(975.0);
        addMoney.setLayoutY(8.0);
        addMoney.setPickOnBounds(true);
        addMoney.setPreserveRatio(true);
        addMoney.setCursor(Cursor.HAND);
        addMoney.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));
        notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setCursor(Cursor.HAND);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setFont(new Font("System Bold", 24.0));

        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setCursor(Cursor.HAND);
        FriendButton.setFont(new Font("System Bold", 24.0));

        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));

        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));

        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        imageView5.setFitHeight(51.0);
        imageView5.setFitWidth(59.0);
        imageView5.setLayoutX(17.0);
        imageView5.setLayoutY(316.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setCursor(Cursor.HAND);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView6.setFitHeight(51.0);
        imageView6.setFitWidth(59.0);
        imageView6.setLayoutX(19.0);
        imageView6.setLayoutY(378.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setCursor(Cursor.HAND);
        HelpButton.setFont(new Font("System Bold", 24.0));

        imageView7.setFitHeight(79.0);
        imageView7.setFitWidth(263.0);
        imageView7.setLayoutX(305.0);
        imageView7.setLayoutY(50.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(new Image(getClass().getResource("Wishlist/friendWishlist.png").toExternalForm()));

        back1.setFitHeight(115.0);
        back1.setFitWidth(414.0);
        back1.setLayoutX(427.0);
        back1.setLayoutY(157.0);
        back1.setPickOnBounds(true);
        back1.setPreserveRatio(true);
        back1.setVisible(false);
        back1.setImage(new Image(getClass().getResource("Wishlist/PicBar.png").toExternalForm()));

        img1.setFitHeight(90.0);
        img1.setFitWidth(140.0);
        img1.setLayoutX(300.0);
        img1.setLayoutY(163.0);
        img1.setPickOnBounds(true);
        img1.setPreserveRatio(true);
        img1.setVisible(false);
        img1.setImage(new Image(getClass().getResource("AddItem/Devices/1.png").toExternalForm()));

        price1.setLayoutX(503.0);
        price1.setLayoutY(229.0);
        price1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        price1.setStrokeWidth(0.0);
        price1.setText("1000");
        price1.setVisible(false);
        price1.setWrappingWidth(33.13671875);
        price1.setFont(new Font("System Bold", 10.0));

        rem1.setLayoutX(742.0);
        rem1.setLayoutY(229.0);
        rem1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rem1.setStrokeWidth(0.0);
        rem1.setText("1000");
        rem1.setVisible(false);
        rem1.setWrappingWidth(33.13671875);
        rem1.setFont(new Font("System Bold", 10.0));

        title1.setLayoutX(472.0);
        title1.setLayoutY(179.0);
        title1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        title1.setStrokeWidth(0.0);
        title1.setText("-");
        title1.setVisible(false);
        title1.setFont(new Font("System Bold", 14.0));

        desc1.setLayoutX(470.0);
        desc1.setLayoutY(202.0);
        desc1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        desc1.setStrokeWidth(0.0);
        desc1.setText("-");
        desc1.setVisible(false);
        desc1.setFont(new Font(14.0));

        back2.setFitHeight(115.0);
        back2.setFitWidth(414.0);
        back2.setLayoutX(427.0);
        back2.setLayoutY(261.0);
        back2.setPickOnBounds(true);
        back2.setPreserveRatio(true);
        back2.setVisible(false);
        back2.setImage(new Image(getClass().getResource("Wishlist/PicBar.png").toExternalForm()));

        img2.setFitHeight(90.0);
        img2.setFitWidth(140.0);
        img2.setLayoutX(300.0);
        img2.setLayoutY(267.0);
        img2.setPickOnBounds(true);
        img2.setPreserveRatio(true);
        img2.setVisible(false);
        img2.setImage(new Image(getClass().getResource("AddItem/Devices/2.png").toExternalForm()));

        price2.setLayoutX(503.0);
        price2.setLayoutY(333.0);
        price2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        price2.setStrokeWidth(0.0);
        price2.setText("1000");
        price2.setVisible(false);
        price2.setWrappingWidth(33.13671875);
        price2.setFont(new Font("System Bold", 10.0));

        rem2.setLayoutX(742.0);
        rem2.setLayoutY(333.0);
        rem2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rem2.setStrokeWidth(0.0);
        rem2.setText("1000");
        rem2.setVisible(false);
        rem2.setWrappingWidth(33.13671875);
        rem2.setFont(new Font("System Bold", 10.0));

        title2.setLayoutX(472.0);
        title2.setLayoutY(283.0);
        title2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        title2.setStrokeWidth(0.0);
        title2.setText("-");
        title2.setVisible(false);
        title2.setFont(new Font("System Bold", 14.0));

        desc2.setLayoutX(470.0);
        desc2.setLayoutY(306.0);
        desc2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        desc2.setStrokeWidth(0.0);
        desc2.setText("-");
        desc2.setVisible(false);
        desc2.setFont(new Font(14.0));

        back3.setFitHeight(115.0);
        back3.setFitWidth(414.0);
        back3.setLayoutX(428.0);
        back3.setLayoutY(369.0);
        back3.setPickOnBounds(true);
        back3.setPreserveRatio(true);
        back3.setVisible(false);
        back3.setImage(new Image(getClass().getResource("Wishlist/PicBar.png").toExternalForm()));

        img3.setFitHeight(90.0);
        img3.setFitWidth(140.0);
        img3.setLayoutX(301.0);
        img3.setLayoutY(375.0);
        img3.setPickOnBounds(true);
        img3.setPreserveRatio(true);
        img3.setVisible(false);
        img3.setImage(new Image(getClass().getResource("AddItem/Devices/3.png").toExternalForm()));

        price3.setLayoutX(504.0);
        price3.setLayoutY(441.0);
        price3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        price3.setStrokeWidth(0.0);
        price3.setText("1000");
        price3.setVisible(false);
        price3.setWrappingWidth(33.13671875);
        price3.setFont(new Font("System Bold", 10.0));

        rem3.setLayoutX(743.0);
        rem3.setLayoutY(441.0);
        rem3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rem3.setStrokeWidth(0.0);
        rem3.setText("1000");
        rem3.setVisible(false);
        rem3.setWrappingWidth(33.13671875);
        rem3.setFont(new Font("System Bold", 10.0));

        title3.setLayoutX(473.0);
        title3.setLayoutY(391.0);
        title3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        title3.setStrokeWidth(0.0);
        title3.setText("-");
        title3.setVisible(false);
        title3.setFont(new Font("System Bold", 14.0));

        desc3.setLayoutX(471.0);
        desc3.setLayoutY(414.0);
        desc3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        desc3.setStrokeWidth(0.0);
        desc3.setText("-");
        desc3.setVisible(false);
        desc3.setFont(new Font(14.0));

        back4.setFitHeight(115.0);
        back4.setFitWidth(414.0);
        back4.setLayoutX(428.0);
        back4.setLayoutY(477.0);
        back4.setPickOnBounds(true);
        back4.setPreserveRatio(true);
        back4.setVisible(false);
        back4.setImage(new Image(getClass().getResource("Wishlist/PicBar.png").toExternalForm()));

        img4.setFitHeight(90.0);
        img4.setFitWidth(140.0);
        img4.setLayoutX(301.0);
        img4.setLayoutY(483.0);
        img4.setPickOnBounds(true);
        img4.setPreserveRatio(true);
        img4.setVisible(false);
        img4.setImage(new Image(getClass().getResource("AddItem/Devices/4.png").toExternalForm()));

        price4.setLayoutX(504.0);
        price4.setLayoutY(549.0);
        price4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        price4.setStrokeWidth(0.0);
        price4.setText("1000");
        price4.setVisible(false);
        price4.setWrappingWidth(33.13671875);
        price4.setFont(new Font("System Bold", 10.0));

        rem4.setLayoutX(743.0);
        rem4.setLayoutY(549.0);
        rem4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rem4.setStrokeWidth(0.0);
        rem4.setText("1000");
        rem4.setVisible(false);
        rem4.setWrappingWidth(33.13671875);
        rem4.setFont(new Font("System Bold", 10.0));

        title4.setLayoutX(473.0);
        title4.setLayoutY(499.0);
        title4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        title4.setStrokeWidth(0.0);
        title4.setText("-");
        title4.setVisible(false);
        title4.setFont(new Font("System Bold", 14.0));

        desc4.setLayoutX(471.0);
        desc4.setLayoutY(522.0);
        desc4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        desc4.setStrokeWidth(0.0);
        desc4.setText("-");
        desc4.setVisible(false);
        desc4.setFont(new Font(14.0));

        next.setFitHeight(50.0);
        next.setFitWidth(74.0);
        next.setLayoutX(1032.0);
        next.setLayoutY(586.0);
        next.setPickOnBounds(true);
        next.setPreserveRatio(true);
        next.setImage(new Image(getClass().getResource("Wishlist/Next.png").toExternalForm()));

        backButt.setFitHeight(50.0);
        backButt.setFitWidth(74.0);
        backButt.setLayoutX(978.0);
        backButt.setLayoutY(586.0);
        backButt.setPickOnBounds(true);
        backButt.setPreserveRatio(true);
        backButt.setImage(new Image(getClass().getResource("Wishlist/Back.png").toExternalForm()));

        cont1.setFitHeight(63.0);
        cont1.setFitWidth(148.0);
        cont1.setLayoutX(855.0);
        cont1.setLayoutY(158.0);
        cont1.setPickOnBounds(true);
        cont1.setPreserveRatio(true);
        cont1.setVisible(false);
        cont1.setImage(new Image(getClass().getResource("Wishlist/Contribute.png").toExternalForm()));

        cont2.setFitHeight(63.0);
        cont2.setFitWidth(148.0);
        cont2.setLayoutX(855.0);
        cont2.setLayoutY(266.0);
        cont2.setPickOnBounds(true);
        cont2.setPreserveRatio(true);
        cont2.setVisible(false);
        cont2.setImage(new Image(getClass().getResource("Wishlist/Contribute.png").toExternalForm()));

        cont3.setFitHeight(63.0);
        cont3.setFitWidth(148.0);
        cont3.setLayoutX(855.0);
        cont3.setLayoutY(370.0);
        cont3.setPickOnBounds(true);
        cont3.setPreserveRatio(true);
        cont3.setVisible(false);
        cont3.setImage(new Image(getClass().getResource("Wishlist/Contribute.png").toExternalForm()));

        cont4.setFitHeight(63.0);
        cont4.setFitWidth(148.0);
        cont4.setLayoutX(855.0);
        cont4.setLayoutY(476.0);
        cont4.setPickOnBounds(true);
        cont4.setPreserveRatio(true);
        cont4.setVisible(false);
        cont4.setImage(new Image(getClass().getResource("Wishlist/Contribute.png").toExternalForm()));
        setCenter(anchorPane);

        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(addMoney);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(imageView6);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(imageView7);
        anchorPane.getChildren().add(back1);
        anchorPane.getChildren().add(img1);
        anchorPane.getChildren().add(price1);
        anchorPane.getChildren().add(rem1);
        anchorPane.getChildren().add(title1);
        anchorPane.getChildren().add(desc1);
        anchorPane.getChildren().add(back2);
        anchorPane.getChildren().add(img2);
        anchorPane.getChildren().add(price2);
        anchorPane.getChildren().add(rem2);
        anchorPane.getChildren().add(title2);
        anchorPane.getChildren().add(desc2);
        anchorPane.getChildren().add(back3);
        anchorPane.getChildren().add(img3);
        anchorPane.getChildren().add(price3);
        anchorPane.getChildren().add(rem3);
        anchorPane.getChildren().add(title3);
        anchorPane.getChildren().add(desc3);
        anchorPane.getChildren().add(back4);
        anchorPane.getChildren().add(img4);
        anchorPane.getChildren().add(price4);
        anchorPane.getChildren().add(rem4);
        anchorPane.getChildren().add(title4);
        anchorPane.getChildren().add(desc4);
        anchorPane.getChildren().add(next);
        anchorPane.getChildren().add(backButt);
        anchorPane.getChildren().add(cont1);
        anchorPane.getChildren().add(cont2);
        anchorPane.getChildren().add(cont3);
        anchorPane.getChildren().add(cont4);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);
        
        moneyText.setText(currentMoney);
        nameText.setText(username);
        
        if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        HomeButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue ,backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        FriendButton.setOnMouseEntered(e -> {
                    FriendButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnMouseExited(e -> {
                    FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchFriendsScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
                    
        HelpButton.setOnMouseEntered(e -> {
                    HelpButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HelpButton.setOnMouseExited(e -> {
                    HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        HelpButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchHelpScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addMoney.setOnMouseClicked(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddItemButton.setOnMouseEntered(e -> {
                    AddItemButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        AddItemButton.setOnMouseExited(e -> {
                    AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        AddItemButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchAddItemScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
         Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });
        ImageView[] backGround = {back1, back2, back3, back4};
        ImageView[] image = {img1, img2, img3, img4};
        ImageView[] cont = {cont1, cont2, cont3, cont4};
        Text[] title = {title1, title2, title3, title4};
        Text[] desc = {desc1,desc2,desc3,desc4};
        Text[] price = {price1,price2,price3,price4};
        remain = new Text[] {rem1, rem2, rem3, rem4};
        Socket socket;
        try {
            socket = new Socket("localhost", 7001);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String request = "wishlist" + ":" + friendUsername ;
            output.println(request);
            
            String response = input.readLine();
            if(!response.contains("fail")){
            String[] data = response.split("#");

            List<String[]> dataList = new ArrayList<>();
            if (data.length > 4) {
                int remaining = data.length;
                int index = 0;

                while (remaining > 0) {
                    int endIndex = Math.min(index + 4, data.length);
                    String[] subArray = Arrays.copyOfRange(data, index, endIndex);
                    dataList.add(subArray);
                    remaining -= subArray.length;
                    index += subArray.length;
                }
            } else {
                dataList.add(data);
            }
            
            int size = dataList.size();
            arr = new String[size][];

            for (int i = 0; i < size; i++) {
                    arr[i] = dataList.get(i);
            }
            listingOfWishlist(arr[0],backGround,image,title,desc,price,remain,cont);
            }
            else{
                   next.setVisible(false);
                   backButt.setVisible(false);
            }
        } catch (IOException ex) {
            Logger.getLogger(Wishlist.class.getName()).log(Level.SEVERE, null, ex);
        }
        cont1.setOnMouseClicked(event -> {
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Contribution");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the amount you want to contribute:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    int data = Integer.parseInt(result.get());
                    String contribution = String.valueOf(data);
                    handleContribute(contribution, friendUsername, title[0].getText(), 0);
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("You have to enter an integer, don't trick us !");
                    alert.showAndWait();
                }
        }

        });
        cont2.setOnMouseClicked(event -> {

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Contribution");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the amount you want to contribute:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    int data = Integer.parseInt(result.get());
                    String contribution = String.valueOf(data);
                    handleContribute(contribution, friendUsername, title[1].getText(), 1);
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("You have to enter an integer, don't trick us !");
                    alert.showAndWait();
                }
        }
        });
        cont3.setOnMouseClicked(event -> {

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Contribution");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the amount you want to contribute:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    int data = Integer.parseInt(result.get());
                    String contribution = String.valueOf(data);
                    handleContribute(contribution, friendUsername, title[2].getText(), 2);
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("You have to enter an integer, don't trick us !");
                    alert.showAndWait();
                }
        }
        });
        cont4.setOnMouseClicked(event -> {

            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Contribution");
            dialog.setHeaderText(null);
            dialog.setContentText("Enter the amount you want to contribute:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                    try {
                        int data = Integer.parseInt(result.get());
                        String contribution = String.valueOf(data);
                        handleContribute(contribution, friendUsername, title[3].getText(), 3);
                    } catch (NumberFormatException e) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("You have to enter an integer, don't trick us !");
                        alert.showAndWait();
                    }
            }
        });
        next.setOnMouseClicked(event -> {
                if (round >= 1 && round < arr.length && arr[round] != null) {
                        clear();
                        listingOfWishlist(arr[round], backGround, image, title, desc, price, remain,cont);
                        round++;
                } else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "No more items to show!");
                        alert.showAndWait();
                }
        });
        backButt.setOnMouseClicked(event -> {
                if (round > 1)
                {round--;}

                if(round >= 1 && round < arr.length && arr[round] != null) {
                        clear();
                        listingOfWishlist(arr[round-1], backGround, image, title, desc, price, remain,cont);
                }
        });
    }
      public void clear(){
            price1.setVisible(false);
            price2.setVisible(false);
            price3.setVisible(false);
            price4.setVisible(false);
            back1.setVisible(false);
            back2.setVisible(false);
            back3.setVisible(false);
            back4.setVisible(false);
            img1.setVisible(false);
            img2.setVisible(false);
            img3.setVisible(false);
            img4.setVisible(false);
            title1.setVisible(false);
            title2.setVisible(false);
            title3.setVisible(false);
            title4.setVisible(false);
            rem1.setVisible(false);
            rem2.setVisible(false);
            rem3.setVisible(false);
            rem4.setVisible(false);
            desc1.setVisible(false);
            desc2.setVisible(false);
            desc3.setVisible(false);
            desc4.setVisible(false);
            cont1.setVisible(false);
            cont2.setVisible(false);
            cont3.setVisible(false);
            cont4.setVisible(false);
        }
        private void handleContribute(String contribution, String friendUsername, String titleText, int num) {
        try {
            Socket SS = new Socket("localhost", 7001);
            PrintWriter out = new PrintWriter(SS.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(SS.getInputStream()));
            String message = "contribute" + ":" + username + ":" + friendUsername + ":" + contribution + ":" + titleText;
            out.println(message);
            String response = in.readLine();
            if (response.equals("lowMoney")) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Insufficient Funds");
                alert.setHeaderText(null);
                alert.setContentText("You don't have enough cash for this contribution. Please charge your account.");
                alert.showAndWait();
            } else if (response.equals("fail")) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Contribution Failed");
                alert.setHeaderText(null);
                alert.setContentText("Sorry, a problem occurred while contributing. Please try again later.");
                alert.showAndWait();
            } else {
                int amount = Integer.parseInt(response);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Contribution Successful");
                alert.setHeaderText(null);
                alert.setContentText("You have contributed " + amount + " to your friend.");
                alert.showAndWait();
                int newMoneyInt = Integer.parseInt(currentMoney) - amount;
                currentMoney = Integer.toString(newMoneyInt);
                moneyText.setText(currentMoney);
                int remainMoney = Integer.parseInt(remain[num].getText()) - amount;
                remain[num].setText(Integer.toString(remainMoney));
            }
        } catch (IOException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("Error occurred, please try again later");
            alert.showAndWait();
        }
    }
    public void listingOfWishlist( String[] data  , ImageView[] backGround ,ImageView[] image,
                                Text[] title ,Text[] desc,Text[] price , 
                                Text[] remain  , ImageView[] cont)
    { 
            for (int i = 0; i < backGround.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String picTitle     = components[0];
                String picDesc      = components[1];
                String picPrice     = components[2];
                String picRemain    = components[3];
                String picID        = components[4];
 
                backGround[i].setVisible(true);
                image[i].setVisible(true);
                price[i].setVisible(true);
                remain[i].setVisible(true);
                cont[i].setVisible(true);

                
                title[i].setText(picTitle);
                title[i].setVisible(true);
                desc[i].setText(picDesc);
                desc[i].setVisible(true);
                price[i].setText(picPrice);
                price[i].setVisible(true);
                remain[i].setText(picRemain);
                remain[i].setVisible(true);
		image[i].setImage(new Image(getClass().getResource("AddItem/Devices/" + picID + ".png").toExternalForm()));
                image[i].setVisible(true);
                
            }
            Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });
    }
    	public void notificationView(  String response , Text[] notification )
    {       
	    String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    }
}

