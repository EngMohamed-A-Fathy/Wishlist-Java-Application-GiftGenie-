package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class helpScene extends BorderPane {
    String backGroundPic = null;
    
    protected final ImageView cashIcon;
    protected final Button CashButton;
    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView imageView4;
    protected final ImageView imageView5;
    protected final ImageView notificationIcon;
    protected final ImageView addMoney;
    protected final Button HomeButton;
    protected final Button MyWishlistButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button SettingButton;
    protected final Button HelpButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView aboutus;
    protected final ImageView aboutfriend;
    protected final ImageView aboutgift;
    protected final ImageView aboutmoney;
    protected final ImageView dialogpic;
    protected final Text text;
    protected final ImageView backButtn;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    
    boolean notificationTurn = true;
    
    public helpScene(Stage s, String username , String moneyValue , String backGroundPic) {
        
        this.backGroundPic = backGroundPic;

        anchorPane = new AnchorPane();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        imageView4 = new ImageView();
        imageView5 = new ImageView();
        notificationIcon = new ImageView();
        addMoney = new ImageView();
        HomeButton = new Button();
        MyWishlistButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        SettingButton = new Button();
        HelpButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        aboutus = new ImageView();
        aboutfriend = new ImageView();
        aboutgift = new ImageView();
        aboutmoney = new ImageView();
        dialogpic = new ImageView();
        text = new Text();
        backButtn = new ImageView();
        CashButton = new Button();
        cashIcon = new ImageView();
        notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();

        setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));

        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        cashIcon.setFitHeight(51.0);
        cashIcon.setFitWidth(59.0);
        cashIcon.setLayoutX(15.0);
        cashIcon.setLayoutY(260.0);
        cashIcon.setPickOnBounds(true);
        cashIcon.setPreserveRatio(true);
        cashIcon.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));
        
        imageView5.setFitHeight(61.0);
        imageView5.setFitWidth(65.0);
        imageView5.setLayoutX(18.0);
        imageView5.setLayoutY(134.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        addMoney.setFitHeight(42.0);
        addMoney.setFitWidth(41.0);
        addMoney.setLayoutX(975.0);
        addMoney.setLayoutY(8.0);
        addMoney.setPickOnBounds(true);
        addMoney.setPreserveRatio(true);
        addMoney.setCursor(Cursor.HAND);
        addMoney.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setFont(new Font("System Bold", 24.0));
        AddItemButton.setCursor(Cursor.HAND);
        notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);
        
        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setCursor(Cursor.HAND);
        FriendButton.setFont(new Font("System Bold", 24.0));
        
        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));

        imageView3.setFitHeight(51.0);
        imageView3.setFitWidth(59.0);
        imageView3.setLayoutX(17.0);
        imageView3.setLayoutY(316.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setCursor(Cursor.HAND);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView4.setFitHeight(51.0);
        imageView4.setFitWidth(59.0);
        imageView4.setLayoutX(19.0);
        imageView4.setLayoutY(378.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setFont(new Font("System Bold", 24.0));
        setCenter(anchorPane);

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));

        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));

        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        aboutus.setFitHeight(180.0);
        aboutus.setFitWidth(180.0);
        aboutus.setLayoutX(400.0);
        aboutus.setLayoutY(100.0);
        aboutus.setPickOnBounds(true);
        aboutus.setPreserveRatio(true);
        aboutus.setCursor(Cursor.HAND);
        aboutus.setImage(new Image(getClass().getResource("help/11.png").toExternalForm()));

        aboutfriend.setFitHeight(180.0);
        aboutfriend.setFitWidth(180.0);
        aboutfriend.setLayoutX(800.0);
        aboutfriend.setLayoutY(100.0);
        aboutfriend.setPickOnBounds(true);
        aboutfriend.setPreserveRatio(true);
        aboutfriend.setCursor(Cursor.HAND);
        aboutfriend.setImage(new Image(getClass().getResource("help/22.png").toExternalForm()));

        aboutgift.setFitHeight(200.0);
        aboutgift.setFitWidth(200.0);
        aboutgift.setLayoutX(400.0);
        aboutgift.setLayoutY(380.0);
        aboutgift.setPickOnBounds(true);
        aboutgift.setPreserveRatio(true);
        aboutgift.setCursor(Cursor.HAND);
        aboutgift.setImage(new Image(getClass().getResource("help/44.png").toExternalForm()));

        aboutmoney.setFitHeight(180.0);
        aboutmoney.setFitWidth(180.0);
        aboutmoney.setLayoutX(800.0);
        aboutmoney.setLayoutY(380.0);
        aboutmoney.setPickOnBounds(true);
        aboutmoney.setPreserveRatio(true);
        aboutmoney.setCursor(Cursor.HAND);
        aboutmoney.setImage(new Image(getClass().getResource("help/33.png").toExternalForm()));

        dialogpic.setFitHeight(397.0);
        dialogpic.setFitWidth(686.0);
        dialogpic.setLayoutX(379.0);
        dialogpic.setLayoutY(250.0);
        dialogpic.setPickOnBounds(true);
        dialogpic.setPreserveRatio(true);
        dialogpic.setVisible(false);
        dialogpic.setImage(new Image(getClass().getResource("help/Dialog.png").toExternalForm()));

        text.setLayoutX(565.0);
        text.setLayoutY(330.0);
        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setText("hello");
        text.setVisible(false);
        text.setWrappingWidth(296.13671875);

        backButtn.setFitHeight(60.0);
        backButtn.setFitWidth(68.0);
        backButtn.setLayoutX(1030.0);
        backButtn.setLayoutY(579.0);
        backButtn.setPickOnBounds(true);
        backButtn.setPreserveRatio(true);
        backButtn.setVisible(false);
        backButtn.setCursor(Cursor.HAND);
        backButtn.setImage(new Image(getClass().getResource("help/back.png").toExternalForm()));
        setCenter(anchorPane);

        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(addMoney);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(aboutus);
        anchorPane.getChildren().add(aboutfriend);
        anchorPane.getChildren().add(aboutgift);
        anchorPane.getChildren().add(aboutmoney);
        anchorPane.getChildren().add(dialogpic);
        anchorPane.getChildren().add(text);
        anchorPane.getChildren().add(backButtn);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(cashIcon);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);
        
        moneyText.setText(moneyValue);
        nameText.setText(username);
        nameText.setTextAlignment(TextAlignment.CENTER);
        
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;"); 
                });
        HomeButton.setOnAction(e -> {
             try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue ,backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        FriendButton.setOnMouseEntered(e -> {
                    FriendButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnMouseExited(e -> {
                    FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchFriendsScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addMoney.setOnMouseClicked(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddItemButton.setOnMouseEntered(e -> {
                    AddItemButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        AddItemButton.setOnMouseExited(e -> {
                    AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        AddItemButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchAddItemScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        aboutus.setOnMouseEntered(e -> {
                aboutus.setFitHeight(220.0);
                aboutus.setFitWidth(220.0);
                     });
        aboutus.setOnMouseExited(e -> {
                aboutus.setFitHeight(180.0);
                aboutus.setFitWidth(180.0);                    
                });
        aboutus.setOnMouseClicked(e -> {
            // Set all other pictures to invisible
            aboutfriend.setVisible(false);
            aboutgift.setVisible(false);
            aboutmoney.setVisible(false);
            backButtn.setVisible(true);
            dialogpic.setVisible(true);
            text.setVisible(true);
            text.setText("Three talented data engineers have come together to create a groundbreaking wishlist application that helps people select the perfect gifts for each other. With the aim of increasing social bonds between individuals, the app allows users to create and share their wishlists with friends and family, enabling them to make more meaningful and personalized gifts.");
            
        });
        
        if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        
        aboutfriend.setOnMouseEntered(e -> {
                aboutfriend.setFitHeight(220.0);
                aboutfriend.setFitWidth(220.0);
                     });
        aboutfriend.setOnMouseExited(e -> {
                aboutfriend.setFitHeight(180.0);
                aboutfriend.setFitWidth(180.0);                    
                });
        aboutfriend.setOnMouseClicked(e -> {
            aboutus.setVisible(false);
            aboutgift.setVisible(false);
            aboutmoney.setVisible(false);
            aboutfriend.setLayoutX(400.0);
            aboutfriend.setLayoutY(100.0);
            backButtn.setVisible(true);
            dialogpic.setVisible(true);
            text.setVisible(true);
            text.setText("we provide a user-friendly friend list handling feature that allows users to connect with their friends, keep track of their friend's wishlists. Our goal is to enhance social connections and make gifting more personalized and enjoyable. Users can easily view their friends' wishlists and get inspired to give meaningful gifts that reflect their interests and preferences.");
            
        });
        
        aboutgift.setOnMouseEntered(e -> {
                aboutgift.setFitHeight(220.0);
                aboutgift.setFitWidth(220.0);
                     });
        aboutgift.setOnMouseExited(e -> {
                aboutgift.setFitHeight(180.0);
                aboutgift.setFitWidth(180.0);                    
                });
        aboutgift.setOnMouseClicked(e -> {
            aboutus.setVisible(false);
            aboutfriend.setVisible(false);
            aboutmoney.setVisible(false);
            aboutgift.setLayoutX(400.0);
            aboutgift.setLayoutY(100.0);
            backButtn.setVisible(true);
            dialogpic.setVisible(true);
            text.setVisible(true);
            text.setText("Handling fits in Gift Genie is easy and hassle-free, You can add anything you desire from our items to your wishlist, which is linked to e-commerce websites for easy access, You can also donate to other users in need by contributing any amount you want. With the easy-to-use gifting system, Gift Genie helps people connect and share their wishes with their loved ones.");
            
        });
        
        aboutmoney.setOnMouseEntered(e -> {
                aboutmoney.setFitHeight(220.0);
                aboutmoney.setFitWidth(220.0);
                     });
        aboutmoney.setOnMouseExited(e -> {
                aboutmoney.setFitHeight(180.0);
                aboutmoney.setFitWidth(180.0);                    
                });
        aboutmoney.setOnMouseClicked(e -> {
            aboutus.setVisible(false);
            aboutfriend.setVisible(false);
            aboutgift.setVisible(false);
            aboutmoney.setLayoutX(400.0);
            aboutmoney.setLayoutY(100.0);
            backButtn.setVisible(true);
            dialogpic.setVisible(true);
            text.setVisible(true);
            text.setText("Gift Genie takes gift-giving to the next level with its innovative money handling system. You can donate to your friend's wishlists with your Visa card or play our exciting games to earn real money and gift it to your loved ones. Our games are not just fun, but also a great way to spread joy and love. So, come join the fun and surprise your friends with the perfect gifts! ");
            
        });
        
        backButtn.setOnMouseClicked(e -> {
            aboutfriend.setVisible(true);
            aboutgift.setVisible(true);
            aboutmoney.setVisible(true);
            aboutus.setVisible(true);
            backButtn.setVisible(false);
            dialogpic.setVisible(false);
            text.setVisible(false);
            
            aboutus.setLayoutX(400.0);
            aboutus.setLayoutY(100.0);
            aboutfriend.setLayoutX(800.0);
            aboutfriend.setLayoutY(100.0);
            aboutgift.setLayoutX(400.0);
            aboutgift.setLayoutY(380.0);
            aboutmoney.setLayoutX(800.0);
            aboutmoney.setLayoutY(380.0);
            
        });
       Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        }); 
        
        
        
    }
   public void notificationView(  String response , Text[] notification )
    {       String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    } 
    
}
