package giftgenie;

import java.io.IOException;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ButtonSwitcher {
    private Stage stage;
    private String username;
    private String moneyValue;
    private String backGroundPic ;
    private String friendUsername ;
    public ButtonSwitcher(Stage s, String username, String moneyValue , String pic, String friendUsername) throws IOException {
        this.stage = s;
        this.username = username;
        this.moneyValue = moneyValue;
        this.backGroundPic = pic; 
        this.friendUsername = friendUsername; 
    }
    public ButtonSwitcher(Stage s, String username, String moneyValue , String pic) throws IOException {
        this.stage = s;
        this.username = username;
        this.moneyValue = moneyValue;
        this.backGroundPic = pic; 
    }
    public ButtonSwitcher(Stage s, String username, String moneyValue ) throws IOException {
        this.stage = s;
        this.username = username;
        this.moneyValue = moneyValue;
    }

    public void switchHelpScene() {
        Parent rootsignup = new helpScene(stage, username, moneyValue , backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchHomeScene() {
        Parent rootsignup = new appScene(stage, username , backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchMoneyScene() {
        Parent rootsignup = new moneyScene(stage, username, moneyValue , backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchFriendsScene() {
        Parent rootsignup = new friendScene(stage, username, moneyValue, backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchWishlistScene() {
        Parent rootsignup = new Wishlist(stage, username, moneyValue , backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchWishlistFriendScene() {
        Parent rootsignup = new WishlistFriend(stage, username, moneyValue , backGroundPic , friendUsername);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchAddFriendScene() {
        Parent rootsignup = new addFriend(stage, username, moneyValue , backGroundPic );
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchFriendRequestScene() {
        Parent rootsignup = new friendRequest(stage, username, moneyValue , backGroundPic );
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchSettingScene() {
        Parent rootsignup = new SettingScene(stage, username, moneyValue , backGroundPic );
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchGameScene() {
        Parent rootsignup = new gameScene(stage, username, moneyValue , backGroundPic );
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchAddItemScene() {
        Parent rootsignup = new AddItemScene(stage, username, moneyValue , backGroundPic);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
    public void switchSignOut() {
        Parent rootsignup = new LoginScene(stage);
        Scene scene = new Scene(rootsignup);
        stage.setScene(scene);
    }
}
