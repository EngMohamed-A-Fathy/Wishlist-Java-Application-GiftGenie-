package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class friendScene extends BorderPane {
    String backGroundPic = null;
    String currentMoney;
    
    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView notificationIcon;
    protected final ImageView imageView4;
    protected final Button MyWishlistButton;
    protected final Button HomeButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView imageView_1;
    protected final ImageView imageView_2;
    protected final ImageView imageView_3;
    protected final ImageView imageView_4;
    protected final ImageView imageView_5;
    protected final ImageView imageView_6;
    protected final ImageView imageView_7;
    protected final ImageView imageView_8;
    protected final ImageView imageView_9;
    protected final ImageView imageView_10;
    protected final ImageView trash_1;
    protected final ImageView wish_1;
    protected final ImageView trash_2;
    protected final ImageView wish_2;
    protected final ImageView trash_3;
    protected final ImageView wish_3;
    protected final ImageView trash_4;
    protected final ImageView wish_4;
    protected final ImageView trash_5;
    protected final ImageView wish_5;
    protected final ImageView trash_6;
    protected final ImageView wish_6;
    protected final ImageView trash_7;
    protected final ImageView wish_7;
    protected final ImageView trash_8;
    protected final ImageView wish_8;
    protected final ImageView trash_9;
    protected final ImageView wish_9;
    protected final ImageView trash_10;
    protected final ImageView wish_10;
    protected final Label lbl_1;
    protected final Label lbl_2;
    protected final Label lbl_3;
    protected final Label lbl_4;
    protected final Label lbl_5;
    protected final Label lbl_6;
    protected final Label lbl_7;
    protected final Label lbl_8;
    protected final Label lbl_9;
    protected final Label lbl_10;
    protected final Label lbl_11;
    protected final Label lbl_12;
    protected final Label lbl_13;
    protected final Label lbl_14;
    protected final Label lbl_15;
    protected final Label lbl_16;
    protected final Label lbl_17;
    protected final Label lbl_18;
    protected final Label lbl_19;
    protected final Label lbl_20;
    protected final Label lbl_21;
    protected final Label lbl_22;
    protected final Label lbl_23;
    protected final Label lbl_24;
    protected final Label lbl_25;
    protected final Label lbl_26;
    protected final Label lbl_27;
    protected final Label lbl_28;
    protected final Label lbl_29;
    protected final Label lbl_30;
    protected final Label lbl_31;
    protected final Label lbl_32;
    protected final Label lbl_33;
    protected final Label lbl_34;
    protected final Label lbl_35;
    protected final Label lbl_36;
    protected final Label lbl_37;
    protected final Label lbl_38;
    protected final Label lbl_39;
    protected final Label lbl_40;
    protected final ImageView imageView5;
    protected final Button CashButton;
    protected final ImageView imageView6;
    protected final Button SettingButton;
    protected final ImageView imageView7;
    protected final Button HelpButton;
    protected final ImageView friendRequestImage;
    protected final ImageView addFriendImage;
    protected final ImageView welcome;
    protected final ImageView labelpic4;
    protected final ImageView labelpic3;
    protected final ImageView labelpic2;
    protected final ImageView labelpic1;
    protected final Label lbl_username;
    protected final Label lbl_name;
    protected final Label lbl_birthdate;
    protected final Label lbl_phone;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    protected final ImageView next;
    protected final ImageView backButt;
    
    boolean notificationTurn = true;
    Stage s;
    String moneyValue;
    int round = 1;
    String[][] arr ;
    
    public friendScene(Stage s, String username , String moneyValue , String pic) {
        this.s = s;
        this.moneyValue = moneyValue;
        backGroundPic = pic;
        currentMoney = moneyValue;
        
        anchorPane = new AnchorPane();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        notificationIcon = new ImageView();
        imageView4 = new ImageView();
        MyWishlistButton = new Button();
        HomeButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        imageView_1 = new ImageView();
        imageView_2 = new ImageView();
        imageView_3 = new ImageView();
        imageView_4 = new ImageView();
        imageView_5 = new ImageView();
        imageView_6 = new ImageView();
        imageView_7 = new ImageView();
        imageView_8 = new ImageView();
        imageView_9 = new ImageView();
        imageView_10 = new ImageView();
        trash_1 = new ImageView();
        wish_1 = new ImageView();
        trash_2 = new ImageView();
        wish_2 = new ImageView();
        trash_3 = new ImageView();
        wish_3 = new ImageView();
        trash_4 = new ImageView();
        wish_4 = new ImageView();
        trash_5 = new ImageView();
        wish_5 = new ImageView();
        trash_6 = new ImageView();
        wish_6 = new ImageView();
        trash_7 = new ImageView();
        wish_7 = new ImageView();
        trash_8 = new ImageView();
        wish_8 = new ImageView();
        trash_9 = new ImageView();
        wish_9 = new ImageView();
        trash_10 = new ImageView();
        wish_10 = new ImageView();
        lbl_1 = new Label();
        lbl_2 = new Label();
        lbl_3 = new Label();
        lbl_4 = new Label();
        lbl_5 = new Label();
        lbl_6 = new Label();
        lbl_7 = new Label();
        lbl_8 = new Label();
        lbl_9 = new Label();
        lbl_10 = new Label();
        lbl_11 = new Label();
        lbl_12 = new Label();
        lbl_13 = new Label();
        lbl_14 = new Label();
        lbl_15 = new Label();
        lbl_16 = new Label();
        lbl_17 = new Label();
        lbl_18 = new Label();
        lbl_19 = new Label();
        lbl_20 = new Label();
        lbl_21 = new Label();
        lbl_22 = new Label();
        lbl_23 = new Label();
        lbl_24 = new Label();
        lbl_25 = new Label();
        lbl_26 = new Label();
        lbl_27 = new Label();
        lbl_28 = new Label();
        lbl_29 = new Label();
        lbl_30 = new Label();
        lbl_31 = new Label();
        lbl_32 = new Label();
        lbl_33 = new Label();
        lbl_34 = new Label();
        lbl_35 = new Label();
        lbl_36 = new Label();
        lbl_37 = new Label();
        lbl_38 = new Label();
        lbl_39 = new Label();
        lbl_40 = new Label();
        labelpic4 = new ImageView();
        labelpic3 = new ImageView();
        labelpic2 = new ImageView();
        labelpic1 = new ImageView();
        imageView5 = new ImageView();
        CashButton = new Button();
        imageView6 = new ImageView();
        SettingButton = new Button();
        imageView7 = new ImageView();
        HelpButton = new Button();
        friendRequestImage = new ImageView();
        addFriendImage = new ImageView();       
        welcome = new ImageView();
        lbl_username = new Label();
        lbl_name = new Label();
        lbl_birthdate = new Label();
        lbl_phone = new Label();
        notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();
        next = new ImageView();
        backButt = new ImageView();
        setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));
        labelpic4.setFitHeight(79.0);
        labelpic4.setFitWidth(76.0);
        labelpic4.setLayoutX(700.0);
        labelpic4.setLayoutY(79.0);
        labelpic4.setPickOnBounds(true);
        labelpic4.setPreserveRatio(true);
        labelpic4.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));

        labelpic3.setFitHeight(79.0);
        labelpic3.setFitWidth(76.0);
        labelpic3.setLayoutX(593.0);
        labelpic3.setLayoutY(79.0);
        labelpic3.setPickOnBounds(true);
        labelpic3.setPreserveRatio(true);
        labelpic3.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));

        labelpic2.setFitHeight(79.0);
        labelpic2.setFitWidth(76.0);
        labelpic2.setLayoutX(420.0);
        labelpic2.setLayoutY(79.0);
        labelpic2.setPickOnBounds(true);
        labelpic2.setPreserveRatio(true);
        labelpic2.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));

        labelpic1.setFitHeight(79.0);
        labelpic1.setFitWidth(76.0);
        labelpic1.setLayoutX(325.0);
        labelpic1.setLayoutY(79.0);
        labelpic1.setPickOnBounds(true);
        labelpic1.setPreserveRatio(true);
        labelpic1.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));
        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        imageView3.setFitHeight(61.0);
        imageView3.setFitWidth(65.0);
        imageView3.setLayoutX(18.0);
        imageView3.setLayoutY(134.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        imageView4.setFitHeight(42.0);
        imageView4.setFitWidth(41.0);
        imageView4.setLayoutX(975.0);
        imageView4.setLayoutY(8.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setCursor(Cursor.HAND);
        AddItemButton.setFont(new Font("System Bold", 24.0));

        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setFont(new Font("System Bold", 24.0));

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));
        welcome.setFitHeight(101.0);
        welcome.setFitWidth(238.0);
        welcome.setLayoutX(314.0);
        welcome.setLayoutY(9.0);
        welcome.setPickOnBounds(true);
        welcome.setPreserveRatio(true);
        welcome.setImage(new Image(getClass().getResource("friends/welcomeFriend.png").toExternalForm()));
        setCenter(anchorPane);
        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));

        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        imageView_1.setFitHeight(45.0);
        imageView_1.setFitWidth(658.0);
        imageView_1.setLayoutX(300.0);
        imageView_1.setLayoutY(139.0);
        imageView_1.setPickOnBounds(true);
        imageView_1.setPreserveRatio(true);
        imageView_1.setVisible(false);
        imageView_1.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_2.setFitHeight(45.0);
        imageView_2.setFitWidth(730.0);
        imageView_2.setLayoutX(300.0);
        imageView_2.setLayoutY(189.0);
        imageView_2.setPickOnBounds(true);
        imageView_2.setPreserveRatio(true);
        imageView_2.setVisible(false);
        imageView_2.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_3.setFitHeight(45.0);
        imageView_3.setFitWidth(730.0);
        imageView_3.setLayoutX(300.0);
        imageView_3.setLayoutY(239.0);
        imageView_3.setPickOnBounds(true);
        imageView_3.setPreserveRatio(true);
        imageView_3.setVisible(false);
        imageView_3.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_4.setFitHeight(45.0);
        imageView_4.setFitWidth(730.0);
        imageView_4.setLayoutX(300.0);
        imageView_4.setLayoutY(289.0);
        imageView_4.setPickOnBounds(true);
        imageView_4.setPreserveRatio(true);
        imageView_4.setVisible(false);
        imageView_4.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_5.setFitHeight(45.0);
        imageView_5.setFitWidth(730.0);
        imageView_5.setLayoutX(300.0);
        imageView_5.setLayoutY(339.0);
        imageView_5.setPickOnBounds(true);
        imageView_5.setPreserveRatio(true);
        imageView_5.setVisible(false);
        imageView_5.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_6.setFitHeight(45.0);
        imageView_6.setFitWidth(730.0);
        imageView_6.setLayoutX(300.0);
        imageView_6.setLayoutY(389.0);
        imageView_6.setPickOnBounds(true);
        imageView_6.setPreserveRatio(true);
        imageView_6.setVisible(false);
        imageView_6.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_7.setFitHeight(45.0);
        imageView_7.setFitWidth(730.0);
        imageView_7.setLayoutX(300.0);
        imageView_7.setLayoutY(439.0);
        imageView_7.setPickOnBounds(true);
        imageView_7.setPreserveRatio(true);
        imageView_7.setVisible(false);
        imageView_7.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_8.setFitHeight(45.0);
        imageView_8.setFitWidth(730.0);
        imageView_8.setLayoutX(300.0);
        imageView_8.setLayoutY(489.0);
        imageView_8.setPickOnBounds(true);
        imageView_8.setPreserveRatio(true);
        imageView_8.setVisible(false);
        imageView_8.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_9.setFitHeight(45.0);
        imageView_9.setFitWidth(730.0);
        imageView_9.setLayoutX(300.0);
        imageView_9.setLayoutY(539.0);
        imageView_9.setPickOnBounds(true);
        imageView_9.setPreserveRatio(true);
        imageView_9.setVisible(false);
        imageView_9.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_10.setFitHeight(45.0);
        imageView_10.setFitWidth(730.0);
        imageView_10.setLayoutX(300.0);
        imageView_10.setLayoutY(589.0);
        imageView_10.setPickOnBounds(true);
        imageView_10.setPreserveRatio(true);
        imageView_10.setVisible(false);
        imageView_10.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));
        
        lbl_username.setLayoutX(330.0);
        lbl_username.setLayoutY(107.0);
        lbl_username.setText("Username");
        lbl_username.setFont(new Font("System Bold", 14.0));

        lbl_name.setLayoutX(440.0);
        lbl_name.setLayoutY(107.0);
        lbl_name.setText("Name");
        lbl_name.setFont(new Font("System Bold", 14.0));

        lbl_birthdate.setLayoutX(600.0);
        lbl_birthdate.setLayoutY(107.0);
        lbl_birthdate.setText("birthdate");
        lbl_birthdate.setFont(new Font("System Bold", 14.0));

        lbl_phone.setLayoutX(720.0);
        lbl_phone.setLayoutY(107.0);
        lbl_phone.setText("phone");
        lbl_phone.setFont(new Font("System Bold", 14.0));

        trash_1.setFitHeight(28.0);
        trash_1.setFitWidth(24.0);
        trash_1.setLayoutX(870.0);
        trash_1.setLayoutY(149.0);
        trash_1.setPickOnBounds(true);
        trash_1.setPreserveRatio(true);
        trash_1.setVisible(false);
        trash_1.setCursor(Cursor.HAND);
        trash_1.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_1.setFitHeight(39.0);
        wish_1.setFitWidth(39.0);
        wish_1.setLayoutX(817.0);
        wish_1.setLayoutY(141.0);
        wish_1.setPickOnBounds(true);
        wish_1.setPreserveRatio(true);
        wish_1.setVisible(false);
        wish_1.setCursor(Cursor.HAND);
        wish_1.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_2.setFitHeight(28.0);
        trash_2.setFitWidth(24.0);
        trash_2.setLayoutX(870.0);
        trash_2.setLayoutY(198.0);
        trash_2.setPickOnBounds(true);
        trash_2.setPreserveRatio(true);
        trash_2.setVisible(false);
        trash_2.setCursor(Cursor.HAND);
        trash_2.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_2.setFitHeight(39.0);
        wish_2.setFitWidth(39.0);
        wish_2.setLayoutX(817.0);
        wish_2.setLayoutY(190.0);
        wish_2.setPickOnBounds(true);
        wish_2.setPreserveRatio(true);
        wish_2.setVisible(false);
        wish_2.setCursor(Cursor.HAND);
        wish_2.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_3.setFitHeight(28.0);
        trash_3.setFitWidth(24.0);
        trash_3.setLayoutX(870.0);
        trash_3.setLayoutY(248.0);
        trash_3.setPickOnBounds(true);
        trash_3.setPreserveRatio(true);
        trash_3.setVisible(false);
        trash_3.setCursor(Cursor.HAND);
        trash_3.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_3.setFitHeight(39.0);
        wish_3.setFitWidth(39.0);
        wish_3.setLayoutX(817.0);
        wish_3.setLayoutY(240.0);
        wish_3.setPickOnBounds(true);
        wish_3.setPreserveRatio(true);
        wish_3.setVisible(false);
        wish_3.setCursor(Cursor.HAND);
        wish_3.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_4.setFitHeight(28.0);
        trash_4.setFitWidth(24.0);
        trash_4.setLayoutX(870.0);
        trash_4.setLayoutY(298.0);
        trash_4.setPickOnBounds(true);
        trash_4.setPreserveRatio(true);
        trash_4.setVisible(false);
        trash_4.setCursor(Cursor.HAND);
        trash_4.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_4.setFitHeight(39.0);
        wish_4.setFitWidth(39.0);
        wish_4.setLayoutX(817.0);
        wish_4.setLayoutY(290.0);
        wish_4.setPickOnBounds(true);
        wish_4.setPreserveRatio(true);
        wish_4.setVisible(false);
        wish_4.setCursor(Cursor.HAND);
        wish_4.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_5.setFitHeight(28.0);
        trash_5.setFitWidth(24.0);
        trash_5.setLayoutX(871.0);
        trash_5.setLayoutY(348.0);
        trash_5.setPickOnBounds(true);
        trash_5.setPreserveRatio(true);
        trash_5.setVisible(false);
        trash_5.setCursor(Cursor.HAND);
        trash_5.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_5.setFitHeight(39.0);
        wish_5.setFitWidth(39.0);
        wish_5.setLayoutX(818.0);
        wish_5.setLayoutY(340.0);
        wish_5.setPickOnBounds(true);
        wish_5.setPreserveRatio(true);
        wish_5.setVisible(false);
        wish_5.setCursor(Cursor.HAND);
        wish_5.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_6.setFitHeight(28.0);
        trash_6.setFitWidth(24.0);
        trash_6.setLayoutX(869.0);
        trash_6.setLayoutY(397.0);
        trash_6.setPickOnBounds(true);
        trash_6.setPreserveRatio(true);
        trash_6.setVisible(false);
        trash_6.setCursor(Cursor.HAND);
        trash_6.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_6.setFitHeight(39.0);
        wish_6.setFitWidth(39.0);
        wish_6.setLayoutX(816.0);
        wish_6.setLayoutY(389.0);
        wish_6.setPickOnBounds(true);
        wish_6.setPreserveRatio(true);
        wish_6.setVisible(false);
        wish_6.setCursor(Cursor.HAND);
        wish_6.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_7.setFitHeight(28.0);
        trash_7.setFitWidth(24.0);
        trash_7.setLayoutX(870.0);
        trash_7.setLayoutY(448.0);
        trash_7.setPickOnBounds(true);
        trash_7.setPreserveRatio(true);
        trash_7.setVisible(false);
        trash_7.setCursor(Cursor.HAND);
        trash_7.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_7.setFitHeight(39.0);
        wish_7.setFitWidth(39.0);
        wish_7.setLayoutX(817.0);
        wish_7.setLayoutY(440.0);
        wish_7.setPickOnBounds(true);
        wish_7.setPreserveRatio(true);
        wish_7.setVisible(false);
        wish_7.setCursor(Cursor.HAND);
        wish_7.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_8.setFitHeight(28.0);
        trash_8.setFitWidth(24.0);
        trash_8.setLayoutX(870.0);
        trash_8.setLayoutY(498.0);
        trash_8.setPickOnBounds(true);
        trash_8.setPreserveRatio(true);
        trash_8.setVisible(false);
        trash_8.setCursor(Cursor.HAND);
        trash_8.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_8.setFitHeight(39.0);
        wish_8.setFitWidth(39.0);
        wish_8.setLayoutX(817.0);
        wish_8.setLayoutY(490.0);
        wish_8.setPickOnBounds(true);
        wish_8.setPreserveRatio(true);
        wish_8.setVisible(false);
        wish_8.setCursor(Cursor.HAND);
        wish_8.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        trash_9.setFitHeight(28.0);
        trash_9.setFitWidth(24.0);
        trash_9.setLayoutX(870.0);
        trash_9.setLayoutY(548.0);
        trash_9.setPickOnBounds(true);
        trash_9.setPreserveRatio(true);
        trash_9.setVisible(false);
        trash_9.setCursor(Cursor.HAND);
        trash_9.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));

        wish_9.setFitHeight(39.0);
        wish_9.setFitWidth(39.0);
        wish_9.setLayoutX(817.0);
        wish_9.setLayoutY(540.0);
        wish_9.setPickOnBounds(true);
        wish_9.setPreserveRatio(true);
        wish_9.setVisible(false);
        wish_9.setCursor(Cursor.HAND);
        wish_9.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

 
        trash_10.setFitHeight(28.0);
        trash_10.setFitWidth(24.0);
        trash_10.setLayoutX(869.0);
        trash_10.setLayoutY(597.0);
        trash_10.setPickOnBounds(true);
        trash_10.setPreserveRatio(true);
        trash_10.setVisible(false);
        trash_10.setCursor(Cursor.HAND);
        trash_10.setImage(new Image(getClass().getResource("trash.png").toExternalForm()));
        
        next.setFitHeight(50.0);
        next.setFitWidth(74.0);
        next.setLayoutX(1032.0);
        next.setLayoutY(586.0);
        next.setPickOnBounds(true);
        next.setPreserveRatio(true);
        next.setCursor(Cursor.HAND);
        next.setImage(new Image(getClass().getResource("Wishlist/Next.png").toExternalForm()));

        backButt.setFitHeight(50.0);
        backButt.setFitWidth(74.0);
        backButt.setLayoutX(978.0);
        backButt.setLayoutY(586.0);
        backButt.setPickOnBounds(true);
        backButt.setPreserveRatio(true);
        backButt.setCursor(Cursor.HAND);
        backButt.setImage(new Image(getClass().getResource("Wishlist/Back.png").toExternalForm()));
        wish_10.setFitHeight(39.0);
        wish_10.setFitWidth(39.0);
        wish_10.setLayoutX(816.0);
        wish_10.setLayoutY(589.0);
        wish_10.setPickOnBounds(true);
        wish_10.setPreserveRatio(true);
        wish_10.setVisible(false);
        wish_10.setCursor(Cursor.HAND);
        wish_10.setImage(new Image(getClass().getResource("wishlist.png").toExternalForm()));

        

        lbl_1.setLayoutX(334.0);
        lbl_1.setLayoutY(150.0);
        lbl_1.setText("phone");
        lbl_1.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_1.setVisible(false);
        lbl_1.setFont(new Font("System Bold", 14.0));

        lbl_2.setLayoutX(334.0);
        lbl_2.setLayoutY(200.0);
        lbl_2.setText("phone");
        lbl_2.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_2.setVisible(false);
        lbl_2.setFont(new Font("System Bold", 14.0));

        lbl_3.setLayoutX(334.0);
        lbl_3.setLayoutY(250.0);
        lbl_3.setText("phone");
        lbl_3.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_3.setVisible(false);
        lbl_3.setFont(new Font("System Bold", 14.0));

        lbl_4.setLayoutX(334.0);
        lbl_4.setLayoutY(300.0);
        lbl_4.setText("phone");
        lbl_4.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_4.setVisible(false);
        lbl_4.setFont(new Font("System Bold", 14.0));

        lbl_5.setLayoutX(334.0);
        lbl_5.setLayoutY(350.0);
        lbl_5.setText("phone");
        lbl_5.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_5.setVisible(false);
        lbl_5.setFont(new Font("System Bold", 14.0));

        lbl_6.setLayoutX(334.0);
        lbl_6.setLayoutY(400.0);
        lbl_6.setText("phone");
        lbl_6.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_6.setVisible(false);
        lbl_6.setFont(new Font("System Bold", 14.0));

        lbl_7.setLayoutX(334.0);
        lbl_7.setLayoutY(450.0);
        lbl_7.setText("phone");
        lbl_7.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_7.setVisible(false);
        lbl_7.setFont(new Font("System Bold", 14.0));

        lbl_8.setLayoutX(334.0);
        lbl_8.setLayoutY(500.0);
        lbl_8.setText("phone");
        lbl_8.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_8.setVisible(false);
        lbl_8.setFont(new Font("System Bold", 14.0));

        lbl_9.setLayoutX(334.0);
        lbl_9.setLayoutY(550.0);
        lbl_9.setText("phone");
        lbl_9.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_9.setVisible(false);
        lbl_9.setFont(new Font("System Bold", 14.0));

        lbl_10.setLayoutX(334.0);
        lbl_10.setLayoutY(600.0);
        lbl_10.setText("phone");
        lbl_10.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_10.setVisible(false);
        lbl_10.setFont(new Font("System Bold", 14.0));

        lbl_11.setLayoutX(431.0);
        lbl_11.setLayoutY(150.0);
        lbl_11.setText("Abdelaziz");
        lbl_11.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_11.setVisible(false);
        lbl_11.setFont(new Font("System Bold", 14.0));

        lbl_12.setLayoutX(431.0);
        lbl_12.setLayoutY(200.0);
        lbl_12.setText("Abdelaziz");
        lbl_12.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_12.setVisible(false);
        lbl_12.setFont(new Font("System Bold", 14.0));

        lbl_13.setLayoutX(431.0);
        lbl_13.setLayoutY(250.0);
        lbl_13.setText("Abdelaziz");
        lbl_13.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_13.setVisible(false);
        lbl_13.setFont(new Font("System Bold", 14.0));

        lbl_14.setLayoutX(431.0);
        lbl_14.setLayoutY(300.0);
        lbl_14.setText("Abdelaziz");
        lbl_14.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_14.setVisible(false);
        lbl_14.setFont(new Font("System Bold", 14.0));

        lbl_15.setLayoutX(431.0);
        lbl_15.setLayoutY(350.0);
        lbl_15.setText("Abdelaziz");
        lbl_15.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_15.setVisible(false);
        lbl_15.setFont(new Font("System Bold", 14.0));

        lbl_16.setLayoutX(431.0);
        lbl_16.setLayoutY(400.0);
        lbl_16.setText("Abdelaziz");
        lbl_16.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_16.setVisible(false);
        lbl_16.setFont(new Font("System Bold", 14.0));

        lbl_17.setLayoutX(431.0);
        lbl_17.setLayoutY(450.0);
        lbl_17.setText("Abdelaziz");
        lbl_17.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_17.setVisible(false);
        lbl_17.setFont(new Font("System Bold", 14.0));

        lbl_18.setLayoutX(431.0);
        lbl_18.setLayoutY(500.0);
        lbl_18.setText("Abdelaziz");
        lbl_18.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_18.setVisible(false);
        lbl_18.setFont(new Font("System Bold", 14.0));

        lbl_19.setLayoutX(431.0);
        lbl_19.setLayoutY(550.0);
        lbl_19.setText("Abdelaziz");
        lbl_19.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_19.setVisible(false);
        lbl_19.setFont(new Font("System Bold", 14.0));

        lbl_20.setLayoutX(431.0);
        lbl_20.setLayoutY(600.0);
        lbl_20.setText("Abdelaziz");
        lbl_20.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_20.setVisible(false);
        lbl_20.setFont(new Font("System Bold", 14.0));

        lbl_21.setLayoutX(600.0);
        lbl_21.setLayoutY(150.0);
        lbl_21.setText("phone");
        lbl_21.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_21.setVisible(false);
        lbl_21.setFont(new Font("System Bold", 14.0));

        lbl_22.setLayoutX(600.0);
        lbl_22.setLayoutY(200.0);
        lbl_22.setText("phone");
        lbl_22.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_22.setVisible(false);
        lbl_22.setFont(new Font("System Bold", 14.0));

        lbl_23.setLayoutX(600.0);
        lbl_23.setLayoutY(250.0);
        lbl_23.setText("phone");
        lbl_23.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_23.setVisible(false);
        lbl_23.setFont(new Font("System Bold", 14.0));

        lbl_24.setLayoutX(600.0);
        lbl_24.setLayoutY(300.0);
        lbl_24.setText("phone");
        lbl_24.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_24.setVisible(false);
        lbl_24.setFont(new Font("System Bold", 14.0));

        lbl_25.setLayoutX(600.0);
        lbl_25.setLayoutY(350.0);
        lbl_25.setText("phone");
        lbl_25.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_25.setVisible(false);
        lbl_25.setFont(new Font("System Bold", 14.0));

        lbl_26.setLayoutX(600.0);
        lbl_26.setLayoutY(400.0);
        lbl_26.setText("phone");
        lbl_26.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_26.setVisible(false);
        lbl_26.setFont(new Font("System Bold", 14.0));

        lbl_27.setLayoutX(600.0);
        lbl_27.setLayoutY(450.0);
        lbl_27.setText("phone");
        lbl_27.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_27.setVisible(false);
        lbl_27.setFont(new Font("System Bold", 14.0));

        lbl_28.setLayoutX(600.0);
        lbl_28.setLayoutY(500.0);
        lbl_28.setText("phone");
        lbl_28.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_28.setVisible(false);
        lbl_28.setFont(new Font("System Bold", 14.0));

        lbl_29.setLayoutX(600.0);
        lbl_29.setLayoutY(550.0);
        lbl_29.setText("phone");
        lbl_29.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_29.setVisible(false);
        lbl_29.setFont(new Font("System Bold", 14.0));

        lbl_30.setLayoutX(600.0);
        lbl_30.setLayoutY(600.0);
        lbl_30.setText("phone");
        lbl_30.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_30.setVisible(false);
        lbl_30.setFont(new Font("System Bold", 14.0));

        lbl_31.setLayoutX(718.0);
        lbl_31.setLayoutY(150.0);
        lbl_31.setText("phone");
        lbl_31.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_31.setVisible(false);
        lbl_31.setFont(new Font("System Bold", 14.0));

        lbl_32.setLayoutX(718.0);
        lbl_32.setLayoutY(200.0);
        lbl_32.setText("phone");
        lbl_32.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_32.setVisible(false);
        lbl_32.setFont(new Font("System Bold", 14.0));

        lbl_33.setLayoutX(718.0);
        lbl_33.setLayoutY(250.0);
        lbl_33.setText("phone");
        lbl_33.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_33.setVisible(false);
        lbl_33.setFont(new Font("System Bold", 14.0));

        lbl_34.setLayoutX(718.0);
        lbl_34.setLayoutY(300.0);
        lbl_34.setText("phone");
        lbl_34.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_34.setVisible(false);
        lbl_34.setFont(new Font("System Bold", 14.0));

        lbl_35.setLayoutX(718.0);
        lbl_35.setLayoutY(350.0);
        lbl_35.setText("phone");
        lbl_35.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_35.setVisible(false);
        lbl_35.setFont(new Font("System Bold", 14.0));

        lbl_36.setLayoutX(718.0);
        lbl_36.setLayoutY(400.0);
        lbl_36.setText("phone");
        lbl_36.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_36.setVisible(false);
        lbl_36.setFont(new Font("System Bold", 14.0));

        lbl_37.setLayoutX(718.0);
        lbl_37.setLayoutY(450.0);
        lbl_37.setText("phone");
        lbl_37.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_37.setVisible(false);
        lbl_37.setFont(new Font("System Bold", 14.0));

        lbl_38.setLayoutX(718.0);
        lbl_38.setLayoutY(500.0);
        lbl_38.setText("phone");
        lbl_38.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_38.setVisible(false);
        lbl_38.setFont(new Font("System Bold", 14.0));

        lbl_39.setLayoutX(718.0);
        lbl_39.setLayoutY(550.0);
        lbl_39.setText("phone");
        lbl_39.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_39.setVisible(false);
        lbl_39.setFont(new Font("System Bold", 14.0));

        lbl_40.setLayoutX(718.0);
        lbl_40.setLayoutY(600.0);
        lbl_40.setText("phone");
        lbl_40.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_40.setVisible(false);
        lbl_40.setFont(new Font("System Bold", 14.0));

        imageView5.setFitHeight(51.0);
        imageView5.setFitWidth(59.0);
        imageView5.setLayoutX(15.0);
        imageView5.setLayoutY(260.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));

        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));

        imageView6.setFitHeight(51.0);
        imageView6.setFitWidth(59.0);
        imageView6.setLayoutX(17.0);
        imageView6.setLayoutY(316.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setCursor(Cursor.HAND);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView7.setFitHeight(51.0);
        imageView7.setFitWidth(59.0);
        imageView7.setLayoutX(19.0);
        imageView7.setLayoutY(378.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setFont(new Font("System Bold", 24.0));
        HelpButton.setCursor(Cursor.HAND);
        setCenter(anchorPane);

        friendRequestImage.setFitHeight(164.0);
        friendRequestImage.setFitWidth(40.0);
        friendRequestImage.setLayoutX(1061.0);
        friendRequestImage.setLayoutY(100.0);
        friendRequestImage.setPickOnBounds(true);
        friendRequestImage.setPreserveRatio(true);
        friendRequestImage.setCursor(Cursor.HAND);
        friendRequestImage.setImage(new Image(getClass().getResource("friendRequestImage.png").toExternalForm()));

        addFriendImage.setFitHeight(164.0);
        addFriendImage.setFitWidth(40.0);
        addFriendImage.setLayoutX(1063.0);
        addFriendImage.setLayoutY(250.0);
        addFriendImage.setPickOnBounds(true);
        addFriendImage.setPreserveRatio(true);
        addFriendImage.setCursor(Cursor.HAND);
        addFriendImage.setImage(new Image(getClass().getResource("addFriendImaga.png").toExternalForm()));
        setCenter(anchorPane);  
        notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);

        
        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(labelpic4);
        anchorPane.getChildren().add(labelpic3);
        anchorPane.getChildren().add(labelpic2);
        anchorPane.getChildren().add(labelpic1);
        anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(imageView_1);
        anchorPane.getChildren().add(imageView_2);
        anchorPane.getChildren().add(imageView_3);
        anchorPane.getChildren().add(imageView_4);
        anchorPane.getChildren().add(imageView_5);
        anchorPane.getChildren().add(imageView_6);
        anchorPane.getChildren().add(imageView_7);
        anchorPane.getChildren().add(imageView_8);
        anchorPane.getChildren().add(imageView_9);
        anchorPane.getChildren().add(imageView_10);
        anchorPane.getChildren().add(welcome);
        anchorPane.getChildren().add(trash_1);
        anchorPane.getChildren().add(wish_1);
        anchorPane.getChildren().add(trash_2);
        anchorPane.getChildren().add(wish_2);
        anchorPane.getChildren().add(trash_3);
        anchorPane.getChildren().add(wish_3);
        anchorPane.getChildren().add(trash_4);
        anchorPane.getChildren().add(wish_4);
        anchorPane.getChildren().add(trash_5);
        anchorPane.getChildren().add(wish_5);
        anchorPane.getChildren().add(trash_6);
        anchorPane.getChildren().add(wish_6);
        anchorPane.getChildren().add(trash_7);
        anchorPane.getChildren().add(wish_7);
        anchorPane.getChildren().add(trash_8);
        anchorPane.getChildren().add(wish_8);
        anchorPane.getChildren().add(trash_9);
        anchorPane.getChildren().add(wish_9);
        anchorPane.getChildren().add(trash_10);
        anchorPane.getChildren().add(wish_10);
        anchorPane.getChildren().add(lbl_1);
        anchorPane.getChildren().add(lbl_2);
        anchorPane.getChildren().add(lbl_3);
        anchorPane.getChildren().add(lbl_4);
        anchorPane.getChildren().add(lbl_5);
        anchorPane.getChildren().add(lbl_6);
        anchorPane.getChildren().add(lbl_7);
        anchorPane.getChildren().add(lbl_8);
        anchorPane.getChildren().add(lbl_9);
        anchorPane.getChildren().add(lbl_10);
        anchorPane.getChildren().add(lbl_11);
        anchorPane.getChildren().add(lbl_12);
        anchorPane.getChildren().add(lbl_13);
        anchorPane.getChildren().add(lbl_14);
        anchorPane.getChildren().add(lbl_15);
        anchorPane.getChildren().add(lbl_16);
        anchorPane.getChildren().add(lbl_17);
        anchorPane.getChildren().add(lbl_18);
        anchorPane.getChildren().add(lbl_19);
        anchorPane.getChildren().add(lbl_20);
        anchorPane.getChildren().add(lbl_21);
        anchorPane.getChildren().add(lbl_22);
        anchorPane.getChildren().add(lbl_23);
        anchorPane.getChildren().add(lbl_24);
        anchorPane.getChildren().add(lbl_25);
        anchorPane.getChildren().add(lbl_26);
        anchorPane.getChildren().add(lbl_27);
        anchorPane.getChildren().add(lbl_28);
        anchorPane.getChildren().add(lbl_29);
        anchorPane.getChildren().add(lbl_30);
        anchorPane.getChildren().add(lbl_31);
        anchorPane.getChildren().add(lbl_32);
        anchorPane.getChildren().add(lbl_33);
        anchorPane.getChildren().add(lbl_34);
        anchorPane.getChildren().add(lbl_35);
        anchorPane.getChildren().add(lbl_36);
        anchorPane.getChildren().add(lbl_37);
        anchorPane.getChildren().add(lbl_38);
        anchorPane.getChildren().add(lbl_39);
        anchorPane.getChildren().add(lbl_40);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(imageView6);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(imageView7);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(friendRequestImage);
        anchorPane.getChildren().add(addFriendImage);
        anchorPane.getChildren().add(lbl_username);
        anchorPane.getChildren().add(lbl_name);
        anchorPane.getChildren().add(lbl_birthdate);
        anchorPane.getChildren().add(lbl_phone);
        anchorPane.getChildren().add(next);
        anchorPane.getChildren().add(backButt);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);


        moneyText.setText(currentMoney);
        nameText.setText(username);
        if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");

                });
        
        HomeButton.setOnAction(e -> {
             try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        HelpButton.setOnMouseEntered(e -> {
                    HelpButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HelpButton.setOnMouseExited(e -> {
                    HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        HelpButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchHelpScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddItemButton.setOnMouseEntered(e -> {
                    AddItemButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        AddItemButton.setOnMouseExited(e -> {
                    AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        AddItemButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchAddItemScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });
        Socket socket;
        try {
            socket = new Socket("localhost", 7001);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            
            ImageView[] imageViews = {imageView_1, imageView_2, imageView_3, imageView_4,imageView_5,
                                      imageView_6, imageView_7,imageView_8, imageView_9, imageView_10};
                                      

            ImageView[] trashs     =    {trash_1, trash_2, trash_3, trash_4, trash_5,
                                         trash_6, trash_7, trash_8, trash_9, trash_10};

            ImageView[] wishlists  =   {wish_1, wish_2, wish_3, wish_4, wish_5,
                                        wish_6, wish_7, wish_8, wish_9, wish_10};

            Label[] userNameLabels =  {lbl_1, lbl_2, lbl_3, lbl_4, lbl_5,
                                       lbl_6, lbl_7, lbl_8, lbl_9, lbl_10};

            Label[] NameLabels     =  {lbl_11, lbl_12, lbl_13, lbl_14, lbl_15,
                                       lbl_16, lbl_17, lbl_18, lbl_19, lbl_20};

            Label[] birthDateLabels = {lbl_21, lbl_22, lbl_23, lbl_24, lbl_25,
                                       lbl_26, lbl_27, lbl_28, lbl_29, lbl_30};

            Label[] phoneLabels     =  {lbl_31, lbl_32, lbl_33, lbl_34, lbl_35,
                                       lbl_36, lbl_37, lbl_38, lbl_39, lbl_40};

             String request = "friend" + ":" + username;
             output.println(request);
             String inputString = input.readLine();
            if (inputString != null && !inputString.isEmpty() && !inputString.equals("no")) {
                String[] data = inputString.split("#");
                List<String[]> dataList = new ArrayList<>();
            if (data.length > 10) {
                int remaining = data.length;
                int index = 0;

                while (remaining > 0) {
                    int endIndex = Math.min(index + 10, data.length);
                    String[] subArray = Arrays.copyOfRange(data, index, endIndex);
                    dataList.add(subArray);
                    remaining -= subArray.length;
                    index += subArray.length;
                }
            } else {
                dataList.add(data);
            }
            
            int size = dataList.size();
            arr = new String[size][];

            for (int i = 0; i < size; i++) {
                    arr[i] = dataList.get(i);
            }
                listingOfFriend(arr[0] , imageViews ,trashs ,wishlists ,userNameLabels,NameLabels , birthDateLabels ,phoneLabels);
            }
            else {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[4].getText());
                buttonSwitcher.switchWishlistFriendScene();
            }
	next.setOnMouseClicked(event -> {
                if (round >= 1 && round < arr.length && arr[round] != null) {
                        clear();
                        listingOfFriend(arr[round], imageViews ,trashs ,wishlists ,userNameLabels,NameLabels , birthDateLabels ,phoneLabels);
                        round++;
                } else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION, "No more items to show!");
                        alert.showAndWait();
                }
        });
        backButt.setOnMouseClicked(event -> {
                if (round > 1)
                {round--;}

                if(round >= 1 && round < arr.length && arr[round] != null) {
                        clear();
                        listingOfFriend(arr[round-1], imageViews ,trashs ,wishlists ,userNameLabels,NameLabels , birthDateLabels ,phoneLabels);
                }
        });	 
            wish_1.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[0].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_2.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[1].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_3.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[2].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_4.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[3].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_5.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[4].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_6.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[5].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_7.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[6].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_8.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[7].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_9.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[8].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            wish_10.setOnMouseClicked(e -> {
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic, userNameLabels[9].getText());
                    buttonSwitcher.switchWishlistFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            trash_1.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[0].getText());
            });
            trash_2.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[1].getText());
            });    
            
            trash_3.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[2].getText());
            });            
            trash_4.setOnMouseClicked(e -> {

               deleteFriend(username, userNameLabels[3].getText());
            });              
            trash_5.setOnMouseClicked(e -> {
                deleteFriend(username, userNameLabels[4].getText());
            });  
            trash_6.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[5].getText());
            });  
            
            trash_7.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[6].getText());
            });
            trash_8.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[7].getText());
            });
            
            trash_9.setOnMouseClicked(e -> {

                deleteFriend(username, userNameLabels[8].getText());
            });     
            trash_10.setOnMouseClicked(e -> {

               deleteFriend(username, userNameLabels[9].getText());
            });        
               
            addFriendImage.setOnMouseClicked(e->{
                
                try {
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchAddFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
      
             friendRequestImage.setOnMouseClicked(e->{
                 try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }   
             });
        
              
            
              
        } catch (IOException ex) {
            Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
        }  
    }
    
    private void deleteFriend(String username, String friendName) {
    try {
        Socket SS = new Socket("localhost", 7001);
        PrintWriter out = new PrintWriter(SS.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(SS.getInputStream()));

        String del = "deleteFriend" + ":" + username + ":" + friendName;
        out.println(del);
        String response = in.readLine();
        if (response.equals("true")) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Friend Deletion");
            alert.setHeaderText(null);
            alert.setContentText("Your Friend Is Deleted Successfully.");
            alert.showAndWait();
            ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
            buttonSwitcher.switchFriendsScene();
        }
    } catch (IOException ex) {
        Logger.getLogger(friendScene.class.getName()).log(Level.SEVERE, null, ex);
    }
}   
    public void clear(){
    imageView_1.setVisible(false);wish_1.setVisible(false);trash_1.setVisible(false);
    imageView_2.setVisible(false);wish_2.setVisible(false);trash_2.setVisible(false);
    imageView_3.setVisible(false);wish_3.setVisible(false);trash_3.setVisible(false);
    imageView_4.setVisible(false);wish_4.setVisible(false);trash_4.setVisible(false);
    imageView_5.setVisible(false);wish_5.setVisible(false);trash_5.setVisible(false);
    imageView_6.setVisible(false);wish_6.setVisible(false);trash_6.setVisible(false);
    imageView_7.setVisible(false);wish_7.setVisible(false);trash_7.setVisible(false);
    imageView_8.setVisible(false);wish_8.setVisible(false);trash_8.setVisible(false);
    imageView_9.setVisible(false);wish_9.setVisible(false);trash_9.setVisible(false);
    imageView_10.setVisible(false);wish_10.setVisible(false);trash_10.setVisible(false);
    lbl_1.setVisible(false);lbl_11.setVisible(false);lbl_21.setVisible(false);lbl_31.setVisible(false);
    lbl_2.setVisible(false);lbl_12.setVisible(false);lbl_22.setVisible(false);lbl_32.setVisible(false);
    lbl_3.setVisible(false);lbl_13.setVisible(false);lbl_23.setVisible(false);lbl_33.setVisible(false);
    lbl_4.setVisible(false);lbl_14.setVisible(false);lbl_24.setVisible(false);lbl_34.setVisible(false);
    lbl_5.setVisible(false);lbl_15.setVisible(false);lbl_25.setVisible(false);lbl_35.setVisible(false);
    lbl_6.setVisible(false);lbl_16.setVisible(false);lbl_26.setVisible(false);lbl_36.setVisible(false);
    lbl_7.setVisible(false);lbl_17.setVisible(false);lbl_27.setVisible(false);lbl_37.setVisible(false);
    lbl_8.setVisible(false);lbl_18.setVisible(false);lbl_28.setVisible(false);lbl_38.setVisible(false);
    lbl_9.setVisible(false);lbl_19.setVisible(false);lbl_29.setVisible(false);lbl_39.setVisible(false);
    lbl_10.setVisible(false);lbl_20.setVisible(false);lbl_30.setVisible(false);lbl_40.setVisible(false);
    }
    public void listingOfFriend( String[] data  , ImageView[] imageViews ,ImageView[] trashs,
                                ImageView[] wishlists ,Label[] userNameLabels,Label[] NameLabels , 
                                Label[] birthDateLabels ,Label[] phoneLabels )
    {
 
            
            for (int i = 0; i < imageViews.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String userName     = components[0];
                String firstName    = components[1];
                String lastName     = components[2];
                String birthDate    = components[3];
                String phone        = components[4];
                String concateName  = firstName+" "+lastName; 
 
                imageViews[i].setVisible(true);
                trashs[i].setVisible(true);
                wishlists[i].setVisible(true);

                
                userNameLabels[i].setText(userName);
                userNameLabels[i].setVisible(true);
                 
                NameLabels[i].setText(concateName);
                NameLabels[i].setVisible(true);
                 
                birthDateLabels[i].setText(birthDate);
                birthDateLabels[i].setVisible(true);
                 
                phoneLabels[i].setText(phone);
                phoneLabels[i].setVisible(true);
         
            }
    }
    	public void notificationView(  String response , Text[] notification )
    {       
	    String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    }
}
