package giftgenie;

import com.jfoenix.controls.JFXCheckBox;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public  class LoginScene extends BorderPane {

    protected final ImageView imageStar;
    protected final ImageView imageStar2;
    protected final ImageView imageBoo;
    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final TextField passwordUnhide;
    protected final TextField textFieldUsername;
    protected final Text text;
    protected final Text forgot_pass;
    protected final Button btnSignup;
    protected final Text text0;
    protected final PasswordField textPassword;
    protected final Button btnLogin;
    protected final Text text1;
    protected final Text text2;
    protected final JFXCheckBox CheckBox;
    protected final Text ShowPass;
    
    String password;

    public LoginScene(Stage s) {

        anchorPane = new AnchorPane();
        imageView = new ImageView();
        passwordUnhide = new TextField();
        textFieldUsername = new TextField();
        text = new Text();
        forgot_pass = new Text();
        btnSignup = new Button();
        text0 = new Text();
        textPassword = new PasswordField();
        btnLogin = new Button();
        text1 = new Text();
        text2 = new Text();
        CheckBox = new JFXCheckBox();
        ShowPass = new Text();

        setMaxHeight(400.0);
        setMaxWidth(612.0);
        setMinHeight(400.0);
        setMinWidth(570.0);
        setPrefHeight(400.0);
        setPrefWidth(592.0);

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setPrefHeight(410.0);
        anchorPane.setPrefWidth(613.0);

        imageView.setFitHeight(427.0);
        imageView.setFitWidth(610.0);
        imageView.setLayoutX(0.0);
        imageView.setLayoutY(0.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("loginback.png").toExternalForm()));

        passwordUnhide.setAlignment(javafx.geometry.Pos.CENTER);
        passwordUnhide.setLayoutX(433.0);
        passwordUnhide.setLayoutY(121.0);
        passwordUnhide.setOpacity(0.88);
        passwordUnhide.setPrefHeight(30.0);
        passwordUnhide.setPrefWidth(147.0);
        passwordUnhide.setPromptText("insert password here");
        passwordUnhide.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");
        passwordUnhide.setVisible(false);

        textFieldUsername.setAlignment(javafx.geometry.Pos.CENTER);
        textFieldUsername.setLayoutX(433.0);
        textFieldUsername.setLayoutY(69.0);
        textFieldUsername.setOpacity(0.88);
        textFieldUsername.setPrefHeight(30.0);
        textFieldUsername.setPrefWidth(147.0);
        textFieldUsername.setPromptText("insert username here");
        textFieldUsername.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        text.setFill(javafx.scene.paint.Color.valueOf("#b9e7ff"));
        text.setLayoutX(420.0);
        text.setLayoutY(35.0);
        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setText("Welcome to GiftGenie app!");
        text.setFont(new Font(14.0));

        forgot_pass.setFill(javafx.scene.paint.Color.WHITE);
        forgot_pass.setLayoutX(480.0);
        forgot_pass.setLayoutY(232.0);
        forgot_pass.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        forgot_pass.setStrokeWidth(0.0);
        forgot_pass.setText("Forgot password?");
        forgot_pass.setWrappingWidth(108.13671875);
        forgot_pass.setCursor(Cursor.HAND);
        forgot_pass.setFont(new Font( 12.0));

        btnSignup.setLayoutX(479.0);
        btnSignup.setLayoutY(359.0);
        btnSignup.setMnemonicParsing(false);
        btnSignup.setOpacity(0.88);
        btnSignup.setPrefHeight(30.0);
        btnSignup.setPrefWidth(69.0);
        btnSignup.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        btnSignup.setText("Register");
        btnSignup.setCursor(Cursor.HAND);
        btnSignup.setFont(new Font("System Bold", 12.0));

        text0.setFill(javafx.scene.paint.Color.WHITE);
        text0.setLayoutX(455.0);
        text0.setLayoutY(349.0);
        text0.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text0.setStrokeWidth(0.0);
        text0.setText("don't have account?");
        text0.setWrappingWidth(126.13671875);
        text0.setFont(new Font("System Bold", 12.0));

        textPassword.setAlignment(javafx.geometry.Pos.CENTER);
        textPassword.setLayoutX(433.0);
        textPassword.setLayoutY(121.0);
        textPassword.setOpacity(0.88);
        textPassword.setPrefHeight(30.0);
        textPassword.setPrefWidth(147.0);
        textPassword.setPromptText("insert password here");
        textPassword.setStyle("-fx-background-color: white; -fx-background-radius: 30; -fx-border-radius: 30;");

        btnLogin.setContentDisplay(javafx.scene.control.ContentDisplay.CENTER);
        btnLogin.setLayoutX(434.0);
        btnLogin.setLayoutY(185.0);
        btnLogin.setMnemonicParsing(false);
        btnLogin.setOpacity(0.88);
        btnLogin.setPrefHeight(30.0);
        btnLogin.setPrefWidth(147.0);
        btnLogin.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        btnLogin.setText("Login");
        btnLogin.setCursor(Cursor.HAND);
        btnLogin.setFont(new Font("System Bold", 12.0));

        text1.setFill(javafx.scene.paint.Color.WHITE);
        text1.setLayoutX(435.0);
        text1.setLayoutY(61.0);
        text1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1.setStrokeWidth(0.0);
        text1.setText("Username");
        text1.setFont(new Font("System Bold", 14.0));

        text2.setFill(javafx.scene.paint.Color.WHITE);
        text2.setLayoutX(436.0);
        text2.setLayoutY(114.0);
        text2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text2.setStrokeWidth(0.0);
        text2.setText("Password");
        text2.setFont(new Font("System Bold", 14.0));

        CheckBox.setLayoutX(440.0);
        CheckBox.setLayoutY(159.0);
        CheckBox.setFont(new Font("System Bold", 14.0));
        CheckBox.setCursor(Cursor.HAND);

        ShowPass.setFill(javafx.scene.paint.Color.WHITE);
        ShowPass.setLayoutX(465.0);
        ShowPass.setLayoutY(174.0);
        ShowPass.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        ShowPass.setStrokeWidth(0.0);
        ShowPass.setText("Show");
        ShowPass.setFont(new Font("System Bold", 14.0));
        setRight(anchorPane);

        
        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(passwordUnhide);
        anchorPane.getChildren().add(textFieldUsername);
        anchorPane.getChildren().add(text);
        anchorPane.getChildren().add(forgot_pass);
        anchorPane.getChildren().add(btnSignup);
        anchorPane.getChildren().add(text0);
        anchorPane.getChildren().add(textPassword);
        anchorPane.getChildren().add(btnLogin);
        anchorPane.getChildren().add(text1);
        anchorPane.getChildren().add(text2);
        anchorPane.getChildren().add(CheckBox);
        anchorPane.getChildren().add(ShowPass);
    
        CheckBox.setOnAction(e -> {
                if (CheckBox.isSelected()) {
                    textPassword.setVisible(false);
                    passwordUnhide.setText(textPassword.getText());
                    passwordUnhide.setVisible(true);
                } else {
                    passwordUnhide.setVisible(false);
                    textPassword.setText(passwordUnhide.getText());
                    textPassword.setVisible(true);
                }
            });
            forgot_pass.setOnMouseClicked(e -> {
                    Parent rootForgetPassword = new editpassword(s);
                    Scene scene = new Scene(rootForgetPassword);
                    s.setScene(scene);
                });
            forgot_pass.setOnMouseEntered(e -> {
                    forgot_pass.setFill(Color.PURPLE);
                    forgot_pass.setUnderline(true);
                    forgot_pass.setFont(Font.font("System",FontWeight.BOLD ,12));
                     });
            forgot_pass.setOnMouseExited(e -> {
                    forgot_pass.setFill(Color.WHITE);
                    forgot_pass.setUnderline(false);
                    forgot_pass.setFont(Font.font("System",  12));
                });
            btnLogin.setOnAction(e -> {
                try {
                    Socket socket = new Socket("localhost", 7001);
                    PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                    BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    if (CheckBox.isSelected()) {
                    password = passwordUnhide.getText();
                    } else {
                    password = textPassword.getText();
                    }
                    if(textFieldUsername.getText().isEmpty() || (textPassword.getText().isEmpty() && passwordUnhide.getText().isEmpty()) )  {
                        Alert alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Please fill all blank fields");
                        alert.showAndWait();
                        return;
                    } else {
                        String request = "login"+":"+textFieldUsername.getText() + ":" + password ;
                        output.println(request);

                        boolean authenticated = Boolean.parseBoolean(input.readLine());
                        String backGroundPic = null;
                        if (authenticated) {
                            Parent rootapp = new appScene(s,textFieldUsername.getText(), backGroundPic);
                            Scene scene = new Scene(rootapp);
                            s.setScene(scene);
                        } else {
                            Alert alert = new Alert(AlertType.ERROR);
                            alert.setTitle("Error Message");
                            alert.setHeaderText(null);
                            alert.setContentText("Wrong Username/Password, Please try again");
                            alert.showAndWait();
                        }
                    }
                    socket.close();
                } catch (IOException ex) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                    alert.showAndWait();
                }
            });

        btnSignup.setOnAction(e -> {
        
        
        Parent rootsignup;
            try {
                rootsignup = new SignupScene( s );
                Scene scene = new Scene(rootsignup);
                s.setScene(scene); 
            } catch (IOException ex) {
                Logger.getLogger(LoginScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });  
        
        
        imageStar = new ImageView();       
        imageStar.setFitHeight(200.0);
        imageStar.setFitWidth(200.0);
        imageStar.setLayoutX(-10.0);
        imageStar.setLayoutY(1.0);
        imageStar.setPickOnBounds(true);
        imageStar.setPreserveRatio(true);
        imageStar.setImage(new Image(getClass().getResource("star.png").toExternalForm()));
        imageStar.toFront(); 
        anchorPane.getChildren().add(imageStar);
        
        Thread starThread = new Thread(() -> {
            int y = 270;
            int x = -10;
            boolean sleep = true; 
            boolean rotate = true; 
            while (sleep == true ) {
                if (rotate)
                {
                x += 10;
                y -= 10 ;
                }
                else {
                x += 10; 
                y += 10;
                }
                imageStar.setLayoutX(x);
                imageStar.setLayoutY(y);

                if (y <= 0){
                        x=0;
                        y=0;
                        imageStar.setRotate(90.0);
                        rotate = false;
                        sleep=false;
                        imageStar.setVisible(false);
                }else if(y>=270){
                       x=0;
                       y=270;
                       imageStar.setRotate(360.0); 
                       rotate = true;
                       sleep=false;
                       imageStar.setVisible(false);
                       }
                
                try {
                    if(sleep == false ){
                    Thread.sleep(4555);
                    sleep = true;
                    imageStar.setVisible(true);
                   
                    }
                    else{
                    Thread.sleep(100);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        starThread.setDaemon(true);
        starThread.start();
    
        imageStar2 = new ImageView();       
        imageStar2.setFitHeight(100.0);
        imageStar2.setFitWidth(100.0);
        imageStar2.setLayoutX(100.0);
        imageStar2.setLayoutY(1.0);
        imageStar2.setImage(new Image(getClass().getResource("star2.png").toExternalForm()));
        imageStar2.toFront(); 
        anchorPane.getChildren().add(imageStar2);
        
        
        Thread imageStar2Thread = new Thread(() -> {
            Random random = new Random();
            int op1 = -10;
            while (true) {
                int x = random.nextInt(400);
                int y = random.nextInt(300);
                imageStar2.setLayoutX(x);
                imageStar2.setLayoutY(y);
                for (int i = 0; i <= 100; i++) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (int i = 100; i >= 0; i--) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        imageStar2Thread.setDaemon(true);
        imageStar2Thread.start();

        
        imageBoo = new ImageView();       
        imageBoo.setFitHeight(200.0);
        imageBoo.setFitWidth(200.0);
        imageBoo.setLayoutX(200.0);
        imageBoo.setLayoutY(100.0);
        imageBoo.setPickOnBounds(true);
        imageBoo.setPreserveRatio(true);
        imageBoo.setVisible(false);
        imageBoo.setImage(new Image(getClass().getResource("Boo.png").toExternalForm()));
        imageStar.toFront(); 
        anchorPane.getChildren().add(imageBoo);
        
        text.setOnMouseEntered(e -> {
                    text.setFill(Color.LIGHTBLUE);
                    text.setUnderline(true);
                    text.setFont(Font.font("System",FontWeight.BOLD ,14));
                     });
        text.setOnMouseExited(e -> {
                    text.setFill(Color.LIGHTBLUE);
                    text.setUnderline(false);
                    text.setFont(Font.font("System" ,  14));
                });
        text.setOnMouseClicked(e -> {
            Thread imageBooThread = new Thread(() -> {
            imageBoo.setFitWidth(50.0);
            imageBoo.setVisible(true);
            int size = 50;
            int step = 5;

            while (size < 300) {
                size += step;
                imageBoo.setFitWidth(size);
                imageBoo.setFitHeight(size);
                imageBoo.setVisible(true);

                try {
                    Thread.sleep(20);
                } catch (InterruptedException es) {
                    es.printStackTrace();
                }
            }
                imageBoo.setVisible(false);
                Thread.currentThread().interrupt();
            });
                    imageBooThread.start();
        });
                
           
    }    
}
