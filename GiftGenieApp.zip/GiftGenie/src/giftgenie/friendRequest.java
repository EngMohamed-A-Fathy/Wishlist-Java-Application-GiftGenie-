package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class friendRequest extends BorderPane {

    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView notificationIcon;
    protected final ImageView imageView4;
    protected final Button MyWishlistButton;
    protected final Button HomeButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView imageView5;
    protected final ImageView imageView6;
    protected final ImageView imageView_1;
    protected final ImageView imageView_2;
    protected final ImageView imageView_3;
    protected final ImageView imageView_4;
    protected final ImageView imageView_5;
    protected final ImageView imageView_6;
    protected final ImageView imageView_7;
    protected final ImageView imageView_8;
    protected final Label lbl_date;
    protected final Label lbl_friend;
    protected final Label lbl_1;
    protected final Label lbl_2;
    protected final Label lbl_3;
    protected final Label lbl_4;
    protected final Label lbl_5;
    protected final Label lbl_6;
    protected final Label lbl_7;
    protected final Label lbl_8;
    protected final Label lbl_11;
    protected final Label lbl_12;
    protected final Label lbl_13;
    protected final Label lbl_14;
    protected final Label lbl_15;
    protected final Label lbl_16;
    protected final Label lbl_17;
    protected final Label lbl_18;
    protected final ImageView imageView7;
    protected final Button CashButton;
    protected final ImageView imageView8;
    protected final Button SettingButton;
    protected final ImageView imageView9;
    protected final Button HelpButton;
    protected final ImageView friendRequestImage;
    protected final ImageView friendListImage;
    protected final ImageView accep_1;
    protected final ImageView accep_2;
    protected final ImageView accep_3;
    protected final ImageView accep_4;
    protected final ImageView accep_5;
    protected final ImageView accep_6;
    protected final ImageView accep_7;
    protected final ImageView accep_8;
    protected final ImageView cancel_1;
    protected final ImageView cancel_2;
    protected final ImageView cancel_3;
    protected final ImageView cancel_4;
    protected final ImageView cancel_5;
    protected final ImageView cancel_6;
    protected final ImageView cancel_7;
    protected final ImageView cancel_8;
    protected final ImageView imageView10;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    
    boolean notificationTurn = true;
    String backGroundPic = null;
    String currentMoney;
    Stage s;
    String moneyValue;

    public friendRequest(Stage s  , String username , String moneyValue, String pic) {
 
        this.s = s;
        this.moneyValue = moneyValue;
        backGroundPic = pic;
        currentMoney = moneyValue;
    
        anchorPane = new AnchorPane();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        notificationIcon = new ImageView();
        imageView4 = new ImageView();
        MyWishlistButton = new Button();
        HomeButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        imageView5 = new ImageView();
        imageView6 = new ImageView();
        imageView_1 = new ImageView();
        imageView_2 = new ImageView();
        imageView_3 = new ImageView();
        imageView_4 = new ImageView();
        imageView_5 = new ImageView();
        imageView_6 = new ImageView();
        imageView_7 = new ImageView();
        imageView_8 = new ImageView();
        lbl_date = new Label();
        lbl_friend = new Label();
        lbl_1 = new Label();
        lbl_2 = new Label();
        lbl_3 = new Label();
        lbl_4 = new Label();
        lbl_5 = new Label();
        lbl_6 = new Label();
        lbl_7 = new Label();
        lbl_8 = new Label();
        lbl_11 = new Label();
        lbl_12 = new Label();
        lbl_13 = new Label();
        lbl_14 = new Label();
        lbl_15 = new Label();
        lbl_16 = new Label();
        lbl_17 = new Label();
        lbl_18 = new Label();
        imageView7 = new ImageView();
        CashButton = new Button();
        imageView8 = new ImageView();
        SettingButton = new Button();
        imageView9 = new ImageView();
        HelpButton = new Button();
        friendRequestImage = new ImageView();
        friendListImage = new ImageView();
        accep_1 = new ImageView();
        accep_2 = new ImageView();
        accep_3 = new ImageView();
        accep_4 = new ImageView();
        accep_5 = new ImageView();
        accep_6 = new ImageView();
        accep_7 = new ImageView();
        accep_8 = new ImageView();
        cancel_1 = new ImageView();
        cancel_2 = new ImageView();
        cancel_3 = new ImageView();
        cancel_4 = new ImageView();
        cancel_5 = new ImageView();
        cancel_6 = new ImageView();
        cancel_7 = new ImageView();
        cancel_8 = new ImageView();
        imageView10 = new ImageView();
        notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();
        
        setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));

        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        imageView3.setFitHeight(61.0);
        imageView3.setFitWidth(65.0);
        imageView3.setLayoutX(18.0);
        imageView3.setLayoutY(134.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        imageView4.setFitHeight(42.0);
        imageView4.setFitWidth(41.0);
        imageView4.setLayoutX(975.0);
        imageView4.setLayoutY(8.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setCursor(Cursor.HAND);
        imageView4.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setCursor(Cursor.HAND);
        AddItemButton.setFont(new Font("System Bold", 24.0));

        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setCursor(Cursor.HAND);
        FriendButton.setFont(new Font("System Bold", 24.0));

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));

        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));

        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        imageView5.setFitHeight(84.0);
        imageView5.setFitWidth(82.0);
        imageView5.setLayoutX(532.0);
        imageView5.setLayoutY(72.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));

        imageView6.setFitHeight(84.0);
        imageView6.setFitWidth(82.0);
        imageView6.setLayoutX(327.0);
        imageView6.setLayoutY(72.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(new Image(getClass().getResource("friends/head.png").toExternalForm()));

        imageView_1.setFitHeight(45.0);
        imageView_1.setFitWidth(638.0);
        imageView_1.setLayoutX(300.0);
        imageView_1.setLayoutY(140.0);
        imageView_1.setPickOnBounds(true);
        imageView_1.setPreserveRatio(true);
        imageView_1.setVisible(false);
        imageView_1.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_2.setFitHeight(45.0);
        imageView_2.setFitWidth(730.0);
        imageView_2.setLayoutX(300.0);
        imageView_2.setLayoutY(190.0);
        imageView_2.setPickOnBounds(true);
        imageView_2.setPreserveRatio(true);
        imageView_2.setVisible(false);
        imageView_2.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_3.setFitHeight(45.0);
        imageView_3.setFitWidth(730.0);
        imageView_3.setLayoutX(300.0);
        imageView_3.setLayoutY(240.0);
        imageView_3.setPickOnBounds(true);
        imageView_3.setPreserveRatio(true);
        imageView_3.setVisible(false);
        imageView_3.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_4.setFitHeight(45.0);
        imageView_4.setFitWidth(730.0);
        imageView_4.setLayoutX(300.0);
        imageView_4.setLayoutY(290.0);
        imageView_4.setPickOnBounds(true);
        imageView_4.setPreserveRatio(true);
        imageView_4.setVisible(false);
        imageView_4.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_5.setFitHeight(45.0);
        imageView_5.setFitWidth(730.0);
        imageView_5.setLayoutX(300.0);
        imageView_5.setLayoutY(340.0);
        imageView_5.setPickOnBounds(true);
        imageView_5.setPreserveRatio(true);
        imageView_5.setVisible(false);
        imageView_5.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_6.setFitHeight(45.0);
        imageView_6.setFitWidth(730.0);
        imageView_6.setLayoutX(300.0);
        imageView_6.setLayoutY(390.0);
        imageView_6.setPickOnBounds(true);
        imageView_6.setPreserveRatio(true);
        imageView_6.setVisible(false);
        imageView_6.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_7.setFitHeight(45.0);
        imageView_7.setFitWidth(730.0);
        imageView_7.setLayoutX(300.0);
        imageView_7.setLayoutY(440.0);
        imageView_7.setPickOnBounds(true);
        imageView_7.setPreserveRatio(true);
        imageView_7.setVisible(false);
        imageView_7.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        imageView_8.setFitHeight(45.0);
        imageView_8.setFitWidth(730.0);
        imageView_8.setLayoutX(300.0);
        imageView_8.setLayoutY(490.0);
        imageView_8.setPickOnBounds(true);
        imageView_8.setPreserveRatio(true);
        imageView_8.setVisible(false);
        imageView_8.setImage(new Image(getClass().getResource("textfield2.png").toExternalForm()));

        lbl_date.setLayoutX(335.0);
        lbl_date.setLayoutY(107.0);
        lbl_date.setText("Username");
        lbl_date.setFont(new Font("System Bold", 14.0));

        lbl_friend.setLayoutX(553.0);
        lbl_friend.setLayoutY(107.0);
        lbl_friend.setText("Name");
        lbl_friend.setFont(new Font("System Bold", 14.0));

        lbl_1.setLayoutX(345.0);
        lbl_1.setLayoutY(150.0);
        lbl_1.setPrefHeight(20.0);
        lbl_1.setPrefWidth(43.0);
        lbl_1.setText("phone");
        lbl_1.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_1.setVisible(false);
        lbl_1.setFont(new Font("System Bold", 14.0));

        lbl_2.setLayoutX(345.0);
        lbl_2.setLayoutY(200.0);
        lbl_2.setText("phone");
        lbl_2.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_2.setVisible(false);
        lbl_2.setFont(new Font("System Bold", 14.0));

        lbl_3.setLayoutX(345.0);
        lbl_3.setLayoutY(250.0);
        lbl_3.setText("phone");
        lbl_3.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_3.setVisible(false);
        lbl_3.setFont(new Font("System Bold", 14.0));

        lbl_4.setLayoutX(345.0);
        lbl_4.setLayoutY(300.0);
        lbl_4.setText("phone");
        lbl_4.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_4.setVisible(false);
        lbl_4.setFont(new Font("System Bold", 14.0));

        lbl_5.setLayoutX(345.0);
        lbl_5.setLayoutY(350.0);
        lbl_5.setText("phone");
        lbl_5.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_5.setVisible(false);
        lbl_5.setFont(new Font("System Bold", 14.0));

        lbl_6.setLayoutX(345.0);
        lbl_6.setLayoutY(400.0);
        lbl_6.setText("phone");
        lbl_6.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_6.setVisible(false);
        lbl_6.setFont(new Font("System Bold", 14.0));

        lbl_7.setLayoutX(345.0);
        lbl_7.setLayoutY(450.0);
        lbl_7.setText("phone");
        lbl_7.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_7.setVisible(false);
        lbl_7.setFont(new Font("System Bold", 14.0));

        lbl_8.setLayoutX(345.0);
        lbl_8.setLayoutY(500.0);
        lbl_8.setText("phone");
        lbl_8.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_8.setVisible(false);
        lbl_8.setFont(new Font("System Bold", 14.0));

        lbl_11.setLayoutX(540.0);
        lbl_11.setLayoutY(150.0);
        lbl_11.setText("Abdelaziz");
        lbl_11.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_11.setVisible(false);
        lbl_11.setFont(new Font("System Bold", 14.0));

        lbl_12.setLayoutX(540.0);
        lbl_12.setLayoutY(200.0);
        lbl_12.setText("Abdelaziz");
        lbl_12.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_12.setVisible(false);
        lbl_12.setFont(new Font("System Bold", 14.0));

        lbl_13.setLayoutX(540.0);
        lbl_13.setLayoutY(250.0);
        lbl_13.setText("Abdelaziz");
        lbl_13.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_13.setVisible(false);
        lbl_13.setFont(new Font("System Bold", 14.0));

        lbl_14.setLayoutX(540.0);
        lbl_14.setLayoutY(300.0);
        lbl_14.setText("Abdelaziz");
        lbl_14.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_14.setVisible(false);
        lbl_14.setFont(new Font("System Bold", 14.0));

        lbl_15.setLayoutX(540.0);
        lbl_15.setLayoutY(350.0);
        lbl_15.setText("Abdelaziz");
        lbl_15.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_15.setVisible(false);
        lbl_15.setFont(new Font("System Bold", 14.0));

        lbl_16.setLayoutX(540.0);
        lbl_16.setLayoutY(400.0);
        lbl_16.setText("Abdelaziz");
        lbl_16.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_16.setVisible(false);
        lbl_16.setFont(new Font("System Bold", 14.0));

        lbl_17.setLayoutX(540.0);
        lbl_17.setLayoutY(450.0);
        lbl_17.setText("Abdelaziz");
        lbl_17.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_17.setVisible(false);
        lbl_17.setFont(new Font("System Bold", 14.0));

        lbl_18.setLayoutX(540.0);
        lbl_18.setLayoutY(500.0);
        lbl_18.setText("Abdelaziz");
        lbl_18.setTextFill(javafx.scene.paint.Color.WHITE);
        lbl_18.setVisible(false);
        lbl_18.setFont(new Font("System Bold", 14.0));

        imageView7.setFitHeight(51.0);
        imageView7.setFitWidth(59.0);
        imageView7.setLayoutX(15.0);
        imageView7.setLayoutY(260.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));

        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));

        imageView8.setFitHeight(51.0);
        imageView8.setFitWidth(59.0);
        imageView8.setLayoutX(17.0);
        imageView8.setLayoutY(316.0);
        imageView8.setPickOnBounds(true);
        imageView8.setPreserveRatio(true);
        imageView8.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView9.setFitHeight(51.0);
        imageView9.setFitWidth(59.0);
        imageView9.setLayoutX(19.0);
        imageView9.setLayoutY(378.0);
        imageView9.setPickOnBounds(true);
        imageView9.setPreserveRatio(true);
        imageView9.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setCursor(Cursor.HAND);
        HelpButton.setFont(new Font("System Bold", 24.0));

        friendRequestImage.setFitHeight(164.0);
        friendRequestImage.setFitWidth(40.0);
        friendRequestImage.setLayoutX(1061.0);
        friendRequestImage.setLayoutY(100.0);
        friendRequestImage.setPickOnBounds(true);
        friendRequestImage.setPreserveRatio(true);
        friendRequestImage.setCursor(Cursor.HAND);
        friendRequestImage.setImage(new Image(getClass().getResource("addFriendImaga.png").toExternalForm()));

        friendListImage.setFitHeight(164.0);
        friendListImage.setFitWidth(40.0);
        friendListImage.setLayoutX(1061.0);
        friendListImage.setLayoutY(250.0);
        friendListImage.setPickOnBounds(true);
        friendListImage.setPreserveRatio(true);
        friendListImage.setCursor(Cursor.HAND);
        friendListImage.setImage(new Image(getClass().getResource("friendListImage.png").toExternalForm()));

        accep_1.setFitHeight(26.0);
        accep_1.setFitWidth(25.0);
        accep_1.setLayoutX(740.0);
        accep_1.setLayoutY(149.0);
        accep_1.setPickOnBounds(true);
        accep_1.setPreserveRatio(true);
        accep_1.setVisible(false);
        accep_1.setCursor(Cursor.HAND);
        accep_1.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_2.setFitHeight(26.0);
        accep_2.setFitWidth(25.0);
        accep_2.setLayoutX(740.0);
        accep_2.setLayoutY(199.0);
        accep_2.setPickOnBounds(true);
        accep_2.setPreserveRatio(true);
        accep_2.setVisible(false);
        accep_2.setCursor(Cursor.HAND);
        accep_2.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_3.setFitHeight(26.0);
        accep_3.setFitWidth(25.0);
        accep_3.setLayoutX(740.0);
        accep_3.setLayoutY(249.0);
        accep_3.setPickOnBounds(true);
        accep_3.setPreserveRatio(true);
        accep_3.setVisible(false);
        accep_3.setCursor(Cursor.HAND);
        accep_3.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_4.setFitHeight(26.0);
        accep_4.setFitWidth(25.0);
        accep_4.setLayoutX(740.0);
        accep_4.setLayoutY(299.0);
        accep_4.setPickOnBounds(true);
        accep_4.setPreserveRatio(true);
        accep_4.setVisible(false);
        accep_4.setCursor(Cursor.HAND);
        accep_4.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_5.setFitHeight(26.0);
        accep_5.setFitWidth(25.0);
        accep_5.setLayoutX(740.0);
        accep_5.setLayoutY(350.0);
        accep_5.setPickOnBounds(true);
        accep_5.setPreserveRatio(true);
        accep_5.setVisible(false);
        accep_5.setCursor(Cursor.HAND);
        accep_5.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_6.setFitHeight(26.0);
        accep_6.setFitWidth(25.0);
        accep_6.setLayoutX(740.0);
        accep_6.setLayoutY(400.0);
        accep_6.setPickOnBounds(true);
        accep_6.setPreserveRatio(true);
        accep_6.setVisible(false);
        accep_7.setCursor(Cursor.HAND);
        accep_6.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_7.setFitHeight(26.0);
        accep_7.setFitWidth(25.0);
        accep_7.setLayoutX(740.0);
        accep_7.setLayoutY(450.0);
        accep_7.setPickOnBounds(true);
        accep_7.setPreserveRatio(true);
        accep_7.setVisible(false);
        accep_7.setCursor(Cursor.HAND);
        accep_7.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        accep_8.setFitHeight(26.0);
        accep_8.setFitWidth(25.0);
        accep_8.setLayoutX(740.0);
        accep_8.setLayoutY(500.0);
        accep_8.setPickOnBounds(true);
        accep_8.setPreserveRatio(true);
        accep_8.setVisible(false);
        accep_8.setCursor(Cursor.HAND);
        accep_8.setImage(new Image(getClass().getResource("accepticon.png").toExternalForm()));

        cancel_1.setFitHeight(26.0);
        cancel_1.setFitWidth(25.0);
        cancel_1.setLayoutX(826.0);
        cancel_1.setLayoutY(149.0);
        cancel_1.setPickOnBounds(true);
        cancel_1.setPreserveRatio(true);
        cancel_1.setVisible(false);
        cancel_1.setCursor(Cursor.HAND);
        cancel_1.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_2.setFitHeight(26.0);
        cancel_2.setFitWidth(25.0);
        cancel_2.setLayoutX(826.0);
        cancel_2.setLayoutY(199.0);
        cancel_2.setPickOnBounds(true);
        cancel_2.setPreserveRatio(true);
        cancel_2.setVisible(false);
        cancel_2.setCursor(Cursor.HAND);
        cancel_2.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_3.setFitHeight(26.0);
        cancel_3.setFitWidth(25.0);
        cancel_3.setLayoutX(826.0);
        cancel_3.setLayoutY(249.0);
        cancel_3.setPickOnBounds(true);
        cancel_3.setPreserveRatio(true);
        cancel_3.setVisible(false);
        cancel_3.setCursor(Cursor.HAND);
        cancel_3.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_4.setFitHeight(26.0);
        cancel_4.setFitWidth(25.0);
        cancel_4.setLayoutX(826.0);
        cancel_4.setLayoutY(299.0);
        cancel_4.setPickOnBounds(true);
        cancel_4.setPreserveRatio(true);
        cancel_4.setVisible(false);
        cancel_4.setCursor(Cursor.HAND);
        cancel_4.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_5.setFitHeight(26.0);
        cancel_5.setFitWidth(25.0);
        cancel_5.setLayoutX(826.0);
        cancel_5.setLayoutY(350.0);
        cancel_5.setPickOnBounds(true);
        cancel_5.setPreserveRatio(true);
        cancel_5.setVisible(false);
        cancel_5.setCursor(Cursor.HAND);
        cancel_5.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_6.setFitHeight(26.0);
        cancel_6.setFitWidth(25.0);
        cancel_6.setLayoutX(826.0);
        cancel_6.setLayoutY(400.0);
        cancel_6.setPickOnBounds(true);
        cancel_6.setPreserveRatio(true);
        cancel_6.setVisible(false);
        cancel_6.setCursor(Cursor.HAND);
        cancel_6.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_7.setFitHeight(26.0);
        cancel_7.setFitWidth(25.0);
        cancel_7.setLayoutX(826.0);
        cancel_7.setLayoutY(450.0);
        cancel_7.setPickOnBounds(true);
        cancel_7.setPreserveRatio(true);
        cancel_7.setVisible(false);
        cancel_7.setCursor(Cursor.HAND);
        cancel_7.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        cancel_8.setFitHeight(26.0);
        cancel_8.setFitWidth(25.0);
        cancel_8.setLayoutX(826.0);
        cancel_8.setLayoutY(500.0);
        cancel_8.setPickOnBounds(true);
        cancel_8.setPreserveRatio(true);
        cancel_8.setVisible(false);
        cancel_8.setCursor(Cursor.HAND);
        cancel_8.setImage(new Image(getClass().getResource("cancelicone.png").toExternalForm()));

        imageView10.setFitHeight(78.0);
        imageView10.setFitWidth(200.0);
        imageView10.setLayoutX(313.0);
        imageView10.setLayoutY(18.0);
        imageView10.setPickOnBounds(true);
        imageView10.setPreserveRatio(true);
        imageView10.setImage(new Image(getClass().getResource("friends/FriendRequestWelcome.png").toExternalForm()));
        setCenter(anchorPane);
        notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);
        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(imageView6);
        anchorPane.getChildren().add(imageView_1);
        anchorPane.getChildren().add(imageView_2);
        anchorPane.getChildren().add(imageView_3);
        anchorPane.getChildren().add(imageView_4);
        anchorPane.getChildren().add(imageView_5);
        anchorPane.getChildren().add(imageView_6);
        anchorPane.getChildren().add(imageView_7);
        anchorPane.getChildren().add(imageView_8);
        anchorPane.getChildren().add(lbl_date);
        anchorPane.getChildren().add(lbl_friend);
        anchorPane.getChildren().add(lbl_1);
        anchorPane.getChildren().add(lbl_2);
        anchorPane.getChildren().add(lbl_3);
        anchorPane.getChildren().add(lbl_4);
        anchorPane.getChildren().add(lbl_5);
        anchorPane.getChildren().add(lbl_6);
        anchorPane.getChildren().add(lbl_7);
        anchorPane.getChildren().add(lbl_8);
        anchorPane.getChildren().add(lbl_11);
        anchorPane.getChildren().add(lbl_12);
        anchorPane.getChildren().add(lbl_13);
        anchorPane.getChildren().add(lbl_14);
        anchorPane.getChildren().add(lbl_15);
        anchorPane.getChildren().add(lbl_16);
        anchorPane.getChildren().add(lbl_17);
        anchorPane.getChildren().add(lbl_18);
        anchorPane.getChildren().add(imageView7);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(imageView8);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(imageView9);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(friendRequestImage);
        anchorPane.getChildren().add(friendListImage);
        anchorPane.getChildren().add(accep_1);
        anchorPane.getChildren().add(accep_2);
        anchorPane.getChildren().add(accep_3);
        anchorPane.getChildren().add(accep_4);
        anchorPane.getChildren().add(accep_5);
        anchorPane.getChildren().add(accep_6);
        anchorPane.getChildren().add(accep_7);
        anchorPane.getChildren().add(accep_8);
        anchorPane.getChildren().add(cancel_1);
        anchorPane.getChildren().add(cancel_2);
        anchorPane.getChildren().add(cancel_3);
        anchorPane.getChildren().add(cancel_4);
        anchorPane.getChildren().add(cancel_5);
        anchorPane.getChildren().add(cancel_6);
        anchorPane.getChildren().add(cancel_7);
        anchorPane.getChildren().add(cancel_8);
        anchorPane.getChildren().add(imageView10);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);

        moneyText.setText(currentMoney);
        nameText.setText(username);
        if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");

                });
        
        HomeButton.setOnAction(e -> {
             try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        FriendButton.setOnMouseEntered(e -> {
                    FriendButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnMouseExited(e -> {
                    FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchFriendsScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
                    
        HelpButton.setOnMouseEntered(e -> {
                    HelpButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HelpButton.setOnMouseExited(e -> {
                    HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        HelpButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchHelpScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        imageView4.setOnMouseClicked(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        AddItemButton.setOnMouseEntered(e -> {
                    AddItemButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        AddItemButton.setOnMouseExited(e -> {
                    AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        AddItemButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchAddItemScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });

        Socket socket;
        try {

            socket = new Socket("localhost", 7001);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            ImageView[] imageViews = {imageView_1, imageView_2, imageView_3, imageView_4, imageView_5,
                imageView_6, imageView_7, imageView_8};

            Label[] userNameLabels = {lbl_1, lbl_2, lbl_3, lbl_4, lbl_5,
                lbl_6, lbl_7, lbl_8};

            Label[] status = {lbl_11, lbl_12, lbl_13, lbl_14, lbl_15,
                lbl_16, lbl_17, lbl_18};

            ImageView[] acceptIcon = {accep_1, accep_2, accep_3, accep_4, accep_5, accep_6, accep_7, accep_8};

            ImageView[] cancelIcon = {cancel_1, cancel_2, cancel_3, cancel_4, cancel_5, cancel_6, cancel_7, cancel_8};

            String request = "showMyFriendRequest" + ":" + username;
            output.println(request);
            String inputString = input.readLine();
             if(inputString.equals("no friend request")){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Friend request");
                alert.setHeaderText(null);
                alert.setContentText("There is no friend requests");
                alert.showAndWait();
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchAddFriendScene();

            
            }
             else{
            String[] data = inputString.split("#");

            for (int i = 0; i < imageViews.length && i < data.length; i++) {

                String[] components = data[i].split(":");
                String name = components[0];
                String Status = components[1];
 
                imageViews[i].setVisible(true);
                acceptIcon[i].setVisible(true);
                cancelIcon[i].setVisible(true);

                userNameLabels[i].setText(name);
                userNameLabels[i].setVisible(true);

                status[i].setText(Status);
                status[i].setVisible(true);
            }
             }
            accep_1.setOnMouseClicked(e -> {
                
                    int num = 0;
                    handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_2.setOnMouseClicked(e -> {
                int num = 1;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_3.setOnMouseClicked(e -> {
                int num = 2;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_4.setOnMouseClicked(e -> {
                int num = 3;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_5.setOnMouseClicked(e -> {
                int num = 4;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_6.setOnMouseClicked(e -> {
                int num = 5;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                } 
            });
            accep_7.setOnMouseClicked(e -> {
                int num = 6;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            accep_8.setOnMouseClicked(e -> {
                int num = 7;
                handleAcceptIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }  
            });
            
            
            
            cancel_1.setOnMouseClicked(e -> {
                int num = 0;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }

            });
            cancel_2.setOnMouseClicked(e -> {
                int num = 1;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            cancel_3.setOnMouseClicked(e -> {
                int num = 2;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            cancel_4.setOnMouseClicked(e -> {
                int num = 3;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }   
            });
            cancel_5.setOnMouseClicked(e -> {
                int num = 4;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            cancel_6.setOnMouseClicked(e -> {
                int num = 5;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }            

            });
            cancel_7.setOnMouseClicked(e -> {
                int num = 6;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }   
            });
            cancel_8.setOnMouseClicked(e -> {
                int num = 7;
                handleCancelIcon(userNameLabels, username, num, imageViews ,status , acceptIcon , cancelIcon);
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendRequestScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }  
            });            

            friendListImage.setOnMouseClicked(e -> {
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchFriendsScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
            friendRequestImage.setOnMouseClicked(e -> {
                try {   
                    ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                    buttonSwitcher.switchAddFriendScene();
                } catch (IOException ex) {
                    Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
                }
            });

        } catch (IOException ex) {
            Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void handleAcceptIcon(Label[] userNameLabels, String username, int num, ImageView[] imageViews  , 
                                 Label[] status ,ImageView[] acceptIcon ,ImageView[] cancelIcon) {
        try {
            Socket SS = new Socket("localhost", 7001);
            PrintWriter output = new PrintWriter(SS.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(SS.getInputStream()));

            String send = "acceptFriend" + ":" + username + ":" + userNameLabels[num].getText() + ":" + "Pending";  //zezo  - malak / pendding
            output.println(send);
            String response = input.readLine();
            if (response.equals("true")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Send Friend Request");
                alert.setHeaderText(null);
                alert.setContentText("Congratulation for accepting " + userNameLabels[num].getText() + " as friend. ");
                alert.showAndWait();
            }

        } catch (IOException ex) {
            Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
        }

   
    }

    public void handleCancelIcon(Label[] userNameLabels, String username, int num, ImageView[] imageViews  , 
                                 Label[] status ,ImageView[] acceptIcon ,ImageView[] cancelIcon){
        try {
            Socket SS = new Socket("localhost", 7001);
            PrintWriter output = new PrintWriter(SS.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(SS.getInputStream()));

            String send = "cancelFriendRequest" + ":" + username + ":" + userNameLabels[num].getText() + ":" + "Pending";  //zezo  - malak / pendding
            output.println(send);
            String response = input.readLine();
            if (response.equals("true")) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Canceling friend request");
                alert.setHeaderText(null);
                alert.setContentText("You cancelled  " + userNameLabels[num].getText() + "'s request ");
                alert.showAndWait();
            }
        } catch (IOException ex) {
            Logger.getLogger(friendRequest.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
	public void notificationView(  String response , Text[] notification )
    {       
	    String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    }

}      