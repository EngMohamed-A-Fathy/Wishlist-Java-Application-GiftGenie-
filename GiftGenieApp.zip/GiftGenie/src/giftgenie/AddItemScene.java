package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.Cursor;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AddItemScene extends BorderPane {

    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final ImageView imageView0;
    protected final ImageView imageView1;
    protected final ImageView imageView2;
    protected final ImageView imageView3;
    protected final ImageView imageView4;
    protected final ImageView notificationIcon;
    protected final ImageView addMoney;
    protected final Button HomeButton;
    protected final Button MyWishlistButton;
    protected final Button AddItemButton;
    protected final Button FriendButton;
    protected final Button CashButton;
    protected final Button SignOutButt;
    protected final Text nameText;
    protected final Text moneyText;
    protected final ImageView imageView5;
    protected final Button SettingButton;
    protected final ImageView imageView6;
    protected final Button HelpButton;
    protected final ImageView imageView7;
    protected final ImageView devicesButt;
    protected final ImageView gamesButt;
    protected final ImageView clothButt;
    protected final ImageView img3;
    protected final ImageView img2;
    protected final ImageView img1;
    protected final ImageView img6;
    protected final ImageView img5;
    protected final ImageView img4;
    protected final Button text1;
    protected final Button p1;
    protected final ImageView add1;
    protected final Button text2;
    protected final Button p2;
    protected final ImageView add2;
    protected final Button text3;
    protected final Button p3;
    protected final ImageView add3;
    protected final Button text4;
    protected final Button p4;
    protected final ImageView add4;
    protected final Button text5;
    protected final Button p5;
    protected final ImageView add5;
    protected final Button text6;
    protected final Button p6;
    protected final ImageView add6;
    protected final ImageView img9;
    protected final ImageView img8;
    protected final ImageView img7;
    protected final ImageView img12;
    protected final ImageView img11;
    protected final ImageView img10;
    protected final Button text7;
    protected final Button p7;
    protected final ImageView add7;
    protected final Button text8;
    protected final Button p8;
    protected final ImageView add8;
    protected final Button text9;
    protected final ImageView add9;
    protected final Button text10;
    protected final Button p10;
    protected final ImageView add10;
    protected final Button text11;
    protected final Button p11;
    protected final ImageView add11;
    protected final Button text12;
    protected final Button p12;
    protected final ImageView add12;
    protected final Button p9;
    protected final ImageView img15;
    protected final ImageView img14;
    protected final ImageView img13;
    protected final ImageView img18;
    protected final ImageView img17;
    protected final ImageView img16;
    protected final Button text13;
    protected final Button p13;
    protected final ImageView add13;
    protected final Button text14;
    protected final Button p14;
    protected final ImageView add14;
    protected final Button text15;
    protected final ImageView add15;
    protected final Button text16;
    protected final Button p16;
    protected final ImageView add16;
    protected final Button text17;
    protected final Button p17;
    protected final ImageView add17;
    protected final Button text18;
    protected final Button p18;
    protected final ImageView add18;
    protected final Button p15;
    protected final ImageView notificationWindow;
    protected final Text not1;
    protected final Text not2;
    protected final Text not3;
    protected final Text not4;
    protected final Text not5;
    protected final Text not6;
    protected final Text not7;
    
    boolean notificationTurn = true;
    String backGroundPic = "background/222s.png";
    String currentMoney;
    String username; 
    public AddItemScene( Stage s , String username, String moneyValue, String pic) {
        
        this.username = username;
        backGroundPic = pic; 
        currentMoney = moneyValue;

        anchorPane = new AnchorPane();
        notificationIcon = new ImageView();
        imageView = new ImageView();
        imageView0 = new ImageView();
        imageView1 = new ImageView();
        imageView2 = new ImageView();
        imageView3 = new ImageView();
        imageView4 = new ImageView();
        addMoney = new ImageView();
        HomeButton = new Button();
        MyWishlistButton = new Button();
        AddItemButton = new Button();
        FriendButton = new Button();
        CashButton = new Button();
        SignOutButt = new Button();
        nameText = new Text();
        moneyText = new Text();
        imageView5 = new ImageView();
        SettingButton = new Button();
        imageView6 = new ImageView();
        HelpButton = new Button();
        imageView7 = new ImageView();
        devicesButt = new ImageView();
        gamesButt = new ImageView();
        clothButt = new ImageView();
        img3 = new ImageView();
        img2 = new ImageView();
        img1 = new ImageView();
        img6 = new ImageView();
        img5 = new ImageView();
        img4 = new ImageView();
        text1 = new Button();
        p1 = new Button();
        add1 = new ImageView();
        text2 = new Button();
        p2 = new Button();
        add2 = new ImageView();
        text3 = new Button();
        p3 = new Button();
        add3 = new ImageView();
        text4 = new Button();
        p4 = new Button();
        add4 = new ImageView();
        text5 = new Button();
        p5 = new Button();
        add5 = new ImageView();
        text6 = new Button();
        p6 = new Button();
        add6 = new ImageView();
        img9 = new ImageView();
        img8 = new ImageView();
        img7 = new ImageView();
        img12 = new ImageView();
        img11 = new ImageView();
        img10 = new ImageView();
        text7 = new Button();
        p7 = new Button();
        add7 = new ImageView();
        text8 = new Button();
        p8 = new Button();
        add8 = new ImageView();
        text9 = new Button();
        add9 = new ImageView();
        text10 = new Button();
        p10 = new Button();
        add10 = new ImageView();
        text11 = new Button();
        p11 = new Button();
        add11 = new ImageView();
        text12 = new Button();
        p12 = new Button();
        add12 = new ImageView();
        p9 = new Button();
        img15 = new ImageView();
        img14 = new ImageView();
        img13 = new ImageView();
        img18 = new ImageView();
        img17 = new ImageView();
        img16 = new ImageView();
        text13 = new Button();
        p13 = new Button();
        add13 = new ImageView();
        text14 = new Button();
        p14 = new Button();
        add14 = new ImageView();
        text15 = new Button();
        add15 = new ImageView();
        text16 = new Button();
        p16 = new Button();
        add16 = new ImageView();
        text17 = new Button();
        p17 = new Button();
        add17 = new ImageView();
        text18 = new Button();
        p18 = new Button();
        add18 = new ImageView();
        p15 = new Button();
		notificationWindow = new ImageView();
        not1 = new Text();
        not2 = new Text();
        not3 = new Text();
        not4 = new Text();
        not5 = new Text();
        not6 = new Text();
        not7 = new Text();

        setMaxHeight(700.0);
        setMaxWidth(1300.0);
        setMinHeight(500.0);
        setMinWidth(800.0);
        setPrefHeight(650.0);
        setPrefWidth(1100.0);
        setStyle("-fx-background-color: lightgray;");

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setMaxHeight(700.0);
        anchorPane.setMaxWidth(1105.0);
        anchorPane.setMinHeight(500.0);
        anchorPane.setMinWidth(200.0);
        anchorPane.setPrefHeight(650.0);
        anchorPane.setPrefWidth(1100.0);
        anchorPane.setStyle("-fx-background-color: darkblue;");

        imageView.setFitHeight(650.0);
        imageView.setFitWidth(1100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("background/222s.png").toExternalForm()));

        imageView0.setFitHeight(66.0);
        imageView0.setFitWidth(60.0);
        imageView0.setLayoutX(8.0);
        imageView0.setLayoutY(12.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(new Image(getClass().getResource("mesbah.png").toExternalForm()));

        imageView1.setFitHeight(77.0);
        imageView1.setFitWidth(74.0);
        imageView1.setLayoutX(4.0);
        imageView1.setLayoutY(65.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(new Image(getClass().getResource("wishlisticon.png").toExternalForm()));

        imageView2.setFitHeight(61.0);
        imageView2.setFitWidth(66.0);
        imageView2.setLayoutX(10.0);
        imageView2.setLayoutY(194.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        imageView2.setImage(new Image(getClass().getResource("friendsicon.png").toExternalForm()));

        imageView3.setFitHeight(51.0);
        imageView3.setFitWidth(59.0);
        imageView3.setLayoutX(15.0);
        imageView3.setLayoutY(260.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(new Image(getClass().getResource("generalIcon/Cash.png").toExternalForm()));

        imageView4.setFitHeight(61.0);
        imageView4.setFitWidth(65.0);
        imageView4.setLayoutX(18.0);
        imageView4.setLayoutY(134.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setImage(new Image(getClass().getResource("newitem.png").toExternalForm()));

        notificationIcon.setFitHeight(54.0);
        notificationIcon.setFitWidth(73.0);
        notificationIcon.setLayoutX(1032.0);
        notificationIcon.setPickOnBounds(true);
        notificationIcon.setPreserveRatio(true);
        notificationIcon.setCursor(Cursor.HAND);
        notificationIcon.setImage(new Image(getClass().getResource("notify.png").toExternalForm()));

        addMoney.setFitHeight(42.0);
        addMoney.setFitWidth(41.0);
        addMoney.setLayoutX(975.0);
        addMoney.setLayoutY(8.0);
        addMoney.setPickOnBounds(true);
        addMoney.setPreserveRatio(true);
        addMoney.setCursor(Cursor.HAND);
        addMoney.setImage(new Image(getClass().getResource("addmoney.png").toExternalForm()));

        HomeButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HomeButton.setLayoutX(77.0);
        HomeButton.setLayoutY(23.0);
        HomeButton.setMnemonicParsing(false);
        HomeButton.setOpacity(0.7);
        HomeButton.setPrefHeight(51.0);
        HomeButton.setPrefWidth(164.0);
        HomeButton.setStyle("-fx-background-color: Transparent; -fx-border-radius: 30; -fx-background-radius: 30;");
        HomeButton.setText("GiftGenie");
        HomeButton.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        HomeButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HomeButton.setCursor(Cursor.HAND);
        HomeButton.setFont(new Font("System Bold", 24.0));

        MyWishlistButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        MyWishlistButton.setLayoutX(77.0);
        MyWishlistButton.setLayoutY(81.0);
        MyWishlistButton.setMnemonicParsing(false);
        MyWishlistButton.setOpacity(0.7);
        MyWishlistButton.setPrefHeight(51.0);
        MyWishlistButton.setPrefWidth(164.0);
        MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        MyWishlistButton.setText("MyWishlist");
        MyWishlistButton.setTextFill(javafx.scene.paint.Color.WHITE);
        MyWishlistButton.setCursor(Cursor.HAND);
        MyWishlistButton.setFont(new Font("System Bold", 24.0));

        AddItemButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        AddItemButton.setLayoutX(76.0);
        AddItemButton.setLayoutY(140.0);
        AddItemButton.setMnemonicParsing(false);
        AddItemButton.setOpacity(0.7);
        AddItemButton.setPrefHeight(51.0);
        AddItemButton.setPrefWidth(164.0);
        AddItemButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        AddItemButton.setText("Add Item");
        AddItemButton.setTextFill(javafx.scene.paint.Color.WHITE);
        AddItemButton.setFont(new Font("System Bold", 24.0));

        FriendButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        FriendButton.setLayoutX(77.0);
        FriendButton.setLayoutY(199.0);
        FriendButton.setMnemonicParsing(false);
        FriendButton.setOpacity(0.7);
        FriendButton.setPrefHeight(51.0);
        FriendButton.setPrefWidth(164.0);
        FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        FriendButton.setText("My Friends");
        FriendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        FriendButton.setCursor(Cursor.HAND);
        FriendButton.setFont(new Font("System Bold", 24.0));

        CashButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        CashButton.setLayoutX(79.0);
        CashButton.setLayoutY(257.0);
        CashButton.setMnemonicParsing(false);
        CashButton.setOpacity(0.7);
        CashButton.setPrefHeight(51.0);
        CashButton.setPrefWidth(164.0);
        CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        CashButton.setText("Cash");
        CashButton.setTextFill(javafx.scene.paint.Color.WHITE);
        CashButton.setCursor(Cursor.HAND);
        CashButton.setFont(new Font("System Bold", 24.0));

        SignOutButt.setLayoutX(187.0);
        SignOutButt.setLayoutY(600.0);
        SignOutButt.setMnemonicParsing(false);
        SignOutButt.setOpacity(0.7);
        SignOutButt.setPrefHeight(43.0);
        SignOutButt.setPrefWidth(94.0);
        SignOutButt.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
        SignOutButt.setText("SignOut");
        SignOutButt.setTextFill(javafx.scene.paint.Color.WHITE);
        SignOutButt.setCursor(Cursor.HAND);
        SignOutButt.setFont(new Font("System Bold", 18.0));

        nameText.setLayoutX(802.0);
        nameText.setLayoutY(33.0);
        nameText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        nameText.setStrokeWidth(0.0);
        nameText.setText("Hello");
        nameText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        nameText.setWrappingWidth(74.13671875);
        nameText.setFont(new Font(14.0));

        moneyText.setLayoutX(940.0);
        moneyText.setLayoutY(33.0);
        moneyText.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        moneyText.setStrokeWidth(0.0);
        moneyText.setText("1000");
        moneyText.setWrappingWidth(55.13671875);
        moneyText.setFont(new Font(14.0));

        imageView5.setFitHeight(51.0);
        imageView5.setFitWidth(59.0);
        imageView5.setLayoutX(17.0);
        imageView5.setLayoutY(316.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(new Image(getClass().getResource("settingicon.png").toExternalForm()));

        SettingButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        SettingButton.setLayoutX(78.0);
        SettingButton.setLayoutY(314.0);
        SettingButton.setMnemonicParsing(false);
        SettingButton.setOpacity(0.7);
        SettingButton.setPrefHeight(51.0);
        SettingButton.setPrefWidth(164.0);
        SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        SettingButton.setText("Setting");
        SettingButton.setTextFill(javafx.scene.paint.Color.WHITE);
        SettingButton.setCursor(Cursor.HAND);
        SettingButton.setFont(new Font("System Bold", 24.0));

        imageView6.setFitHeight(51.0);
        imageView6.setFitWidth(59.0);
        imageView6.setLayoutX(19.0);
        imageView6.setLayoutY(378.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(new Image(getClass().getResource("helpicon.png").toExternalForm()));

        HelpButton.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        HelpButton.setLayoutX(79.0);
        HelpButton.setLayoutY(376.0);
        HelpButton.setMnemonicParsing(false);
        HelpButton.setOpacity(0.7);
        HelpButton.setPrefHeight(51.0);
        HelpButton.setPrefWidth(164.0);
        HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        HelpButton.setText("Help");
        HelpButton.setTextFill(javafx.scene.paint.Color.WHITE);
        HelpButton.setCursor(Cursor.HAND);
        HelpButton.setFont(new Font("System Bold", 24.0));

        imageView7.setFitHeight(79.0);
        imageView7.setFitWidth(263.0);
        imageView7.setLayoutX(328.0);
        imageView7.setLayoutY(50.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(new Image(getClass().getResource("AddItem/WelcomeStore.png").toExternalForm()));

        devicesButt.setFitHeight(54.0);
        devicesButt.setFitWidth(152.0);
        devicesButt.setLayoutX(382.0);
        devicesButt.setLayoutY(162.0);
        devicesButt.setPickOnBounds(true);
        devicesButt.setPreserveRatio(true);
        devicesButt.setCursor(Cursor.HAND);
        devicesButt.setImage(new Image(getClass().getResource("AddItem/Devices.png").toExternalForm()));

        gamesButt.setFitHeight(50.0);
        gamesButt.setFitWidth(176.0);
        gamesButt.setLayoutX(613.0);
        gamesButt.setLayoutY(163.0);
        gamesButt.setPickOnBounds(true);
        gamesButt.setPreserveRatio(true);
        gamesButt.setCursor(Cursor.HAND);
        gamesButt.setImage(new Image(getClass().getResource("AddItem/Games.png").toExternalForm()));

        clothButt.setFitHeight(54.0);
        clothButt.setFitWidth(152.0);
        clothButt.setLayoutX(826.0);
        clothButt.setLayoutY(161.0);
        clothButt.setPickOnBounds(true);
        clothButt.setPreserveRatio(true);
        clothButt.setCursor(Cursor.HAND);
        clothButt.setImage(new Image(getClass().getResource("AddItem/Clothes.png").toExternalForm()));

        img3.setFitHeight(145.0);
        img3.setFitWidth(239.0);
        img3.setLayoutX(852.0);
        img3.setLayoutY(246.0);
        img3.setPickOnBounds(true);
        img3.setPreserveRatio(true);
        img3.setImage(new Image(getClass().getResource("AddItem/Devices/3.png").toExternalForm()));

        img2.setFitHeight(215.0);
        img2.setFitWidth(250.0);
        img2.setLayoutX(584.0);
        img2.setLayoutY(241.0);
        img2.setPickOnBounds(true);
        img2.setPreserveRatio(true);
        img2.setImage(new Image(getClass().getResource("AddItem/Devices/2.png").toExternalForm()));

        img1.setFitHeight(156.0);
        img1.setFitWidth(278.0);
        img1.setLayoutX(309.0);
        img1.setLayoutY(236.0);
        img1.setPickOnBounds(true);
        img1.setPreserveRatio(true);
        img1.setImage(new Image(getClass().getResource("AddItem/Devices/1.png").toExternalForm()));

        img6.setFitHeight(215.0);
        img6.setFitWidth(250.0);
        img6.setLayoutX(843.0);
        img6.setLayoutY(450.0);
        img6.setPickOnBounds(true);
        img6.setPreserveRatio(true);
        img6.setImage(new Image(getClass().getResource("AddItem/Devices/6.png").toExternalForm()));

        img5.setFitHeight(160.0);
        img5.setFitWidth(262.0);
        img5.setLayoutX(581.0);
        img5.setLayoutY(440.0);
        img5.setPickOnBounds(true);
        img5.setPreserveRatio(true);
        img5.setImage(new Image(getClass().getResource("AddItem/Devices/5.png").toExternalForm()));

        img4.setFitHeight(162.0);
        img4.setFitWidth(276.0);
        img4.setLayoutX(299.0);
        img4.setLayoutY(438.0);
        img4.setPickOnBounds(true);
        img4.setPreserveRatio(true);
        img4.setImage(new Image(getClass().getResource("AddItem/Devices/4.png").toExternalForm()));

        text1.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text1.setLayoutX(328.0);
        text1.setLayoutY(383.0);
        text1.setMnemonicParsing(false);
        text1.setOpacity(0.7);
        text1.setPrefHeight(27.0);
        text1.setPrefWidth(156.0);
        text1.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text1.setText("Asus Laptop");
        text1.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text1.setTextFill(javafx.scene.paint.Color.WHITE);
        text1.setFont(new Font("System Bold", 18.0));

        p1.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p1.setLayoutX(479.0);
        p1.setLayoutY(383.0);
        p1.setMnemonicParsing(false);
        p1.setOpacity(0.7);
        p1.setPrefHeight(16.0);
        p1.setPrefWidth(74.0);
        p1.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p1.setText("1000");
        p1.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p1.setTextFill(javafx.scene.paint.Color.WHITE);
        p1.setFont(new Font("System Bold", 18.0));

        add1.setFitHeight(30.0);
        add1.setFitWidth(34.0);
        add1.setLayoutX(458.0);
        add1.setLayoutY(388.0);
        add1.setPickOnBounds(true);
        add1.setPreserveRatio(true);
        add1.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add1.setCursor(Cursor.HAND);

        text2.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text2.setLayoutX(595.0);
        text2.setLayoutY(382.0);
        text2.setMnemonicParsing(false);
        text2.setOpacity(0.7);
        text2.setPrefHeight(27.0);
        text2.setPrefWidth(156.0);
        text2.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text2.setText("Apple Mac Pro");
        text2.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text2.setTextFill(javafx.scene.paint.Color.WHITE);
        text2.setFont(new Font("System Bold", 18.0));

        p2.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p2.setLayoutX(761.0);
        p2.setLayoutY(383.0);
        p2.setMnemonicParsing(false);
        p2.setOpacity(0.7);
        p2.setPrefHeight(16.0);
        p2.setPrefWidth(74.0);
        p2.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p2.setText("1950");
        p2.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p2.setTextFill(javafx.scene.paint.Color.WHITE);
        p2.setFont(new Font("System Bold", 18.0));

        add2.setFitHeight(30.0);
        add2.setFitWidth(34.0);
        add2.setLayoutX(741.0);
        add2.setLayoutY(387.0);
        add2.setPickOnBounds(true);
        add2.setPreserveRatio(true);
        add2.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add2.setCursor(Cursor.HAND);

        text3.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text3.setLayoutX(860.0);
        text3.setLayoutY(384.0);
        text3.setMnemonicParsing(false);
        text3.setOpacity(0.7);
        text3.setPrefHeight(39.0);
        text3.setPrefWidth(194.0);
        text3.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text3.setText("Playstation 5");
        text3.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text3.setTextFill(javafx.scene.paint.Color.WHITE);
        text3.setFont(new Font("System Bold", 18.0));

        p3.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p3.setLayoutX(1021.0);
        p3.setLayoutY(385.0);
        p3.setMnemonicParsing(false);
        p3.setOpacity(0.7);
        p3.setPrefHeight(16.0);
        p3.setPrefWidth(74.0);
        p3.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p3.setText("700");
        p3.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p3.setTextFill(javafx.scene.paint.Color.WHITE);
        p3.setFont(new Font("System Bold", 18.0));

        add3.setFitHeight(30.0);
        add3.setFitWidth(34.0);
        add3.setLayoutX(1000.0);
        add3.setLayoutY(389.0);
        add3.setPickOnBounds(true);
        add3.setPreserveRatio(true);
        add3.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add3.setCursor(Cursor.HAND);

        text4.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text4.setLayoutX(328.0);
        text4.setLayoutY(596.0);
        text4.setMnemonicParsing(false);
        text4.setOpacity(0.7);
        text4.setPrefHeight(27.0);
        text4.setPrefWidth(156.0);
        text4.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text4.setText("Laptop Table");
        text4.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text4.setTextFill(javafx.scene.paint.Color.WHITE);
        text4.setFont(new Font("System Bold", 18.0));

        p4.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p4.setLayoutX(479.0);
        p4.setLayoutY(597.0);
        p4.setMnemonicParsing(false);
        p4.setOpacity(0.7);
        p4.setPrefHeight(16.0);
        p4.setPrefWidth(74.0);
        p4.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p4.setText("200");
        p4.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p4.setTextFill(javafx.scene.paint.Color.WHITE);
        p4.setFont(new Font("System Bold", 18.0));

        add4.setFitHeight(30.0);
        add4.setFitWidth(34.0);
        add4.setLayoutX(458.0);
        add4.setLayoutY(601.0);
        add4.setPickOnBounds(true);
        add4.setPreserveRatio(true);
        add4.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add4.setCursor(Cursor.HAND);

        text5.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text5.setLayoutX(595.0);
        text5.setLayoutY(598.0);
        text5.setMnemonicParsing(false);
        text5.setOpacity(0.7);
        text5.setPrefHeight(27.0);
        text5.setPrefWidth(156.0);
        text5.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text5.setText("MT 9020 PC");
        text5.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text5.setTextFill(javafx.scene.paint.Color.WHITE);
        text5.setFont(new Font("System Bold", 18.0));

        p5.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p5.setLayoutX(762.0);
        p5.setLayoutY(599.0);
        p5.setMnemonicParsing(false);
        p5.setOpacity(0.7);
        p5.setPrefHeight(16.0);
        p5.setPrefWidth(74.0);
        p5.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p5.setText("600");
        p5.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p5.setTextFill(javafx.scene.paint.Color.WHITE);
        p5.setFont(new Font("System Bold", 18.0));

        add5.setFitHeight(30.0);
        add5.setFitWidth(34.0);
        add5.setLayoutX(741.0);
        add5.setLayoutY(603.0);
        add5.setPickOnBounds(true);
        add5.setPreserveRatio(true);
        add5.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add5.setCursor(Cursor.HAND);

        text6.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text6.setLayoutX(860.0);
        text6.setLayoutY(600.0);
        text6.setMnemonicParsing(false);
        text6.setOpacity(0.7);
        text6.setPrefHeight(39.0);
        text6.setPrefWidth(194.0);
        text6.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text6.setText("Samsong TV");
        text6.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text6.setTextFill(javafx.scene.paint.Color.WHITE);
        text6.setFont(new Font("System Bold", 18.0));

        p6.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p6.setLayoutX(1022.0);
        p6.setLayoutY(600.0);
        p6.setMnemonicParsing(false);
        p6.setOpacity(0.7);
        p6.setPrefHeight(16.0);
        p6.setPrefWidth(74.0);
        p6.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p6.setText("1100");
        p6.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p6.setTextFill(javafx.scene.paint.Color.WHITE);
        p6.setFont(new Font("System Bold", 18.0));

        add6.setFitHeight(30.0);
        add6.setFitWidth(34.0);
        add6.setLayoutX(1003.0);
        add6.setLayoutY(605.0);
        add6.setPickOnBounds(true);
        add6.setPreserveRatio(true);
        add6.setVisible(true);
        add6.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add6.setCursor(Cursor.HAND);

        img9.setFitHeight(166.0);
        img9.setFitWidth(137.0);
        img9.setLayoutX(904.0);
        img9.setLayoutY(229.0);
        img9.setPickOnBounds(true);
        img9.setPreserveRatio(true);
        img9.setVisible(false);
        img9.setImage(new Image(getClass().getResource("AddItem/Games/9.png").toExternalForm()));

        img8.setFitHeight(164.0);
        img8.setFitWidth(134.0);
        img8.setLayoutX(651.0);
        img8.setLayoutY(226.0);
        img8.setPickOnBounds(true);
        img8.setPreserveRatio(true);
        img8.setVisible(false);
        img8.setImage(new Image(getClass().getResource("AddItem/Games/8.png").toExternalForm()));

        img7.setFitHeight(166.0);
        img7.setFitWidth(149.0);
        img7.setLayoutX(373.0);
        img7.setLayoutY(225.0);
        img7.setPickOnBounds(true);
        img7.setPreserveRatio(true);
        img7.setVisible(false);
        img7.setImage(new Image(getClass().getResource("AddItem/Games/7.png").toExternalForm()));

        img12.setFitHeight(170.0);
        img12.setFitWidth(133.0);
        img12.setLayoutX(904.0);
        img12.setLayoutY(432.0);
        img12.setPickOnBounds(true);
        img12.setPreserveRatio(true);
        img12.setVisible(false);
        img12.setImage(new Image(getClass().getResource("AddItem/Games/12.png").toExternalForm()));

        img11.setFitHeight(170.0);
        img11.setFitWidth(141.0);
        img11.setLayoutX(654.0);
        img11.setLayoutY(429.0);
        img11.setPickOnBounds(true);
        img11.setPreserveRatio(true);
        img11.setVisible(false);
        img11.setImage(new Image(getClass().getResource("AddItem/Games/11.png").toExternalForm()));

        img10.setFitHeight(177.0);
        img10.setFitWidth(134.0);
        img10.setLayoutX(371.0);
        img10.setLayoutY(422.0);
        img10.setPickOnBounds(true);
        img10.setPreserveRatio(true);
        img10.setVisible(false);
        img10.setImage(new Image(getClass().getResource("AddItem/Games/10.png").toExternalForm()));

        text7.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text7.setLayoutX(337.0);
        text7.setLayoutY(382.0);
        text7.setMnemonicParsing(false);
        text7.setOpacity(0.7);
        text7.setPrefHeight(27.0);
        text7.setPrefWidth(156.0);
        text7.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text7.setText("A WAY OUT");
        text7.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text7.setTextFill(javafx.scene.paint.Color.WHITE);
        text7.setVisible(false);
        text7.setFont(new Font("System Bold", 18.0));

        p7.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p7.setLayoutX(479.0);
        p7.setLayoutY(382.0);
        p7.setMnemonicParsing(false);
        p7.setOpacity(0.7);
        p7.setPrefHeight(16.0);
        p7.setPrefWidth(74.0);
        p7.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p7.setText("29");
        p7.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p7.setTextFill(javafx.scene.paint.Color.WHITE);
        p7.setVisible(false);
        p7.setFont(new Font("System Bold", 18.0));

        add7.setFitHeight(30.0);
        add7.setFitWidth(34.0);
        add7.setLayoutX(458.0);
        add7.setLayoutY(387.0);
        add7.setPickOnBounds(true);
        add7.setPreserveRatio(true);
        add7.setVisible(false);
        add7.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add7.setCursor(Cursor.HAND);

        text8.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text8.setLayoutX(641.0);
        text8.setLayoutY(383.0);
        text8.setMnemonicParsing(false);
        text8.setOpacity(0.7);
        text8.setPrefHeight(27.0);
        text8.setPrefWidth(156.0);
        text8.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text8.setText("FARCRY6");
        text8.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text8.setTextFill(javafx.scene.paint.Color.WHITE);
        text8.setVisible(false);
        text8.setFont(new Font("System Bold", 18.0));

        p8.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p8.setLayoutX(761.0);
        p8.setLayoutY(382.0);
        p8.setMnemonicParsing(false);
        p8.setOpacity(0.7);
        p8.setPrefHeight(16.0);
        p8.setPrefWidth(74.0);
        p8.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p8.setText("25");
        p8.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p8.setTextFill(javafx.scene.paint.Color.WHITE);
        p8.setVisible(false);
        p8.setFont(new Font("System Bold", 18.0));

        add8.setFitHeight(30.0);
        add8.setFitWidth(34.0);
        add8.setLayoutX(741.0);
        add8.setLayoutY(386.0);
        add8.setPickOnBounds(true);
        add8.setPreserveRatio(true);
        add8.setVisible(false);
        add8.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add8.setCursor(Cursor.HAND);

        text9.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text9.setLayoutX(902.0);
        text9.setLayoutY(386.0);
        text9.setMnemonicParsing(false);
        text9.setOpacity(0.7);
        text9.setPrefHeight(39.0);
        text9.setPrefWidth(194.0);
        text9.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text9.setText("FIFA23");
        text9.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text9.setTextFill(javafx.scene.paint.Color.WHITE);
        text9.setVisible(false);
        text9.setFont(new Font("System Bold", 18.0));

        add9.setFitHeight(30.0);
        add9.setFitWidth(34.0);
        add9.setLayoutX(1000.0);
        add9.setLayoutY(388.0);
        add9.setPickOnBounds(true);
        add9.setPreserveRatio(true);
        add9.setVisible(false);
        add9.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add9.setCursor(Cursor.HAND);

        text10.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text10.setLayoutX(332.0);
        text10.setLayoutY(596.0);
        text10.setMnemonicParsing(false);
        text10.setOpacity(0.7);
        text10.setPrefHeight(27.0);
        text10.setPrefWidth(156.0);
        text10.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text10.setText("REDDEAD 2");
        text10.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text10.setTextFill(javafx.scene.paint.Color.WHITE);
        text10.setVisible(false);
        text10.setFont(new Font("System Bold", 18.0));

        p10.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p10.setLayoutX(479.0);
        p10.setLayoutY(596.0);
        p10.setMnemonicParsing(false);
        p10.setOpacity(0.7);
        p10.setPrefHeight(16.0);
        p10.setPrefWidth(74.0);
        p10.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p10.setText("27");
        p10.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p10.setTextFill(javafx.scene.paint.Color.WHITE);
        p10.setVisible(false);
        p10.setFont(new Font("System Bold", 18.0));

        add10.setFitHeight(30.0);
        add10.setFitWidth(34.0);
        add10.setLayoutX(458.0);
        add10.setLayoutY(600.0);
        add10.setPickOnBounds(true);
        add10.setPreserveRatio(true);
        add10.setVisible(false);
        add10.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add10.setCursor(Cursor.HAND);

        text11.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text11.setLayoutX(605.0);
        text11.setLayoutY(599.0);
        text11.setMnemonicParsing(false);
        text11.setOpacity(0.7);
        text11.setPrefHeight(27.0);
        text11.setPrefWidth(156.0);
        text11.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text11.setText("UNCHARTED");
        text11.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text11.setTextFill(javafx.scene.paint.Color.WHITE);
        text11.setVisible(false);
        text11.setFont(new Font("System Bold", 18.0));

        p11.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p11.setLayoutX(762.0);
        p11.setLayoutY(598.0);
        p11.setMnemonicParsing(false);
        p11.setOpacity(0.7);
        p11.setPrefHeight(16.0);
        p11.setPrefWidth(74.0);
        p11.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p11.setText("36");
        p11.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p11.setTextFill(javafx.scene.paint.Color.WHITE);
        p11.setVisible(false);
        p11.setFont(new Font("System Bold", 18.0));

        add11.setFitHeight(30.0);
        add11.setFitWidth(34.0);
        add11.setLayoutX(741.0);
        add11.setLayoutY(602.0);
        add11.setPickOnBounds(true);
        add11.setPreserveRatio(true);
        add11.setVisible(false);
        add11.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add11.setCursor(Cursor.HAND);

        text12.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text12.setLayoutX(860.0);
        text12.setLayoutY(599.0);
        text12.setMnemonicParsing(false);
        text12.setOpacity(0.7);
        text12.setPrefHeight(39.0);
        text12.setPrefWidth(194.0);
        text12.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text12.setText("CALL OF DUTY");
        text12.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text12.setTextFill(javafx.scene.paint.Color.WHITE);
        text12.setVisible(false);
        text12.setFont(new Font("System Bold", 18.0));

        p12.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p12.setLayoutX(1022.0);
        p12.setLayoutY(599.0);
        p12.setMnemonicParsing(false);
        p12.setOpacity(0.7);
        p12.setPrefHeight(16.0);
        p12.setPrefWidth(74.0);
        p12.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p12.setText("75");
        p12.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p12.setTextFill(javafx.scene.paint.Color.WHITE);
        p12.setVisible(false);
        p12.setFont(new Font("System Bold", 18.0));

        add12.setFitHeight(30.0);
        add12.setFitWidth(34.0);
        add12.setLayoutX(1003.0);
        add12.setLayoutY(604.0);
        add12.setPickOnBounds(true);
        add12.setPreserveRatio(true);
        add12.setVisible(false);
        add12.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add12.setCursor(Cursor.HAND);

        p9.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p9.setLayoutX(1020.0);
        p9.setLayoutY(385.0);
        p9.setMnemonicParsing(false);
        p9.setOpacity(0.7);
        p9.setPrefHeight(16.0);
        p9.setPrefWidth(74.0);
        p9.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p9.setText("53");
        p9.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p9.setTextFill(javafx.scene.paint.Color.WHITE);
        p9.setVisible(false);
        p9.setFont(new Font("System Bold", 18.0));

        img15.setFitHeight(166.0);
        img15.setFitWidth(137.0);
        img15.setLayoutX(904.0);
        img15.setLayoutY(229.0);
        img15.setPickOnBounds(true);
        img15.setPreserveRatio(true);
        img15.setVisible(false);
        img15.setImage(new Image(getClass().getResource("AddItem/Devices/15.png").toExternalForm()));

        img14.setFitHeight(164.0);
        img14.setFitWidth(134.0);
        img14.setLayoutX(651.0);
        img14.setLayoutY(226.0);
        img14.setPickOnBounds(true);
        img14.setPreserveRatio(true);
        img14.setVisible(false);
        img14.setImage(new Image(getClass().getResource("AddItem/Devices/14.png").toExternalForm()));

        img13.setFitHeight(166.0);
        img13.setFitWidth(149.0);
        img13.setLayoutX(373.0);
        img13.setLayoutY(225.0);
        img13.setPickOnBounds(true);
        img13.setPreserveRatio(true);
        img13.setVisible(false);
        img13.setImage(new Image(getClass().getResource("AddItem/Devices/13.png").toExternalForm()));

        img18.setFitHeight(170.0);
        img18.setFitWidth(133.0);
        img18.setLayoutX(904.0);
        img18.setLayoutY(432.0);
        img18.setPickOnBounds(true);
        img18.setPreserveRatio(true);
        img18.setVisible(false);
        img18.setImage(new Image(getClass().getResource("AddItem/Devices/18.png").toExternalForm()));

        img17.setFitHeight(170.0);
        img17.setFitWidth(141.0);
        img17.setLayoutX(654.0);
        img17.setLayoutY(429.0);
        img17.setPickOnBounds(true);
        img17.setPreserveRatio(true);
        img17.setVisible(false);
        img17.setImage(new Image(getClass().getResource("AddItem/Devices/17.png").toExternalForm()));

        img16.setFitHeight(177.0);
        img16.setFitWidth(134.0);
        img16.setLayoutX(371.0);
        img16.setLayoutY(432.0);
        img16.setPickOnBounds(true);
        img16.setPreserveRatio(true);
        img16.setVisible(false);
        img16.setImage(new Image(getClass().getResource("AddItem/Devices/16.png").toExternalForm()));

        text13.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text13.setLayoutX(372.0);
        text13.setLayoutY(382.0);
        text13.setMnemonicParsing(false);
        text13.setOpacity(0.7);
        text13.setPrefHeight(39.0);
        text13.setPrefWidth(79.0);
        text13.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text13.setText("Jacket");
        text13.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text13.setTextFill(javafx.scene.paint.Color.WHITE);
        text13.setVisible(false);
        text13.setFont(new Font("System Bold", 18.0));

        p13.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p13.setLayoutX(479.0);
        p13.setLayoutY(382.0);
        p13.setMnemonicParsing(false);
        p13.setOpacity(0.7);
        p13.setPrefHeight(16.0);
        p13.setPrefWidth(74.0);
        p13.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p13.setText("50");
        p13.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p13.setTextFill(javafx.scene.paint.Color.WHITE);
        p13.setVisible(false);
        p13.setFont(new Font("System Bold", 18.0));

        add13.setFitHeight(30.0);
        add13.setFitWidth(34.0);
        add13.setLayoutX(458.0);
        add13.setLayoutY(387.0);
        add13.setPickOnBounds(true);
        add13.setPreserveRatio(true);
        add13.setVisible(false);
        add13.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add13.setCursor(Cursor.HAND);

        text14.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text14.setLayoutX(666.0);
        text14.setLayoutY(381.0);
        text14.setMnemonicParsing(false);
        text14.setOpacity(0.7);
        text14.setPrefHeight(39.0);
        text14.setPrefWidth(74.0);
        text14.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text14.setText("Jeans");
        text14.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text14.setTextFill(javafx.scene.paint.Color.WHITE);
        text14.setVisible(false);
        text14.setFont(new Font("System Bold", 18.0));

        p14.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p14.setLayoutX(761.0);
        p14.setLayoutY(382.0);
        p14.setMnemonicParsing(false);
        p14.setOpacity(0.7);
        p14.setPrefHeight(16.0);
        p14.setPrefWidth(74.0);
        p14.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p14.setText("45");
        p14.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p14.setTextFill(javafx.scene.paint.Color.WHITE);
        p14.setVisible(false);
        p14.setFont(new Font("System Bold", 18.0));

        add14.setFitHeight(30.0);
        add14.setFitWidth(34.0);
        add14.setLayoutX(741.0);
        add14.setLayoutY(386.0);
        add14.setPickOnBounds(true);
        add14.setPreserveRatio(true);
        add14.setVisible(false);
        add14.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add14.setCursor(Cursor.HAND);

        text15.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text15.setLayoutX(902.0);
        text15.setLayoutY(383.0);
        text15.setMnemonicParsing(false);
        text15.setOpacity(0.7);
        text15.setPrefHeight(39.0);
        text15.setPrefWidth(89.0);
        text15.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text15.setText("T-shirt");
        text15.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text15.setTextFill(javafx.scene.paint.Color.WHITE);
        text15.setVisible(false);
        text15.setFont(new Font("System Bold", 18.0));

        add15.setFitHeight(30.0);
        add15.setFitWidth(34.0);
        add15.setLayoutX(1000.0);
        add15.setLayoutY(388.0);
        add15.setPickOnBounds(true);
        add15.setPreserveRatio(true);
        add15.setVisible(false);
        add15.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add15.setCursor(Cursor.HAND);

        text16.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text16.setLayoutX(354.0);
        text16.setLayoutY(593.0);
        text16.setMnemonicParsing(false);
        text16.setOpacity(0.7);
        text16.setPrefHeight(39.0);
        text16.setPrefWidth(112.0);
        text16.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text16.setText("Red shoes");
        text16.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text16.setTextFill(javafx.scene.paint.Color.WHITE);
        text16.setVisible(false);
        text16.setFont(new Font("System Bold", 18.0));

        p16.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p16.setLayoutX(479.0);
        p16.setLayoutY(596.0);
        p16.setMnemonicParsing(false);
        p16.setOpacity(0.7);
        p16.setPrefHeight(39.0);
        p16.setPrefWidth(55.0);
        p16.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p16.setText("33");
        p16.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p16.setTextFill(javafx.scene.paint.Color.WHITE);
        p16.setVisible(false);
        p16.setFont(new Font("System Bold", 18.0));

        add16.setFitHeight(30.0);
        add16.setFitWidth(34.0);
        add16.setLayoutX(458.0);
        add16.setLayoutY(600.0);
        add16.setPickOnBounds(true);
        add16.setPreserveRatio(true);
        add16.setVisible(false);
        add16.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add16.setCursor(Cursor.HAND);

        text17.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text17.setLayoutX(613.0);
        text17.setLayoutY(596.0);
        text17.setMnemonicParsing(false);
        text17.setOpacity(0.7);
        text17.setPrefHeight(39.0);
        text17.setPrefWidth(130.0);
        text17.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text17.setText("Black shoes");
        text17.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text17.setTextFill(javafx.scene.paint.Color.WHITE);
        text17.setVisible(false);
        text17.setFont(new Font("System Bold", 18.0));

        p17.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p17.setLayoutX(762.0);
        p17.setLayoutY(598.0);
        p17.setMnemonicParsing(false);
        p17.setOpacity(0.7);
        p17.setPrefHeight(16.0);
        p17.setPrefWidth(74.0);
        p17.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p17.setText("42");
        p17.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p17.setTextFill(javafx.scene.paint.Color.WHITE);
        p17.setVisible(false);
        p17.setFont(new Font("System Bold", 18.0));

        add17.setFitHeight(30.0);
        add17.setFitWidth(34.0);
        add17.setLayoutX(741.0);
        add17.setLayoutY(602.0);
        add17.setPickOnBounds(true);
        add17.setPreserveRatio(true);
        add17.setVisible(false);
        add17.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add17.setCursor(Cursor.HAND);

        text18.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        text18.setLayoutX(906.0);
        text18.setLayoutY(599.0);
        text18.setMnemonicParsing(false);
        text18.setOpacity(0.7);
        text18.setPrefHeight(39.0);
        text18.setPrefWidth(87.0);
        text18.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        text18.setText("Heels");
        text18.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        text18.setTextFill(javafx.scene.paint.Color.WHITE);
        text18.setVisible(false);
        text18.setFont(new Font("System Bold", 18.0));

        p18.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p18.setLayoutX(1022.0);
        p18.setLayoutY(599.0);
        p18.setMnemonicParsing(false);
        p18.setOpacity(0.7);
        p18.setPrefHeight(16.0);
        p18.setPrefWidth(74.0);
        p18.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p18.setText("57");
        p18.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p18.setTextFill(javafx.scene.paint.Color.WHITE);
        p18.setVisible(false);
        p18.setFont(new Font("System Bold", 18.0));

        add18.setFitHeight(30.0);
        add18.setFitWidth(34.0);
        add18.setLayoutX(1003.0);
        add18.setLayoutY(604.0);
        add18.setPickOnBounds(true);
        add18.setPreserveRatio(true);
        add18.setVisible(false);
        add18.setImage(new Image(getClass().getResource("AddItem/ADD.png").toExternalForm()));
        add18.setCursor(Cursor.HAND);

        p15.setAlignment(javafx.geometry.Pos.BOTTOM_LEFT);
        p15.setLayoutX(1020.0);
        p15.setLayoutY(385.0);
        p15.setMnemonicParsing(false);
        p15.setOpacity(0.7);
        p15.setPrefHeight(16.0);
        p15.setPrefWidth(74.0);
        p15.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
        p15.setText("30");
        p15.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        p15.setTextFill(javafx.scene.paint.Color.WHITE);
        p15.setVisible(false);
        p15.setFont(new Font("System Bold", 18.0));
        setCenter(anchorPane);
		
		notificationWindow.setFitHeight(368.0);
        notificationWindow.setFitWidth(200.0);
        notificationWindow.setLayoutX(886.0);
        notificationWindow.setLayoutY(45.0);
        notificationWindow.setPickOnBounds(true);
        notificationWindow.setPreserveRatio(true);
        notificationWindow.setVisible(false);
        notificationWindow.setImage(new Image(getClass().getResource("generalIcon/notifyWindow.png").toExternalForm()));

        not1.setLayoutX(935.0);
        not1.setLayoutY(81.0);
        not1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not1.setStrokeWidth(0.0);
        not1.setText("-");
        not1.setVisible(false);
        not1.setWrappingWidth(126.818359375);
        not1.setFont(new Font("System Bold", 12.0));

        not2.setLayoutX(935.0);
        not2.setLayoutY(125.0);
        not2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not2.setStrokeWidth(0.0);
        not2.setText("-");
        not2.setVisible(false);
        not2.setWrappingWidth(126.818359375);
        not2.setFont(new Font("System Bold", 12.0));

        not3.setLayoutX(934.0);
        not3.setLayoutY(166.0);
        not3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not3.setStrokeWidth(0.0);
        not3.setText("-");
        not3.setVisible(false);
        not3.setWrappingWidth(126.818359375);
        not3.setFont(new Font("System Bold", 12.0));

        not4.setLayoutX(935.0);
        not4.setLayoutY(209.0);
        not4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not4.setStrokeWidth(0.0);
        not4.setText("-");
        not4.setVisible(false);
        not4.setWrappingWidth(126.818359375);
        not4.setFont(new Font("System Bold", 12.0));

        not5.setLayoutX(936.0);
        not5.setLayoutY(252.0);
        not5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not5.setStrokeWidth(0.0);
        not5.setText("-");
        not5.setVisible(false);
        not5.setWrappingWidth(126.818359375);
        not5.setFont(new Font("System Bold", 12.0));

        not6.setLayoutX(937.0);
        not6.setLayoutY(295.0);
        not6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not6.setStrokeWidth(0.0);
        not6.setText("-");
        not6.setVisible(false);
        not6.setWrappingWidth(126.818359375);
        not6.setFont(new Font("System Bold", 12.0));

        not7.setLayoutX(936.0);
        not7.setLayoutY(343.0);
        not7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        not7.setStrokeWidth(0.0);
        not7.setText("-");
        not7.setVisible(false);
        not7.setWrappingWidth(126.818359375);
        not7.setFont(new Font("System Bold", 12.0));
        setCenter(anchorPane);



        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(imageView0);
        anchorPane.getChildren().add(imageView1);
        anchorPane.getChildren().add(imageView2);
        anchorPane.getChildren().add(imageView3);
        anchorPane.getChildren().add(imageView4);
        anchorPane.getChildren().add(addMoney);
        anchorPane.getChildren().add(HomeButton);
        anchorPane.getChildren().add(MyWishlistButton);
        anchorPane.getChildren().add(AddItemButton);
        anchorPane.getChildren().add(FriendButton);
        anchorPane.getChildren().add(CashButton);
        anchorPane.getChildren().add(SignOutButt);
        anchorPane.getChildren().add(nameText);
        anchorPane.getChildren().add(moneyText);
        anchorPane.getChildren().add(imageView5);
        anchorPane.getChildren().add(SettingButton);
        anchorPane.getChildren().add(imageView6);
        anchorPane.getChildren().add(HelpButton);
        anchorPane.getChildren().add(imageView7);
        anchorPane.getChildren().add(devicesButt);
        anchorPane.getChildren().add(gamesButt);
        anchorPane.getChildren().add(clothButt);
        anchorPane.getChildren().add(img3);
        anchorPane.getChildren().add(img2);
        anchorPane.getChildren().add(img1);
        anchorPane.getChildren().add(img6);
        anchorPane.getChildren().add(img5);
        anchorPane.getChildren().add(img4);
        anchorPane.getChildren().add(text1);
        anchorPane.getChildren().add(p1);
        anchorPane.getChildren().add(add1);
        anchorPane.getChildren().add(text2);
        anchorPane.getChildren().add(p2);
        anchorPane.getChildren().add(add2);
        anchorPane.getChildren().add(text3);
        anchorPane.getChildren().add(p3);
        anchorPane.getChildren().add(add3);
        anchorPane.getChildren().add(text4);
        anchorPane.getChildren().add(p4);
        anchorPane.getChildren().add(add4);
        anchorPane.getChildren().add(text5);
        anchorPane.getChildren().add(p5);
        anchorPane.getChildren().add(add5);
        anchorPane.getChildren().add(text6);
        anchorPane.getChildren().add(p6);
        anchorPane.getChildren().add(add6);
        anchorPane.getChildren().add(img9);
        anchorPane.getChildren().add(img8);
        anchorPane.getChildren().add(img7);
        anchorPane.getChildren().add(img12);
        anchorPane.getChildren().add(img11);
        anchorPane.getChildren().add(img10);
        anchorPane.getChildren().add(text7);
        anchorPane.getChildren().add(p7);
        anchorPane.getChildren().add(add7);
        anchorPane.getChildren().add(text8);
        anchorPane.getChildren().add(p8);
        anchorPane.getChildren().add(add8);
        anchorPane.getChildren().add(text9);
        anchorPane.getChildren().add(add9);
        anchorPane.getChildren().add(text10);
        anchorPane.getChildren().add(p10);
        anchorPane.getChildren().add(add10);
        anchorPane.getChildren().add(text11);
        anchorPane.getChildren().add(p11);
        anchorPane.getChildren().add(add11);
        anchorPane.getChildren().add(text12);
        anchorPane.getChildren().add(p12);
        anchorPane.getChildren().add(add12);
        anchorPane.getChildren().add(p9);
        anchorPane.getChildren().add(img15);
        anchorPane.getChildren().add(img14);
        anchorPane.getChildren().add(img13);
        anchorPane.getChildren().add(img18);
        anchorPane.getChildren().add(img17);
        anchorPane.getChildren().add(img16);
        anchorPane.getChildren().add(text13);
        anchorPane.getChildren().add(p13);
        anchorPane.getChildren().add(add13);
        anchorPane.getChildren().add(text14);
        anchorPane.getChildren().add(p14);
        anchorPane.getChildren().add(add14);
        anchorPane.getChildren().add(text15);
        anchorPane.getChildren().add(add15);
        anchorPane.getChildren().add(text16);
        anchorPane.getChildren().add(p16);
        anchorPane.getChildren().add(add16);
        anchorPane.getChildren().add(text17);
        anchorPane.getChildren().add(p17);
        anchorPane.getChildren().add(add17);
        anchorPane.getChildren().add(text18);
        anchorPane.getChildren().add(p18);
        anchorPane.getChildren().add(add18);
        anchorPane.getChildren().add(p15);
	anchorPane.getChildren().add(notificationIcon);
        anchorPane.getChildren().add(notificationWindow);
        anchorPane.getChildren().add(not1);
        anchorPane.getChildren().add(not2);
        anchorPane.getChildren().add(not3);
        anchorPane.getChildren().add(not4);
        anchorPane.getChildren().add(not5);
        anchorPane.getChildren().add(not6);
        anchorPane.getChildren().add(not7);
        
        moneyText.setText(currentMoney);
        nameText.setText(username);
        
         if (backGroundPic != null){
        imageView.setImage(new Image(getClass().getResource(backGroundPic).toExternalForm()));
        }
        HomeButton.setOnMouseEntered(e -> {
                    HomeButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        HomeButton.setOnMouseExited(e -> {
                    HomeButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        HomeButton.setOnAction(e -> {
             try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchHomeScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        MyWishlistButton.setOnMouseEntered(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        MyWishlistButton.setOnMouseExited(e -> {
                    MyWishlistButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        
        MyWishlistButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchWishlistScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        
        FriendButton.setOnMouseEntered(e -> {
                    FriendButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnMouseExited(e -> {
                    FriendButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        FriendButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchFriendsScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
                    
        HelpButton.setOnMouseEntered(e -> {
                    HelpButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        HelpButton.setOnMouseExited(e -> {
                    HelpButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        HelpButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue, backGroundPic);
                buttonSwitcher.switchHelpScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
                });
        CashButton.setOnMouseEntered(e -> {
                    CashButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");

                     });
        CashButton.setOnMouseExited(e -> {
                    CashButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                    
                });
        CashButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        addMoney.setOnMouseClicked(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic);
                buttonSwitcher.switchMoneyScene();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SettingButton.setOnMouseEntered(e -> {
                    SettingButton.setStyle("-fx-background-color: Purple; -fx-border-radius: 30; -fx-background-radius: 30;");
                     });
        SettingButton.setOnMouseExited(e -> {
                    SettingButton.setStyle("-fx-background-color: TRANSPARENT; -fx-border-radius: 30; -fx-background-radius: 30;");
                });
        SettingButton.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue , backGroundPic );
                buttonSwitcher.switchSettingScene();
            }catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        SignOutButt.setOnAction(e -> {
            try {
                ButtonSwitcher buttonSwitcher = new ButtonSwitcher(s, username, moneyValue);
                buttonSwitcher.switchSignOut();
            } catch (IOException ex) {
                Logger.getLogger(appScene.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        Text[] notification = {not1,not2,not3,not4,not5,not6,not7};
        
        notificationIcon.setOnMouseClicked(event -> {
            try { 
                if (notificationTurn == true){
                Socket socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String request = "notify" + ":" + username;
                output.println(request);
                String response = input.readLine();
                if (response != null && !response.isEmpty()) {
                notificationView(response,notification);
                notificationTurn = false;
                }
                else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Ops! seems you don't have notification yet");
                    alert.showAndWait();}
                }
                else {
                notificationWindow.setVisible(false);
                not1.setVisible(false);
                not2.setVisible(false);
                not3.setVisible(false);
                not4.setVisible(false);
                not5.setVisible(false);
                not6.setVisible(false);
                not7.setVisible(false);
                notificationTurn = true;
                }
            } catch (IOException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error, can't connet to server");
                alert.setHeaderText(null);
                alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                alert.showAndWait();}
            
        });
        add1.setOnMouseClicked(event -> {
            String ID = "1";
            String price = p1.getText();
            addItem(ID,price);
            return;
            } );
        add2.setOnMouseClicked(event -> {
            String ID = "2";
            String price = p2.getText();
            addItem(ID,price);
            return;
            } );
        add3.setOnMouseClicked(event -> {
            String ID = "3";
            String price = p3.getText();
            addItem(ID,price);
            return;
            } );
        add4.setOnMouseClicked(event -> {
            String ID = "4";
            String price = p4.getText();
            addItem(ID,price);
            return;
            } );
        add5.setOnMouseClicked(event -> {
            String ID = "5";
            String price = p5.getText();
            addItem(ID,price);
            return;
            } );
        add6.setOnMouseClicked(event -> {
            String ID = "6";
            String price = p6.getText();
            addItem(ID,price);
            return;
            } );
        add7.setOnMouseClicked(event -> {
            String ID = "7";
            String price = p7.getText();
            addItem(ID,price);
            return;
            } );
        add8.setOnMouseClicked(event -> {
            String ID = "8";
            String price = p8.getText();
            addItem(ID,price);
            return;
            } );
        add9.setOnMouseClicked(event -> {
            String ID = "9";
            String price = p9.getText();
            addItem(ID,price);
            return;
            } );
        add10.setOnMouseClicked(event -> {
            String ID = "10";
            String price = p10.getText();
            addItem(ID,price);
            return;
            } );
        add11.setOnMouseClicked(event -> {
            String ID = "11";
            String price = p11.getText();
            addItem(ID,price);
            return;
            } );
        add12.setOnMouseClicked(event -> {
            String ID = "12";
            String price = p12.getText();
            addItem(ID,price);
            return;
            } );
        add13.setOnMouseClicked(event -> {
            String ID = "13";
            String price = p13.getText();
            addItem(ID,price);
            return;
            } );
        add14.setOnMouseClicked(event -> {
            String ID = "14";
            String price = p14.getText();
            addItem(ID,price);
            return;
            } );
        add15.setOnMouseClicked(event -> {
            String ID = "15";
            String price = p15.getText();
            addItem(ID,price);
            return;
            } );
        add16.setOnMouseClicked(event -> {
            String ID = "16";
            String price = p16.getText();
            addItem(ID,price);
            return;
            } );
        add17.setOnMouseClicked(event -> {
            String ID = "17";
            String price = p17.getText();
            addItem(ID,price);
            return;
            } );
        add18.setOnMouseClicked(event -> {
            String ID = "18";
            String price = p18.getText();
            addItem(ID,price);
            return;
            } );
        
        devicesButt.setOnMouseClicked(event -> {
            clear();
            add1.setVisible(true);text1.setVisible(true);p1.setVisible(true);img1.setVisible(true);
            add2.setVisible(true);text2.setVisible(true);p2.setVisible(true);img2.setVisible(true);
            add3.setVisible(true);text3.setVisible(true);p3.setVisible(true);img3.setVisible(true);
            add4.setVisible(true);text4.setVisible(true);p4.setVisible(true);img4.setVisible(true);
            add5.setVisible(true);text5.setVisible(true);p5.setVisible(true);img5.setVisible(true);
            add6.setVisible(true);text6.setVisible(true);p6.setVisible(true);img6.setVisible(true);
            } );
        gamesButt.setOnMouseClicked(event -> {
            clear();
            add7.setVisible(true);text7.setVisible(true);p7.setVisible(true);img7.setVisible(true);
            add8.setVisible(true);text8.setVisible(true);p8.setVisible(true);img8.setVisible(true);
            add9.setVisible(true);text9.setVisible(true);p9.setVisible(true);img9.setVisible(true);
            add10.setVisible(true);text10.setVisible(true);p10.setVisible(true);img10.setVisible(true);
            add11.setVisible(true);text11.setVisible(true);p11.setVisible(true);img11.setVisible(true);
            add12.setVisible(true);text12.setVisible(true);p12.setVisible(true);img12.setVisible(true);
            } );
        clothButt.setOnMouseClicked(event -> {
            clear();
            add13.setVisible(true);text13.setVisible(true);p13.setVisible(true);img13.setVisible(true);
            add14.setVisible(true);text14.setVisible(true);p14.setVisible(true);img14.setVisible(true);
            add15.setVisible(true);text15.setVisible(true);p15.setVisible(true);img15.setVisible(true);
            add16.setVisible(true);text16.setVisible(true);p16.setVisible(true);img16.setVisible(true);
            add17.setVisible(true);text17.setVisible(true);p17.setVisible(true);img17.setVisible(true);
            add18.setVisible(true);text18.setVisible(true);p18.setVisible(true);img18.setVisible(true);
            } );
        
        
    }
    public void clear(){
    add1.setVisible(false);text1.setVisible(false);p1.setVisible(false);img1.setVisible(false);
    add2.setVisible(false);text2.setVisible(false);p2.setVisible(false);img2.setVisible(false);
    add3.setVisible(false);text3.setVisible(false);p3.setVisible(false);img3.setVisible(false);
    add4.setVisible(false);text4.setVisible(false);p4.setVisible(false);img4.setVisible(false);
    add5.setVisible(false);text5.setVisible(false);p5.setVisible(false);img5.setVisible(false);
    add6.setVisible(false);text6.setVisible(false);p6.setVisible(false);img6.setVisible(false);
    add7.setVisible(false);text7.setVisible(false);p7.setVisible(false);img7.setVisible(false);
    add8.setVisible(false);text8.setVisible(false);p8.setVisible(false);img8.setVisible(false);
    add9.setVisible(false);text9.setVisible(false);p9.setVisible(false);img9.setVisible(false);
    add10.setVisible(false);text10.setVisible(false);p10.setVisible(false);img10.setVisible(false);
    add11.setVisible(false);text11.setVisible(false);p11.setVisible(false);img11.setVisible(false);
    add12.setVisible(false);text12.setVisible(false);p12.setVisible(false);img12.setVisible(false);
    add13.setVisible(false);text13.setVisible(false);p13.setVisible(false);img13.setVisible(false);
    add14.setVisible(false);text14.setVisible(false);p14.setVisible(false);img14.setVisible(false);
    add15.setVisible(false);text15.setVisible(false);p15.setVisible(false);img15.setVisible(false);
    add16.setVisible(false);text16.setVisible(false);p16.setVisible(false);img16.setVisible(false);
    add17.setVisible(false);text17.setVisible(false);p17.setVisible(false);img17.setVisible(false);
    add18.setVisible(false);text18.setVisible(false);p18.setVisible(false);img18.setVisible(false);
    
    
    
    }
    public void addItem(String ID, String price) {
    try {
        Socket socket = new Socket("localhost", 7001);
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String user = username;
        String request = "additem" + ":" + user + ":" + ID +":" + price;
        output.println(request);
        String response = input.readLine();
        
        if (response.equals("success")) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("ITEM ADDED");
            alert.setHeaderText(null);
            alert.setContentText("Your Item Is Added Successfully to your wishlist!");
            alert.showAndWait();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("This item was already added before!");
            alert.showAndWait();
        }
    } catch (IOException ex) {
        Logger.getLogger(AddItemScene.class.getName()).log(Level.SEVERE, null, ex);
    }
	
    }
	public void notificationView(  String response , Text[] notification )
    {       String[] data = response.split("#");
            notificationWindow.setVisible(true);
            for (int i = 0; i < notification.length && i < data.length; i++) {
                
                String[] components = data[i].split(":");
                String notifyMsg     = components[1];
                notification[i].setVisible(true);
                notification[i].setText(notifyMsg);
            }
    }

}
