package giftgenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class editpassword extends BorderPane {

    protected final ImageView imageStar;
    protected final ImageView imageStar2;
    protected final ImageView imageBoo;
    protected final AnchorPane anchorPane;
    protected final ImageView imageView;
    protected final TextField passwordUnhide;
    protected final TextField userField;
    protected final Text text;
    protected final Button backButton;
    protected final Button saveButton;
    protected final Text text0;
    protected final Text text1;
    protected final Text text2;
    protected final ProgressBar pgbar;
    protected final TextField secretField;
    protected final TextField passwordField;
    protected final TextField confirmPasswordField;

    public editpassword( Stage s) {

        anchorPane = new AnchorPane();
        imageView = new ImageView();
        passwordUnhide = new TextField();
        userField = new TextField();
        text = new Text();
        backButton = new Button();
        saveButton = new Button();
        text0 = new Text();
        text1 = new Text();
        text2 = new Text();
        pgbar = new ProgressBar();
        secretField = new TextField();
        passwordField = new TextField();
        confirmPasswordField = new TextField();

        setMaxHeight(400.0);
        setMaxWidth(612.0);
        setMinHeight(400.0);
        setMinWidth(570.0);
        setPrefHeight(400.0);
        setPrefWidth(592.0);

        BorderPane.setAlignment(anchorPane, javafx.geometry.Pos.CENTER);
        anchorPane.setPrefHeight(410.0);
        anchorPane.setPrefWidth(613.0);

        imageView.setFitHeight(427.0);
        imageView.setFitWidth(610.0);
        imageView.setLayoutX(0.0);
        imageView.setLayoutY(0.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(new Image(getClass().getResource("loginback.png").toExternalForm()));

        passwordUnhide.setAlignment(javafx.geometry.Pos.CENTER);
        passwordUnhide.setLayoutX(435.0);
        passwordUnhide.setLayoutY(121.0);
        passwordUnhide.setOpacity(0.88);
        passwordUnhide.setPrefHeight(30.0);
        passwordUnhide.setPrefWidth(147.0);
        passwordUnhide.setPromptText("insert password here");
        passwordUnhide.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");
        passwordUnhide.setVisible(false);

        userField.setAlignment(javafx.geometry.Pos.CENTER);
        userField.setLayoutX(437.0);
        userField.setLayoutY(69.0);
        userField.setOpacity(0.88);
        userField.setPrefHeight(30.0);
        userField.setPrefWidth(147.0);
        userField.setPromptText("insert your username");
        userField.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        text.setFill(javafx.scene.paint.Color.valueOf("#b9e7ff"));
        text.setLayoutX(435.0);
        text.setLayoutY(35.0);
        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setText("Change your password");
        text.setFont(new Font("System Bold", 14.0));

        backButton.setLayoutX(524.0);
        backButton.setLayoutY(368.0);
        backButton.setMnemonicParsing(false);
        backButton.setOpacity(0.88);
        backButton.setPrefHeight(30.0);
        backButton.setPrefWidth(69.0);
        backButton.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        backButton.setText("Back");
        backButton.setCursor(Cursor.HAND);
        backButton.setFont(new Font("System Bold", 12.0));

        saveButton.setContentDisplay(javafx.scene.control.ContentDisplay.CENTER);
        saveButton.setLayoutX(438.0);
        saveButton.setLayoutY(286.0);
        saveButton.setMnemonicParsing(false);
        saveButton.setOpacity(0.88);
        saveButton.setPrefHeight(30.0);
        saveButton.setPrefWidth(147.0);
        saveButton.setStyle("-fx-background-color: lightblue; -fx-background-radius: 30; -fx-border-radius: 30;");
        saveButton.setText("Save");
        saveButton.setCursor(Cursor.HAND);
        saveButton.setFont(new Font("System Bold", 12.0));

        text0.setFill(javafx.scene.paint.Color.WHITE);
        text0.setLayoutX(435.0);
        text0.setLayoutY(61.0);
        text0.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text0.setStrokeWidth(0.0);
        text0.setText("Username");
        text0.setFont(new Font("System Bold", 14.0));

        text1.setFill(javafx.scene.paint.Color.WHITE);
        text1.setLayoutX(436.0);
        text1.setLayoutY(114.0);
        text1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1.setStrokeWidth(0.0);
        text1.setText("Secret");
        text1.setFont(new Font("System Bold", 14.0));

        text2.setFill(javafx.scene.paint.Color.WHITE);
        text2.setLayoutX(462.0);
        text2.setLayoutY(181.0);
        text2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text2.setStrokeWidth(0.0);
        text2.setText("Edit Password");
        text2.setFont(new Font("System Bold", 14.0));

        pgbar.setLayoutX(438.0);
        pgbar.setLayoutY(267.0);
        pgbar.setMaxHeight(12.0);
        pgbar.setMinHeight(12.0);
        pgbar.setPrefHeight(12.0);
        pgbar.setPrefWidth(147.0);
        pgbar.setProgress(0.0);

        secretField.setAlignment(javafx.geometry.Pos.CENTER);
        secretField.setLayoutX(437.0);
        secretField.setLayoutY(123.0);
        secretField.setOpacity(0.88);
        secretField.setPrefHeight(30.0);
        secretField.setPrefWidth(147.0);
        secretField.setPromptText("insert your number");
        secretField.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        passwordField.setAlignment(javafx.geometry.Pos.CENTER);
        passwordField.setLayoutX(437.0);
        passwordField.setLayoutY(189.0);
        passwordField.setOpacity(0.88);
        passwordField.setPrefHeight(30.0);
        passwordField.setPrefWidth(147.0);
        passwordField.setPromptText("insert your number");
        passwordField.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");

        confirmPasswordField.setAlignment(javafx.geometry.Pos.CENTER);
        confirmPasswordField.setLayoutX(437.0);
        confirmPasswordField.setLayoutY(227.0);
        confirmPasswordField.setOpacity(0.88);
        confirmPasswordField.setPrefHeight(30.0);
        confirmPasswordField.setPrefWidth(147.0);
        confirmPasswordField.setPromptText("insert your number");
        confirmPasswordField.setStyle("-fx-background-color: white; -fx-border-radius: 30; -fx-background-radius: 30;");
        setRight(anchorPane);

        anchorPane.getChildren().add(imageView);
        anchorPane.getChildren().add(passwordUnhide);
        anchorPane.getChildren().add(userField);
        anchorPane.getChildren().add(text);
        anchorPane.getChildren().add(backButton);
        anchorPane.getChildren().add(saveButton);
        anchorPane.getChildren().add(text0);
        anchorPane.getChildren().add(text1);
        anchorPane.getChildren().add(text2);
        anchorPane.getChildren().add(pgbar);
        anchorPane.getChildren().add(secretField);
        anchorPane.getChildren().add(passwordField);
        anchorPane.getChildren().add(confirmPasswordField);
        
        
        backButton.setOnAction(e -> {
            Parent rootlogin = new LoginScene(s);
            Scene scene = new Scene(rootlogin);
            s.setScene(scene);       
            });
        passwordField.textProperty().addListener((observable, oldValue, newValue) -> {
            int length = newValue.length();
            double progress = calculateStrength(newValue);
            pgbar.setProgress(progress);

            // update color based on strength level
            if (progress < 0.33) {
                pgbar.setStyle("-fx-accent: red;");
            } else if (progress < 0.66) {
                pgbar.setStyle("-fx-accent: yellow;");
            } else {
                pgbar.setStyle("-fx-accent: green;");
            }
        });
        
        saveButton.setOnAction(e -> {
          
            Socket socket;
            try {
                socket = new Socket("localhost", 7001);
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String password = passwordField.getText();
                String confirmPassword = confirmPasswordField.getText();
                 if(secretField.getText().isEmpty() || passwordField.getText().isEmpty() || userField.getText().isEmpty()  )  {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Please fill all blank fields");
                        alert.showAndWait();
                        return;
                    }
                 else if (!password.equals(confirmPassword)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry! Password and Confirm Password do not match. Please try again.");
                    alert.showAndWait();
                    return;
                }
                String signUpQuery = "editPass"+":"+userField.getText() + ":" + secretField.getText() + ":" + passwordField.getText() ;
                output.println(signUpQuery);
                boolean editCheck = Boolean.parseBoolean(input.readLine());
                if (editCheck) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Password change");
                    alert.setHeaderText(null);
                    alert.setContentText("Password changed successfully");
                    alert.showAndWait();
                    Parent rootlogin = new LoginScene(s);
                    Scene scene = new Scene(rootlogin);
                    s.setScene(scene);  
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Sorry! Either the username or your answer is incorrect, try again!");
                    alert.showAndWait();
                }
                socket.close();
            } catch (IOException ex) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error, can't connet to server");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to connect to server. Please check your server connection and press ok to try again.");
                    alert.showAndWait();
            }
        });
        imageStar = new ImageView();       
            imageStar.setFitHeight(200.0);
            imageStar.setFitWidth(200.0);
            imageStar.setLayoutX(-10.0);
            imageStar.setLayoutY(1.0);
            imageStar.setPickOnBounds(true);
            imageStar.setPreserveRatio(true);
            imageStar.setImage(new Image(getClass().getResource("star.png").toExternalForm()));
            imageStar.toFront(); 
            anchorPane.getChildren().add(imageStar);

            Thread starThread = new Thread(() -> {
                int y = 270;
                int x = -10;
                boolean sleep = true; 
                boolean rotate = true; 
                while (sleep == true ) {
                    if (rotate)
                    {
                    x += 10;
                    y -= 10 ;
                    }
                    else {
                    x += 10; 
                    y += 10;
                    }
                    imageStar.setLayoutX(x);
                    imageStar.setLayoutY(y);

                    if (y <= 0){
                            x=0;
                            y=0;
                            imageStar.setRotate(90.0);
                            rotate = false;
                            sleep=false;
                            imageStar.setVisible(false);
                    }else if(y>=270){
                           x=0;
                           y=270;
                           imageStar.setRotate(360.0); 
                           rotate = true;
                           sleep=false;
                           imageStar.setVisible(false);
                           }

                    try {
                        if(sleep == false ){
                        Thread.sleep(4555);
                        sleep = true;
                        imageStar.setVisible(true);

                        }
                        else{
                        Thread.sleep(100);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            starThread.setDaemon(true);
            starThread.start();

            imageStar2 = new ImageView();       
            imageStar2.setFitHeight(100.0);
            imageStar2.setFitWidth(100.0);
            imageStar2.setLayoutX(100.0);
            imageStar2.setLayoutY(1.0);
            imageStar2.setImage(new Image(getClass().getResource("star2.png").toExternalForm()));
            imageStar2.toFront(); 
            anchorPane.getChildren().add(imageStar2);


            Thread imageStar2Thread = new Thread(() -> {
                Random random = new Random();
            int op1 = -10;
            while (true) {
                int x = random.nextInt(400);
                int y = random.nextInt(300);
                imageStar2.setLayoutX(x);
                imageStar2.setLayoutY(y);
                for (int i = 0; i <= 100; i++) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                for (int i = 100; i >= 0; i--) {
                        imageStar2.setOpacity(i / 100.0);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
            });
            imageStar2Thread.setDaemon(true);
            imageStar2Thread.start();


            imageBoo = new ImageView();       
            imageBoo.setFitHeight(200.0);
            imageBoo.setFitWidth(200.0);
            imageBoo.setLayoutX(200.0);
            imageBoo.setLayoutY(100.0);
            imageBoo.setPickOnBounds(true);
            imageBoo.setPreserveRatio(true);
            imageBoo.setVisible(false);
            imageBoo.setImage(new Image(getClass().getResource("Boo.png").toExternalForm()));
            imageStar.toFront(); 
            anchorPane.getChildren().add(imageBoo);

            text.setOnMouseEntered(e -> {
                        text.setFill(Color.WHITE);
                        text.setUnderline(true);
                        text.setFont(Font.font("System",FontWeight.BOLD ,14));
                         });
            text.setOnMouseExited(e -> {
                        text.setFill(Color.LIGHTBLUE);
                        text.setUnderline(false);
                        text.setFont(Font.font("System",FontWeight.BOLD,  14));
                    });
            text.setOnMouseClicked(e -> {
                Thread imageBooThread = new Thread(() -> {
                imageBoo.setFitWidth(50.0);
                imageBoo.setVisible(true);
                int size = 50;
                int step = 5;

                while (size < 300) {
                    size += step;
                    imageBoo.setFitWidth(size);
                    imageBoo.setFitHeight(size);
                    imageBoo.setVisible(true);

                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException es) {
                        es.printStackTrace();
                    }
                }
                    imageBoo.setVisible(false);
                    Thread.currentThread().interrupt();
                });
                        imageBooThread.start();
            });
    }
        private double calculateStrength(String password) {
            int score = 0;

                if (password.length() >= 8) {
                score += 1;
                }

                if (password.matches(".*[A-Z].*")) {
                    score += 1;
                }

                if (password.matches(".*[a-z].*")) {
                    score += 1;
                }

                if (password.matches(".*\\d.*")) {
                    score += 1;
                }

                if (password.matches(".*[!@#$%^&*()].*")) {
                    score += 1;
                }

                switch (score) {
                    case 1:
                        return .15;
                    case 2:
                        return .33;
                    case 3:
                        return .66;
                    case 4:
                        return .9;
                    default:
                        return 0;
                }    
        };        
        
}
